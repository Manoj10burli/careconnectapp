import { fileURLToPath, URL } from 'node:url';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';

// `npm run build`         -> dist/index.html, one self-contained file (web demo)
// `npm run build:android` -> dist/ with normal assets, synced into the Android app
export default defineConfig(({ mode }) => ({
  base: './',
  plugins: [react(), mode !== 'android' && viteSingleFile()],
  resolve: { alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) } },
}));
