import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.careconnect.demo',
  appName: 'CareConnect',
  webDir: 'dist',
  android: {
    // Health data: never allow the WebView to be inspected in release builds.
    webContentsDebuggingEnabled: false,
    allowMixedContent: false,
  },
  plugins: {
    SystemBars: {
      insetsHandling: 'css',
      initialViewportFitValueHint: 'cover',
      style: 'LIGHT',
    },
    SplashScreen: {
      launchShowDuration: 1200,
      launchAutoHide: true,
      backgroundColor: '#083F3D',
      androidScaleType: 'CENTER_CROP',
      showSpinner: false,
    },
    LocalNotifications: {
      smallIcon: 'ic_stat_careconnect',
      iconColor: '#0F8A84',
    },
  },
};

export default config;
