# CareConnect — Architecture and path to production

> The prototype anticipates the controls below; it does not implement them.
> Nothing here is a claim of regulatory compliance. Compliance (HIPAA, GDPR,
> DPDP Act 2023, local health-data rules, ABDM integration in India, etc.) must be
> assessed for the deployment country with legal and clinical-safety advisers.

## 1. Layering today

```
Pages / components  ──►  services (interfaces.ts)  ──►  mock/*  ──►  localStorage
                                   ▲
                     swap here ────┘  http/* ──► REST API ──► database, blob, AI, messaging
```

* **Types** (`src/types`) are the API contract. Generate them from OpenAPI later
  (e.g. `openapi-typescript`) so frontend and backend never drift.
* **Service registry** (`src/services/index.ts`) is the single seam.
* **useData** re-fetches when data changes. In production replace with
  TanStack Query + SignalR / Azure Web PubSub events for live updates.
* The same services and types can be shared with a **React Native** app.

## 2. Target production architecture (Microsoft Azure)

| Concern | Prototype | Production |
|---|---|---|
| Frontend | React SPA, hash routing | React (Azure Static Web Apps / Front Door + WAF); React Native mobile |
| API | Mock services | ASP.NET Core 8 or Node.js (NestJS) on Azure App Service / Container Apps behind API Management |
| Database | localStorage | Azure Database for PostgreSQL or Azure SQL; TDE, private endpoints, PITR backups, geo-redundant replica |
| Auth | Demo session | Microsoft Entra ID (staff), Entra External ID / Azure AD B2C (patients); OAuth 2.0 + PKCE, MFA, conditional access |
| Files | Browser memory | Azure Blob Storage (private containers, SAS URLs issued per request, Defender for Storage malware scanning) |
| AI | Mock responses | Azure OpenAI via backend only; Azure AI Document Intelligence for OCR; content filters; prompt forbids diagnosis/treatment |
| Notifications | In-app list | Azure Communication Services (email/SMS), Notification Hubs (push), queued via Service Bus |
| Secrets | none | Azure Key Vault + managed identities (no secrets in code or pipelines) |
| Monitoring | none | Azure Application Insights + Log Analytics; correlation IDs already sent by `apiClient.ts` |
| CI/CD | `npm run build` | GitHub Actions or Azure DevOps: lint, type-check, test, SAST/dependency scan, IaC (Bicep/Terraform), staged deploys |
| Interop | none | HL7 FHIR R4 resources (Patient, Appointment, Observation, MedicationRequest, ServiceRequest) |

## 3. Suggested API surface

```
POST /api/auth/session                      (handled by Entra ID in production)
GET  /api/patients/{id}                      GET  /api/patients?search=
GET  /api/doctors  /api/departments          GET  /api/doctors/{id}/slots?date=
GET  /api/appointments?patientId&doctorId&date&status
POST /api/appointments   POST /api/appointments/{id}/cancel   PATCH /api/appointments/{id}/status
GET  /api/patients/{id}/records              POST /api/patients/{id}/consultations
GET  /api/prescriptions?patientId            POST /api/prescriptions
GET  /api/lab-reports?patientId              POST /api/lab-orders
POST /api/documents (multipart → blob)       GET  /api/documents/{id}/download (→ short-lived SAS)
POST /api/ai/document-summary                (server calls Azure OpenAI)
GET  /api/notifications  PATCH /api/notifications/{id}/read
GET/PUT /api/admin/config   GET /api/admin/audit
```

## 4. Security controls to build

* **Encryption** — TLS 1.2+ everywhere, HSTS; encryption at rest (TDE, Blob SSE,
  optionally customer-managed keys in Key Vault).
* **Authentication** — OAuth 2.0 / OIDC, MFA for staff, short-lived tokens,
  refresh-token rotation, session timeout.
* **Authorization (RBAC + relationship checks)** — enforced in the API, never
  only in the UI. Doctors see patients they have a care relationship with;
  break-glass access is logged and reviewed. The UI route guard in `App.tsx`
  mirrors this for usability only.
* **Audit trail** — every read and write of patient data (who, what, when,
  from where) to append-only storage. The prototype's `AuditEntry` model and
  admin Audit log screen show the shape.
* **Secure uploads** — type/size allow-list (prototype: `DocumentService.validate`),
  server-side re-validation, malware scanning, no public blob access.
* **Input validation** — schema validation at the API (FluentValidation / zod),
  parameterised queries, output encoding, CSP headers.
* **AI safety** — backend-only model calls, no PHI sent to non-approved
  endpoints, system prompt restricting to extraction/explanation, output
  checks, visible disclaimer, human review, prompt/response logging policy.
* **Privacy** — data minimisation, consent capture, data-subject rights
  (access, correction, erasure where lawful), data residency (e.g. Azure
  Central India), retention schedules.
* **Resilience** — automated backups, tested restores, documented RPO/RTO,
  multi-zone deployment, disaster-recovery runbook.
* **Operations** — dependency scanning, penetration testing, vulnerability
  management, incident response plan.

## 5. Suggested roadmap

1. Backend skeleton + PostgreSQL schema from `src/types`; Entra ID sign-in.
2. Replace services one by one (appointments first), keep mocks for tests.
3. Blob storage uploads + lab integration (FHIR).
4. Notifications via Service Bus + Azure Communication Services.
5. Azure OpenAI document summaries with clinical-safety review.
6. Security hardening, audit, performance and accessibility testing, regulatory assessment.
