# CareConnect for Android

The Android app wraps the same React + TypeScript code in a native shell using
[Capacitor 8](https://capacitorjs.com). Every screen, service and piece of demo
data is shared with the web version; the `android/` folder is a standard
Android Studio project.

> Demo prototype with fictional data. Not a medical device, not for real
> patient data, and not certified or compliant with any healthcare regulation.

## Get an APK

### Option A — no Android tooling (GitHub Actions)

1. Push this folder to a GitHub repository (branch `main`).
2. Open **Actions → Android APK**. It runs on push, or press **Run workflow**.
3. When it finishes (~5–8 min), download **CareConnect-debug-apk** from the
   run's *Artifacts* section and unzip it.
4. Copy `app-debug.apk` to the phone and open it. Android will ask you to allow
   installs from that source (Files app or browser) — allow it once.

### Option B — Android Studio

Requirements: Node.js 22+, JDK 21, Android Studio (Otter or newer) with
SDK 36.

```bash
npm install
npm run build:android   # builds the web app and copies it into android/
npm run android:open    # opens the project in Android Studio
```

In Android Studio press **Run ▶** with a phone connected (USB debugging on) or
an emulator. For an APK file: **Build → Build App Bundle(s) / APK(s) → Build
APK(s)**. The file lands in `android/app/build/outputs/apk/debug/`.

Command line alternative once the SDK is installed: `npm run android:apk`.

After changing any code in `src/`, run `npm run build:android` again.

## What is native in the app

| Feature | How it works |
|---|---|
| System notifications | New in-app notifications for the signed-in user (booking confirmed, prescription added, lab test requested, follow-up) appear in the Android notification shade. Tapping one opens the related screen. Android 13+ asks permission on first sign-in. |
| Back button | Closes an open sheet, dialog or menu first, then goes back; on a home screen it sends the app to the background. |
| Haptics | Short vibration on confirmations and errors. |
| PDF reports | "Download sample PDF" opens the Android share sheet, so the PDF can be opened, saved to Files/Drive or sent. |
| File upload | The upload buttons open the Android file picker. |
| Edge-to-edge | Content respects the status and navigation bars (Capacitor SystemBars). |
| Offline | The app and fonts are bundled; all demo features work with no connection. |
| Icon and splash | CareConnect pulse mark; adaptive icon for Android 8+. |

Demo data is stored on the device (WebView storage) and survives restarts.
Use **Admin → Configuration → Reset demo data** before a presentation.

## Security settings already applied

* `allowBackup="false"` plus data-extraction rules: app data is excluded from
  cloud backup and device-to-device transfer.
* `usesCleartextTraffic="false"`: no unencrypted HTTP.
* WebView debugging disabled; no mixed content.

## Before a Play Store / production release

1. **Signing** — create an upload key and a release build:
   `keytool -genkey -v -keystore careconnect-upload.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload`,
   then **Build → Generate Signed App Bundle** (AAB). Store the keystore and
   passwords in a secret manager / GitHub encrypted secrets, never in the repo.
   Change `appId` in `capacitor.config.ts` to your organisation's package name first.
2. **Push notifications** — replace local notifications with Firebase Cloud
   Messaging (`@capacitor/push-notifications`) sent from the backend via Azure
   Notification Hubs, so alerts arrive when the app is closed.
3. **Sign-in** — Microsoft Entra ID / External ID using the system browser
   (MSAL or `@capacitor/browser` + PKCE), with biometric unlock for returning users.
4. **On-device data** — move cached patient data to encrypted storage
   (Android Keystore-backed), set session timeouts, and consider
   `FLAG_SECURE` to hide health data from screenshots and the recent-apps view.
5. **Network** — pin the API host with a network security config, keep all
   AI and database calls on the backend.
6. **Store listing** — Google Play's Health apps declaration, data safety
   form, privacy policy, and any country-specific health-data requirements.

## Going fully native later

The service interfaces in `src/services/interfaces.ts` and the types in
`src/types` are UI-independent, so a React Native app can reuse them unchanged
if you later want native UI components instead of a WebView.
