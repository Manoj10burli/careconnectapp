/**
 * Builds a tiny single-page PDF (Helvetica, text only) for demo downloads.
 * Production: serve the lab's original PDF from Azure Blob Storage via a
 * short-lived SAS URL issued by the backend after an authorization check.
 */
const esc = (s: string) => s.replace(/[\\()]/g, (c) => `\\${c}`).replace(/[^\x20-\x7E]/g, '-');

export function buildSamplePdf(title: string, lines: string[]): Blob {
  const content = [
    'BT', '/F1 16 Tf', '50 790 Td', `(${esc(title)}) Tj`, '/F1 10 Tf', '0 -18 Td',
    '(SAMPLE DOCUMENT - DEMO DATA - NOT A REAL PATIENT - NOT MEDICAL ADVICE) Tj',
    ...lines.flatMap((l) => ['0 -16 Td', `(${esc(l)}) Tj`]),
    'ET',
  ].join('\n');
  const objs = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>',
    `<< /Length ${content.length} >>\nstream\n${content}\nendstream`,
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
  ];
  let pdf = '%PDF-1.4\n';
  const offsets: number[] = [];
  objs.forEach((o, i) => { offsets.push(pdf.length); pdf += `${i + 1} 0 obj\n${o}\nendobj\n`; });
  const xref = pdf.length;
  pdf += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n${offsets.map((o) => `${String(o).padStart(10, '0')} 00000 n \n`).join('')}`;
  pdf += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return new Blob([pdf], { type: 'application/pdf' });
}

export { saveFile } from '@/platform/native';
