/**
 * CareConnect domain model.
 * These types are the contract between the UI and the service layer.
 * They are intentionally backend-agnostic so they can map to a .NET/Node API
 * and a PostgreSQL / Azure SQL schema later.
 */

export type ID = string;
export type ISODate = string; // YYYY-MM-DD
export type ISODateTime = string; // full ISO 8601

export type Role = 'patient' | 'doctor' | 'admin';

export interface UserAccount {
  id: ID;
  role: Role;
  name: string;
  email: string;
  phone: string;
  active: boolean;
  /** Links an account to its patient or doctor profile. */
  profileId?: ID;
  lastLogin?: ISODateTime;
}

export interface Session {
  user: UserAccount;
  /** Placeholder for a real OAuth / Entra ID access token. */
  accessToken: string;
  expiresAt: ISODateTime;
}

export interface EmergencyContact {
  name: string;
  relation: string;
  phone: string;
}

export interface Patient {
  id: ID;
  mrn: string; // medical record number (demo)
  name: string;
  dob: ISODate;
  gender: 'Female' | 'Male' | 'Other';
  bloodGroup: string;
  phone: string;
  email: string;
  address: string;
  allergies: string[];
  conditions: string[];
  emergencyContact: EmergencyContact;
  primaryDoctorId: ID;
  heightCm: number;
  weightKg: number;
}

export interface Department {
  id: ID;
  name: string;
  description: string;
  location: string;
  active: boolean;
}

export interface Doctor {
  id: ID;
  name: string;
  departmentId: ID;
  specialization: string;
  qualification: string;
  experienceYears: number;
  email: string;
  phone: string;
  /** Weekday numbers 0 (Sun) – 6 (Sat) */
  workingDays: number[];
  slots: string[]; // "09:00", "09:30", …
  active: boolean;
  room: string;
}

export type AppointmentStatus = 'Pending' | 'Confirmed' | 'Completed' | 'Cancelled';
export type AppointmentType = 'In-person' | 'Video';

export interface Appointment {
  id: ID;
  patientId: ID;
  doctorId: ID;
  departmentId: ID;
  date: ISODate;
  time: string;
  type: AppointmentType;
  reason: string;
  status: AppointmentStatus;
  createdAt: ISODateTime;
}

export interface MedicalRecord {
  id: ID;
  patientId: ID;
  doctorId: ID;
  appointmentId?: ID;
  date: ISODate;
  chiefComplaint: string;
  consultationNotes: string;
  /** Free text entered by the treating doctor. The app never generates this. */
  diagnosisByDoctor: string;
  prescriptionId?: ID;
  labTests: string[];
  followUp?: ISODate;
  vitals?: { bp: string; pulse: number; tempC: number; spo2: number };
}

export interface Medication {
  name: string;
  dosage: string;
  frequency: string;
  duration: string;
  instructions?: string;
}

export interface Prescription {
  id: ID;
  patientId: ID;
  doctorId: ID;
  date: ISODate;
  medications: Medication[];
  notes?: string;
  status: 'Active' | 'Completed';
}

export type LabFlag = 'Normal' | 'High' | 'Low';

export interface LabParameter {
  name: string;
  value: string;
  unit: string;
  referenceRange: string;
  flag: LabFlag;
}

export type LabStatus = 'Requested' | 'Available' | 'Uploaded';

export interface LabReport {
  id: ID;
  patientId: ID;
  orderedById?: ID;
  testName: string;
  category: string;
  date: ISODate;
  status: LabStatus;
  labName: string;
  parameters: LabParameter[];
  file?: StoredFile;
  comments?: string;
}

export interface StoredFile {
  id: ID;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  uploadedAt: ISODateTime;
  /** In production: a short-lived Azure Blob SAS URL, never a public link. */
  url?: string;
  textContent?: string;
}

export type NotificationKind =
  | 'appointment_confirmed'
  | 'appointment_reminder'
  | 'appointment_cancelled'
  | 'lab_available'
  | 'lab_requested'
  | 'prescription_added'
  | 'follow_up'
  | 'system';

export type NotificationChannel = 'In-app' | 'Email' | 'SMS' | 'Push';

export interface AppNotification {
  id: ID;
  userId: ID;
  kind: NotificationKind;
  title: string;
  message: string;
  createdAt: ISODateTime;
  read: boolean;
  channels: NotificationChannel[];
  link?: string;
}

export interface AuditEntry {
  id: ID;
  at: ISODateTime;
  actorId: ID;
  actorName: string;
  role: Role;
  action: string;
  entity: string;
  entityId?: ID;
}

export interface AppConfig {
  organizationName: string;
  slotMinutes: number;
  autoConfirmBookings: boolean;
  bookingWindowDays: number;
  aiAssistantEnabled: boolean;
  channels: Record<NotificationChannel, boolean>;
  reminderHoursBefore: number;
}

/* ---------- AI document assistant ---------- */

export interface SampleDocument {
  id: ID;
  title: string;
  kind: string;
  date: ISODate;
  text: string;
}

export interface AIExtraction {
  documentTitle: string;
  documentType: string;
  keyInformation: { label: string; value: string }[];
  plainLanguageSummary: string;
  importantDates: { date: string; context: string }[];
  medications: { name: string; detail: string }[];
  labValues: { name: string; value: string; referenceRange?: string; outsideRange: boolean }[];
  attentionItems: { title: string; detail: string }[];
  model: string;
  generatedAt: ISODateTime;
  disclaimer: string;
}
