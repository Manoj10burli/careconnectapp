import { createContext, ReactNode, useContext, useState } from 'react';
import { services } from '@/services';
import type { Role, Session, UserAccount } from '@/types';

interface AuthState {
  session: Session | null;
  user: UserAccount | null;
  login: (email: string, password: string, role: Role) => Promise<void>;
  demoLogin: (role: Role) => Promise<void>;
  logout: () => Promise<void>;
}

const Ctx = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(services.auth.getSession());
  const value: AuthState = {
    session,
    user: session?.user ?? null,
    login: async (e, p, r) => setSession(await services.auth.login(e, p, r)),
    demoLogin: async (r) => setSession(await services.auth.demoLogin(r)),
    logout: async () => { await services.auth.logout(); setSession(null); },
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export const useAuth = () => {
  const c = useContext(Ctx);
  if (!c) throw new Error('useAuth must be used inside AuthProvider');
  return c;
};

/** Current user's profile id — patient or doctor id. */
export const useProfileId = () => useAuth().user?.profileId ?? '';
