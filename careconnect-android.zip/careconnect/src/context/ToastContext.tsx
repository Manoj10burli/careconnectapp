import { createContext, ReactNode, useCallback, useContext, useState } from 'react';
import { CheckCircle2, Info, XCircle } from 'lucide-react';
import { haptic } from '@/platform/native';

type Tone = 'success' | 'error' | 'info';
interface Toast { id: number; tone: Tone; title: string; body?: string }

const Ctx = createContext<(t: Omit<Toast, 'id'>) => void>(() => {});

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const push = useCallback((t: Omit<Toast, 'id'>) => {
    const id = Date.now() + Math.random();
    if (t.tone !== 'info') haptic(t.tone === 'success' ? 'success' : 'warning');
    setToasts((x) => [...x, { ...t, id }]);
    setTimeout(() => setToasts((x) => x.filter((y) => y.id !== id)), 4200);
  }, []);
  const icon = { success: <CheckCircle2 className="h-5 w-5 text-teal-500" />, error: <XCircle className="h-5 w-5 text-alert-600" />, info: <Info className="h-5 w-5 text-care-500" /> };
  return (
    <Ctx.Provider value={push}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 bottom-20 z-[70] flex flex-col items-center gap-2 px-4 md:bottom-6 md:items-end md:pr-6" aria-live="polite">
        {toasts.map((t) => (
          <div key={t.id} className="rise pointer-events-auto flex w-full max-w-sm gap-3 rounded-item border border-line bg-white p-3.5 shadow-lg shadow-ink/10">
            {icon[t.tone]}
            <div className="min-w-0">
              <p className="text-sm font-semibold text-ink">{t.title}</p>
              {t.body && <p className="mt-0.5 text-sm text-ink-soft">{t.body}</p>}
            </div>
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}

export const useToast = () => useContext(Ctx);
