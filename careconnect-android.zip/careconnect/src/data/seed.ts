/**
 * DEMO SEED DATA — every person, number and clinical value below is fictional.
 * Dates are generated relative to "today" so the demo always looks current.
 */
import type {
  AppConfig, AppNotification, Appointment, AuditEntry, Department, Doctor, LabReport,
  MedicalRecord, Patient, Prescription, UserAccount,
} from '@/types';
import { addDays } from '@/utils/format';

const iso = (daysAgo: number, hour = 9) => {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  d.setHours(hour, 15, 0, 0);
  return d.toISOString();
};

export const departments: Department[] = [
  { id: 'DEP-GM', name: 'General Medicine', description: 'Primary care, routine check-ups and common illnesses', location: 'Block A, Ground floor', active: true },
  { id: 'DEP-CAR', name: 'Cardiology', description: 'Heart and blood vessel care', location: 'Block B, 2nd floor', active: true },
  { id: 'DEP-END', name: 'Endocrinology', description: 'Diabetes, thyroid and hormone care', location: 'Block B, 1st floor', active: true },
  { id: 'DEP-ORT', name: 'Orthopedics', description: 'Bones, joints and sports injuries', location: 'Block C, Ground floor', active: true },
  { id: 'DEP-DER', name: 'Dermatology', description: 'Skin, hair and nail care', location: 'Block A, 1st floor', active: true },
  { id: 'DEP-PED', name: 'Pediatrics', description: 'Care for children and adolescents', location: 'Block D, Ground floor', active: true },
];

const std = ['09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '12:00', '14:00', '14:30', '15:00', '15:30', '16:00', '16:30'];
const everyDay = [0, 1, 2, 3, 4, 5, 6]; // demo: available all week so the walkthrough never hits a closed day

export const doctors: Doctor[] = [
  { id: 'D001', name: 'Dr. Arjun Menon', departmentId: 'DEP-GM', specialization: 'Family Physician', qualification: 'MBBS, MD (Demo)', experienceYears: 14, email: 'arjun.menon@careconnect.demo', phone: '+91 90000 10001', workingDays: everyDay, slots: std, active: true, room: 'A-04' },
  { id: 'D002', name: 'Dr. Meera Iyer', departmentId: 'DEP-CAR', specialization: 'Cardiologist', qualification: 'MBBS, DM Cardiology (Demo)', experienceYears: 18, email: 'meera.iyer@careconnect.demo', phone: '+91 90000 10002', workingDays: [1, 2, 3, 4, 5], slots: std, active: true, room: 'B-21' },
  { id: 'D003', name: 'Dr. Sarah Thomas', departmentId: 'DEP-END', specialization: 'Endocrinologist', qualification: 'MBBS, DM Endocrinology (Demo)', experienceYears: 11, email: 'sarah.thomas@careconnect.demo', phone: '+91 90000 10003', workingDays: [1, 3, 5, 6], slots: std, active: true, room: 'B-12' },
  { id: 'D004', name: 'Dr. Rahul Deshpande', departmentId: 'DEP-ORT', specialization: 'Orthopedic Surgeon', qualification: 'MBBS, MS Ortho (Demo)', experienceYears: 16, email: 'rahul.deshpande@careconnect.demo', phone: '+91 90000 10004', workingDays: [1, 2, 4, 5, 6], slots: std, active: true, room: 'C-03' },
  { id: 'D005', name: 'Dr. Kavya Nair', departmentId: 'DEP-DER', specialization: 'Dermatologist', qualification: 'MBBS, MD Dermatology (Demo)', experienceYears: 9, email: 'kavya.nair@careconnect.demo', phone: '+91 90000 10005', workingDays: [2, 3, 4, 6], slots: std, active: true, room: 'A-15' },
  { id: 'D006', name: 'Dr. Fatima Sheikh', departmentId: 'DEP-PED', specialization: 'Pediatrician', qualification: 'MBBS, MD Pediatrics (Demo)', experienceYears: 12, email: 'fatima.sheikh@careconnect.demo', phone: '+91 90000 10006', workingDays: [1, 2, 3, 4, 5, 6], slots: std, active: true, room: 'D-02' },
];

export const patients: Patient[] = [
  { id: 'P001', mrn: 'CC-DEMO-10001', name: 'Priya Sharma', dob: '1991-03-14', gender: 'Female', bloodGroup: 'B+', phone: '+91 98000 00001', email: 'priya.sharma@example.demo', address: '12 Lakeview Residency, Vidyanagar (fictional)', allergies: ['Penicillin'], conditions: ['Seasonal allergies'], emergencyContact: { name: 'Nikhil Sharma', relation: 'Spouse', phone: '+91 98000 00101' }, primaryDoctorId: 'D001', heightCm: 162, weightKg: 58 },
  { id: 'P002', mrn: 'CC-DEMO-10002', name: 'Rohan Verma', dob: '1985-07-22', gender: 'Male', bloodGroup: 'O+', phone: '+91 98000 00002', email: 'rohan.verma@example.demo', address: '44 Green Park Colony (fictional)', allergies: [], conditions: ['Hypertension (on review)'], emergencyContact: { name: 'Anita Verma', relation: 'Sister', phone: '+91 98000 00102' }, primaryDoctorId: 'D001', heightCm: 176, weightKg: 82 },
  { id: 'P003', mrn: 'CC-DEMO-10003', name: 'Aisha Khan', dob: '1978-11-05', gender: 'Female', bloodGroup: 'A+', phone: '+91 98000 00003', email: 'aisha.khan@example.demo', address: '7 Rosewood Lane (fictional)', allergies: ['Sulfa drugs'], conditions: ['Type 2 diabetes'], emergencyContact: { name: 'Salman Khan', relation: 'Husband', phone: '+91 98000 00103' }, primaryDoctorId: 'D003', heightCm: 158, weightKg: 70 },
  { id: 'P004', mrn: 'CC-DEMO-10004', name: 'David Fernandes', dob: '1962-02-18', gender: 'Male', bloodGroup: 'AB+', phone: '+91 98000 00004', email: 'david.fernandes@example.demo', address: '3 Harbour View Road (fictional)', allergies: [], conditions: ['Coronary artery disease (stable)'], emergencyContact: { name: 'Clara Fernandes', relation: 'Wife', phone: '+91 98000 00104' }, primaryDoctorId: 'D002', heightCm: 172, weightKg: 79 },
  { id: 'P005', mrn: 'CC-DEMO-10005', name: 'Lakshmi Hegde', dob: '1956-09-30', gender: 'Female', bloodGroup: 'O-', phone: '+91 98000 00005', email: 'lakshmi.hegde@example.demo', address: '21 Temple Street (fictional)', allergies: ['Aspirin'], conditions: ['Osteoarthritis, knee'], emergencyContact: { name: 'Suresh Hegde', relation: 'Son', phone: '+91 98000 00105' }, primaryDoctorId: 'D004', heightCm: 155, weightKg: 64 },
  { id: 'P006', mrn: 'CC-DEMO-10006', name: 'Karthik Rao', dob: '1999-12-01', gender: 'Male', bloodGroup: 'B-', phone: '+91 98000 00006', email: 'karthik.rao@example.demo', address: '9 College Road (fictional)', allergies: [], conditions: [], emergencyContact: { name: 'Geetha Rao', relation: 'Mother', phone: '+91 98000 00106' }, primaryDoctorId: 'D001', heightCm: 180, weightKg: 74 },
  { id: 'P007', mrn: 'CC-DEMO-10007', name: 'Sneha Patil', dob: '1994-05-17', gender: 'Female', bloodGroup: 'A-', phone: '+91 98000 00007', email: 'sneha.patil@example.demo', address: '58 Sunrise Apartments (fictional)', allergies: ['Latex'], conditions: ['Eczema'], emergencyContact: { name: 'Ajay Patil', relation: 'Brother', phone: '+91 98000 00107' }, primaryDoctorId: 'D005', heightCm: 165, weightKg: 56 },
  { id: 'P008', mrn: 'CC-DEMO-10008', name: 'Vikram Joshi', dob: '1970-08-09', gender: 'Male', bloodGroup: 'O+', phone: '+91 98000 00008', email: 'vikram.joshi@example.demo', address: '16 Station Road (fictional)', allergies: [], conditions: ['High cholesterol'], emergencyContact: { name: 'Pooja Joshi', relation: 'Wife', phone: '+91 98000 00108' }, primaryDoctorId: 'D001', heightCm: 170, weightKg: 88 },
  { id: 'P009', mrn: 'CC-DEMO-10009', name: "Maria D'Souza", dob: '1988-01-26', gender: 'Female', bloodGroup: 'B+', phone: '+91 98000 00009', email: 'maria.dsouza@example.demo', address: '2 Church Lane (fictional)', allergies: [], conditions: ['Hypothyroidism'], emergencyContact: { name: "Joseph D'Souza", relation: 'Father', phone: '+91 98000 00109' }, primaryDoctorId: 'D003', heightCm: 160, weightKg: 61 },
  { id: 'P010', mrn: 'CC-DEMO-10010', name: 'Imran Qureshi', dob: '2014-06-11', gender: 'Male', bloodGroup: 'A+', phone: '+91 98000 00010', email: 'guardian.qureshi@example.demo', address: '30 Park Avenue (fictional)', allergies: ['Peanuts'], conditions: ['Mild asthma'], emergencyContact: { name: 'Rizwan Qureshi', relation: 'Father', phone: '+91 98000 00110' }, primaryDoctorId: 'D006', heightCm: 140, weightKg: 34 },
];

export const users: UserAccount[] = [
  ...patients.map<UserAccount>((p) => ({ id: `U-${p.id}`, role: 'patient', name: p.name, email: p.email, phone: p.phone, active: true, profileId: p.id })),
  ...doctors.map<UserAccount>((d) => ({ id: `U-${d.id}`, role: 'doctor', name: d.name, email: d.email, phone: d.phone, active: true, profileId: d.id })),
  { id: 'U-ADM1', role: 'admin', name: 'Neha Kulkarni', email: 'admin@careconnect.demo', phone: '+91 90000 19999', active: true },
  { id: 'U-ADM2', role: 'admin', name: 'Sanjay Bhat', email: 'ops@careconnect.demo', phone: '+91 90000 19998', active: false },
];

const dep = (doctorId: string) => doctors.find((d) => d.id === doctorId)!.departmentId;
const appt = (id: string, patientId: string, doctorId: string, dayOffset: number, time: string, reason: string, status: Appointment['status'], type: Appointment['type'] = 'In-person'): Appointment => ({
  id, patientId, doctorId, departmentId: dep(doctorId), date: addDays(dayOffset), time, reason, status, type, createdAt: iso(Math.max(1, -dayOffset + 7)),
});

export const appointments: Appointment[] = [
  // Priya Sharma (demo patient)
  appt('A001', 'P001', 'D001', -120, '10:00', 'Sneezing and runny nose for two weeks', 'Completed'),
  appt('A002', 'P001', 'D001', -45, '11:30', 'Tiredness and body ache', 'Completed'),
  appt('A003', 'P001', 'D003', -30, '09:30', 'Review of blood test results', 'Completed'),
  appt('A004', 'P001', 'D002', 6, '10:30', 'Routine heart check-up', 'Confirmed'),
  appt('A005', 'P001', 'D005', -60, '15:00', 'Skin rash on forearm', 'Cancelled'),
  // Dr. Arjun Menon — today
  appt('A006', 'P006', 'D001', 0, '09:00', 'Fever and sore throat', 'Completed'),
  appt('A007', 'P002', 'D001', 0, '09:30', 'Blood pressure follow-up', 'Confirmed'),
  appt('A008', 'P008', 'D001', 0, '11:00', 'Cholesterol report review', 'Confirmed', 'Video'),
  appt('A009', 'P004', 'D001', 0, '14:30', 'Persistent cough', 'Confirmed'),
  appt('A010', 'P009', 'D001', 0, '16:00', 'General health check', 'Pending'),
  // Other doctors — today
  appt('A011', 'P004', 'D002', 0, '10:00', 'Cardiac review', 'Confirmed'),
  appt('A012', 'P003', 'D003', 0, '11:30', 'Diabetes follow-up', 'Confirmed'),
  appt('A013', 'P005', 'D004', 0, '12:00', 'Knee pain review', 'Pending'),
  appt('A014', 'P010', 'D006', 0, '15:30', 'Asthma follow-up', 'Confirmed'),
  // Upcoming
  appt('A015', 'P007', 'D005', 2, '14:00', 'Eczema flare-up', 'Confirmed'),
  appt('A016', 'P002', 'D002', 3, '09:00', 'ECG review', 'Pending'),
  appt('A017', 'P009', 'D003', 4, '10:30', 'Thyroid follow-up', 'Confirmed', 'Video'),
  appt('A018', 'P006', 'D004', 5, '16:30', 'Sports injury, ankle', 'Pending'),
  appt('A019', 'P008', 'D001', 9, '11:30', 'Lifestyle follow-up', 'Confirmed'),
  // Past
  appt('A020', 'P003', 'D003', -21, '10:00', 'Quarterly diabetes review', 'Completed'),
  appt('A021', 'P005', 'D004', -14, '11:00', 'Knee pain', 'Completed'),
  appt('A022', 'P007', 'D005', -35, '14:30', 'Dry skin patches', 'Completed'),
  appt('A023', 'P002', 'D001', -28, '10:30', 'Headache and high BP reading', 'Completed'),
  appt('A024', 'P010', 'D006', -18, '09:30', 'Wheezing at night', 'Completed'),
];

export const prescriptions: Prescription[] = [
  { id: 'RX001', patientId: 'P001', doctorId: 'D001', date: addDays(-120), status: 'Completed', medications: [{ name: 'Cetirizine 10 mg (demo)', dosage: '1 tablet', frequency: 'Once daily at night', duration: '10 days' }], notes: 'Demo prescription.' },
  { id: 'RX002', patientId: 'P001', doctorId: 'D001', date: addDays(-45), status: 'Completed', medications: [{ name: 'Paracetamol 500 mg (demo)', dosage: '1 tablet', frequency: 'Up to 3 times daily if needed', duration: '5 days' }] },
  { id: 'RX003', patientId: 'P001', doctorId: 'D003', date: addDays(-30), status: 'Active', medications: [{ name: 'Cholecalciferol 60,000 IU (demo)', dosage: '1 sachet', frequency: 'Once weekly', duration: '8 weeks', instructions: 'Take with milk after a meal' }, { name: 'Calcium carbonate 500 mg (demo)', dosage: '1 tablet', frequency: 'Once daily after lunch', duration: '8 weeks' }] },
  { id: 'RX004', patientId: 'P002', doctorId: 'D001', date: addDays(-28), status: 'Active', medications: [{ name: 'Amlodipine 5 mg (demo)', dosage: '1 tablet', frequency: 'Once daily in the morning', duration: '30 days' }] },
  { id: 'RX005', patientId: 'P003', doctorId: 'D003', date: addDays(-21), status: 'Active', medications: [{ name: 'Metformin 500 mg (demo)', dosage: '1 tablet', frequency: 'Twice daily with meals', duration: '90 days' }] },
  { id: 'RX006', patientId: 'P004', doctorId: 'D002', date: addDays(-40), status: 'Active', medications: [{ name: 'Atorvastatin 20 mg (demo)', dosage: '1 tablet', frequency: 'Once daily at night', duration: '90 days' }, { name: 'Aspirin 75 mg (demo)', dosage: '1 tablet', frequency: 'Once daily after lunch', duration: '90 days' }] },
  { id: 'RX007', patientId: 'P005', doctorId: 'D004', date: addDays(-14), status: 'Active', medications: [{ name: 'Diclofenac gel 1% (demo)', dosage: 'Thin layer', frequency: 'Twice daily on knee', duration: '14 days' }] },
  { id: 'RX008', patientId: 'P007', doctorId: 'D005', date: addDays(-35), status: 'Completed', medications: [{ name: 'Emollient cream (demo)', dosage: 'Apply liberally', frequency: '3 times daily', duration: '21 days' }] },
  { id: 'RX009', patientId: 'P010', doctorId: 'D006', date: addDays(-18), status: 'Active', medications: [{ name: 'Salbutamol inhaler 100 mcg (demo)', dosage: '1–2 puffs', frequency: 'When needed for wheeze', duration: '30 days' }] },
  { id: 'RX010', patientId: 'P009', doctorId: 'D003', date: addDays(-50), status: 'Active', medications: [{ name: 'Levothyroxine 50 mcg (demo)', dosage: '1 tablet', frequency: 'Once daily, empty stomach', duration: '90 days' }] },
  { id: 'RX011', patientId: 'P006', doctorId: 'D001', date: addDays(0), status: 'Active', medications: [{ name: 'Paracetamol 650 mg (demo)', dosage: '1 tablet', frequency: 'Up to 3 times daily if needed', duration: '3 days' }] },
];

export const medicalRecords: MedicalRecord[] = [
  { id: 'MR001', patientId: 'P001', doctorId: 'D001', appointmentId: 'A001', date: addDays(-120), chiefComplaint: 'Sneezing and runny nose for two weeks', consultationNotes: 'Symptoms worse in the mornings. No fever. Throat mildly congested.', diagnosisByDoctor: 'Seasonal allergic rhinitis (demo entry)', prescriptionId: 'RX001', labTests: [], followUp: addDays(-106), vitals: { bp: '118/76', pulse: 74, tempC: 36.8, spo2: 99 } },
  { id: 'MR002', patientId: 'P001', doctorId: 'D001', appointmentId: 'A002', date: addDays(-45), chiefComplaint: 'Tiredness and body ache', consultationNotes: 'Reports low energy for a month. Advised blood tests and referral to endocrinology for review.', diagnosisByDoctor: 'Fatigue — under evaluation (demo entry)', prescriptionId: 'RX002', labTests: ['Complete Blood Count', 'Lipid Profile', 'Blood Sugar & Vitals Panel', 'Vitamin D (25-OH)'], followUp: addDays(-30), vitals: { bp: '116/74', pulse: 78, tempC: 37.0, spo2: 98 } },
  { id: 'MR003', patientId: 'P001', doctorId: 'D003', appointmentId: 'A003', date: addDays(-30), chiefComplaint: 'Review of blood test results', consultationNotes: 'Reviewed reports with patient. Vitamin D below reference range per lab report.', diagnosisByDoctor: 'Vitamin D deficiency (demo entry)', prescriptionId: 'RX003', labTests: [], followUp: addDays(26), vitals: { bp: '120/78', pulse: 72, tempC: 36.7, spo2: 99 } },
  { id: 'MR004', patientId: 'P002', doctorId: 'D001', appointmentId: 'A023', date: addDays(-28), chiefComplaint: 'Headache and high BP reading at home', consultationNotes: 'Home readings logged by patient. Lifestyle discussion done.', diagnosisByDoctor: 'Elevated blood pressure — monitoring (demo entry)', prescriptionId: 'RX004', labTests: ['Kidney Function Test'], followUp: addDays(0), vitals: { bp: '148/94', pulse: 82, tempC: 36.9, spo2: 98 } },
  { id: 'MR005', patientId: 'P003', doctorId: 'D003', appointmentId: 'A020', date: addDays(-21), chiefComplaint: 'Quarterly diabetes review', consultationNotes: 'Diet diary reviewed. Continues current plan.', diagnosisByDoctor: 'Type 2 diabetes — routine review (demo entry)', prescriptionId: 'RX005', labTests: ['HbA1c'], followUp: addDays(0) },
  { id: 'MR006', patientId: 'P004', doctorId: 'D002', date: addDays(-40), chiefComplaint: 'Routine cardiac follow-up', consultationNotes: 'No chest discomfort reported. ECG on file.', diagnosisByDoctor: 'Stable coronary artery disease (demo entry)', prescriptionId: 'RX006', labTests: ['Lipid Profile'], followUp: addDays(0) },
  { id: 'MR007', patientId: 'P005', doctorId: 'D004', appointmentId: 'A021', date: addDays(-14), chiefComplaint: 'Right knee pain on climbing stairs', consultationNotes: 'Mild swelling. Advised physiotherapy exercises.', diagnosisByDoctor: 'Osteoarthritis, right knee (demo entry)', prescriptionId: 'RX007', labTests: ['X-ray Knee (AP/Lateral)'], followUp: addDays(0) },
  { id: 'MR008', patientId: 'P007', doctorId: 'D005', appointmentId: 'A022', date: addDays(-35), chiefComplaint: 'Dry, itchy skin patches', consultationNotes: 'Patches on elbows. Advised gentle skincare routine.', diagnosisByDoctor: 'Atopic eczema (demo entry)', prescriptionId: 'RX008', labTests: [], followUp: addDays(2) },
  { id: 'MR009', patientId: 'P010', doctorId: 'D006', appointmentId: 'A024', date: addDays(-18), chiefComplaint: 'Wheezing at night', consultationNotes: 'Parent reports symptoms after outdoor play. Inhaler technique taught.', diagnosisByDoctor: 'Mild intermittent asthma (demo entry)', prescriptionId: 'RX009', labTests: [], followUp: addDays(0) },
  { id: 'MR010', patientId: 'P009', doctorId: 'D003', date: addDays(-50), chiefComplaint: 'Thyroid review', consultationNotes: 'Stable on current dose. Repeat TSH in 6 weeks.', diagnosisByDoctor: 'Hypothyroidism — stable (demo entry)', prescriptionId: 'RX010', labTests: ['Thyroid Profile'], followUp: addDays(4) },
  { id: 'MR011', patientId: 'P008', doctorId: 'D001', date: addDays(-60), chiefComplaint: 'Annual health check', consultationNotes: 'Advised lipid profile. Diet counselling given.', diagnosisByDoctor: 'Raised cholesterol — monitoring (demo entry)', labTests: ['Lipid Profile'], followUp: addDays(0) },
];

const P = (name: string, value: string, unit: string, referenceRange: string, flag: 'Normal' | 'High' | 'Low' = 'Normal') => ({ name, value, unit, referenceRange, flag });

export const labReports: LabReport[] = [
  { id: 'LR001', patientId: 'P001', orderedById: 'D001', testName: 'Complete Blood Count', category: 'Hematology', date: addDays(-32), status: 'Available', labName: 'CareConnect Central Lab (Demo)', parameters: [P('Hemoglobin', '11.8', 'g/dL', '12.0 – 15.5', 'Low'), P('WBC count', '7,200', '/µL', '4,000 – 11,000'), P('Platelets', '2.6', 'lakh/µL', '1.5 – 4.0'), P('RBC count', '4.3', 'million/µL', '4.0 – 5.2')] },
  { id: 'LR002', patientId: 'P001', orderedById: 'D001', testName: 'Lipid Profile', category: 'Biochemistry', date: addDays(-32), status: 'Available', labName: 'CareConnect Central Lab (Demo)', parameters: [P('Total cholesterol', '186', 'mg/dL', '< 200'), P('LDL cholesterol', '112', 'mg/dL', '< 130'), P('HDL cholesterol', '52', 'mg/dL', '> 45'), P('Triglycerides', '128', 'mg/dL', '< 150')] },
  { id: 'LR003', patientId: 'P001', orderedById: 'D001', testName: 'Blood Sugar & Vitals Panel', category: 'Biochemistry', date: addDays(-32), status: 'Available', labName: 'CareConnect Central Lab (Demo)', parameters: [P('Fasting glucose', '94', 'mg/dL', '70 – 99'), P('HbA1c', '5.4', '%', '< 5.7'), P('Blood pressure', '118/76', 'mmHg', '< 120/80')] },
  { id: 'LR004', patientId: 'P001', orderedById: 'D001', testName: 'Vitamin D (25-OH)', category: 'Biochemistry', date: addDays(-31), status: 'Available', labName: 'CareConnect Central Lab (Demo)', parameters: [P('25-OH Vitamin D', '14.2', 'ng/mL', '30 – 100', 'Low')] },
  { id: 'LR005', patientId: 'P002', orderedById: 'D001', testName: 'Kidney Function Test', category: 'Biochemistry', date: addDays(-26), status: 'Available', labName: 'CareConnect Central Lab (Demo)', parameters: [P('Creatinine', '0.9', 'mg/dL', '0.7 – 1.3'), P('Urea', '28', 'mg/dL', '15 – 40'), P('Blood pressure', '146/92', 'mmHg', '< 120/80', 'High')] },
  { id: 'LR006', patientId: 'P003', orderedById: 'D003', testName: 'HbA1c', category: 'Biochemistry', date: addDays(-22), status: 'Available', labName: 'CareConnect Central Lab (Demo)', parameters: [P('HbA1c', '7.2', '%', '< 5.7', 'High'), P('Fasting glucose', '138', 'mg/dL', '70 – 99', 'High')] },
  { id: 'LR007', patientId: 'P004', orderedById: 'D002', testName: 'Lipid Profile', category: 'Biochemistry', date: addDays(-41), status: 'Available', labName: 'CareConnect Central Lab (Demo)', parameters: [P('Total cholesterol', '168', 'mg/dL', '< 200'), P('LDL cholesterol', '88', 'mg/dL', '< 100'), P('HDL cholesterol', '44', 'mg/dL', '> 40'), P('Triglycerides', '142', 'mg/dL', '< 150')] },
  { id: 'LR008', patientId: 'P008', orderedById: 'D001', testName: 'Lipid Profile', category: 'Biochemistry', date: addDays(-58), status: 'Available', labName: 'CareConnect Central Lab (Demo)', parameters: [P('Total cholesterol', '242', 'mg/dL', '< 200', 'High'), P('LDL cholesterol', '164', 'mg/dL', '< 130', 'High'), P('HDL cholesterol', '38', 'mg/dL', '> 40', 'Low'), P('Triglycerides', '196', 'mg/dL', '< 150', 'High')] },
  { id: 'LR009', patientId: 'P009', orderedById: 'D003', testName: 'Thyroid Profile', category: 'Endocrinology', date: addDays(-51), status: 'Available', labName: 'CareConnect Central Lab (Demo)', parameters: [P('TSH', '3.1', 'µIU/mL', '0.4 – 4.0'), P('Free T4', '1.2', 'ng/dL', '0.8 – 1.8')] },
  { id: 'LR010', patientId: 'P005', orderedById: 'D004', testName: 'X-ray Knee (AP/Lateral)', category: 'Radiology', date: addDays(-13), status: 'Available', labName: 'CareConnect Imaging (Demo)', parameters: [], comments: 'Radiology report text available in PDF (demo).' },
  { id: 'LR011', patientId: 'P007', orderedById: 'D005', testName: 'Complete Blood Count', category: 'Hematology', date: addDays(-34), status: 'Available', labName: 'CareConnect Central Lab (Demo)', parameters: [P('Hemoglobin', '13.1', 'g/dL', '12.0 – 15.5'), P('WBC count', '6,400', '/µL', '4,000 – 11,000'), P('Eosinophils', '7', '%', '1 – 6', 'High')] },
];

const n = (id: string, userId: string, kind: AppNotification['kind'], title: string, message: string, daysAgo: number, read: boolean, link?: string, hour = 9): AppNotification => ({
  id, userId, kind, title, message, createdAt: iso(daysAgo, hour), read, channels: ['In-app', 'Email'], link,
});

export const notifications: AppNotification[] = [
  n('N001', 'U-P001', 'appointment_confirmed', 'Appointment confirmed', `Your appointment with Dr. Meera Iyer (Cardiology) is confirmed for ${addDays(6)} at 10:30 AM.`, 2, false, '/appointments'),
  n('N002', 'U-P001', 'appointment_reminder', 'Upcoming appointment', 'Reminder: Routine heart check-up with Dr. Meera Iyer in 6 days. Please arrive 15 minutes early.', 0, false, '/appointments', 8),
  n('N003', 'U-P001', 'lab_available', 'Lab report available', 'Your Vitamin D (25-OH) report is ready to view.', 31, true, '/lab-reports'),
  n('N004', 'U-P001', 'prescription_added', 'New prescription added', 'Dr. Sarah Thomas added a prescription with 2 medicines.', 30, true, '/prescriptions'),
  n('N005', 'U-P001', 'follow_up', 'Follow-up due soon', 'Your follow-up with Dr. Sarah Thomas (Endocrinology) is due in about 4 weeks. Book a slot when convenient.', 5, false, '/appointments/book'),
  n('N006', 'U-P001', 'lab_available', 'Lab reports available', 'Complete Blood Count, Lipid Profile and Blood Sugar Panel results are ready.', 32, true, '/lab-reports'),
  n('N007', 'U-P001', 'system', 'Profile check', 'Please confirm your emergency contact details are current.', 12, true, '/profile'),
  n('N008', 'U-D001', 'appointment_confirmed', 'New booking', 'Maria D\u2019Souza requested a General health check today at 4:00 PM.', 1, false, '/doctor/appointments'),
  n('N009', 'U-D001', 'lab_available', 'Lab result received', 'Kidney Function Test for Rohan Verma is available.', 26, true, '/doctor/patients/P002'),
  n('N010', 'U-D001', 'follow_up', 'Follow-ups today', '3 of your patients have follow-ups due today.', 0, false, '/doctor', 7),
  n('N011', 'U-ADM1', 'system', 'Pending approvals', 'There are appointment requests waiting for confirmation.', 0, false, '/admin/appointments', 8),
  n('N012', 'U-ADM1', 'system', 'Nightly backup completed', 'Demo backup job finished successfully (simulated).', 1, true, '/admin/settings', 2),
  n('N013', 'U-P002', 'appointment_reminder', 'Appointment today', 'Blood pressure follow-up with Dr. Arjun Menon today at 9:30 AM.', 0, false, '/appointments', 7),
];

export const auditLog: AuditEntry[] = [
  { id: 'AU001', at: iso(1, 18), actorId: 'U-ADM1', actorName: 'Neha Kulkarni', role: 'admin', action: 'Updated configuration', entity: 'AppConfig' },
  { id: 'AU002', at: iso(1, 11), actorId: 'U-D003', actorName: 'Dr. Sarah Thomas', role: 'doctor', action: 'Viewed patient record', entity: 'Patient', entityId: 'P009' },
  { id: 'AU003', at: iso(2, 10), actorId: 'U-P001', actorName: 'Priya Sharma', role: 'patient', action: 'Viewed lab report', entity: 'LabReport', entityId: 'LR004' },
];

export const defaultConfig: AppConfig = {
  organizationName: 'CareConnect Demo Hospital',
  slotMinutes: 30,
  autoConfirmBookings: true,
  bookingWindowDays: 30,
  aiAssistantEnabled: true,
  channels: { 'In-app': true, Email: true, SMS: false, Push: true },
  reminderHoursBefore: 24,
};
