/** SAMPLE documents for the AI Health Document Assistant. Entirely fictional. */
import type { AIExtraction, SampleDocument } from '@/types';
import { addDays, fmtDate } from '@/utils/format';

const d = (n: number) => fmtDate(addDays(n));

export const sampleDocuments: SampleDocument[] = [
  {
    id: 'DOC-LAB',
    title: 'Lab report — Metabolic & vitamin panel',
    kind: 'Laboratory report',
    date: addDays(-31),
    text: `CARECONNECT CENTRAL LAB (DEMO) — SAMPLE REPORT — NOT A REAL PATIENT
Patient: Priya Sharma (DEMO)   MRN: CC-DEMO-10001   Age/Sex: 35/F
Referred by: Dr. Arjun Menon   Sample collected: ${d(-32)}   Reported: ${d(-31)}

TEST                      RESULT     UNIT         REFERENCE RANGE
Hemoglobin                11.8  L    g/dL         12.0 - 15.5
Fasting glucose           94         mg/dL        70 - 99
HbA1c                     5.4        %            < 5.7
Total cholesterol         186        mg/dL        < 200
LDL cholesterol           112        mg/dL        < 130
HDL cholesterol           52         mg/dL        > 45
25-OH Vitamin D           14.2  L    ng/mL        30 - 100
Blood pressure (recorded) 118/76     mmHg         < 120/80

Remarks: Results flagged L are below the laboratory reference range.
Please correlate clinically. Repeat testing as advised by treating physician.
Current medication declared by patient: Paracetamol 500 mg as needed.`,
  },
  {
    id: 'DOC-CONSULT',
    title: 'Consultation letter — Endocrinology',
    kind: 'Consultation letter',
    date: addDays(-30),
    text: `CARECONNECT DEMO HOSPITAL — ENDOCRINOLOGY — SAMPLE LETTER
To: Dr. Arjun Menon, General Medicine
Re: Priya Sharma (DEMO), MRN CC-DEMO-10001
Date of consultation: ${d(-30)}

Thank you for referring Ms Sharma, who reports tiredness for about a month.
Reports dated ${d(-31)} reviewed. 25-OH Vitamin D 14.2 ng/mL (ref 30-100).
Hemoglobin 11.8 g/dL (ref 12.0-15.5).

Doctor's assessment (entered by treating doctor): Vitamin D deficiency.
Plan as documented by the doctor:
 - Cholecalciferol 60,000 IU once weekly for 8 weeks
 - Calcium carbonate 500 mg once daily after lunch for 8 weeks
 - Repeat Vitamin D and CBC after 8 weeks
Follow-up appointment: ${d(26)}

Allergy on record: Penicillin.
Dr. Sarah Thomas, Endocrinology (DEMO)`,
  },
  {
    id: 'DOC-DISCHARGE',
    title: 'Discharge summary — Day care',
    kind: 'Discharge summary',
    date: addDays(-75),
    text: `CARECONNECT DEMO HOSPITAL — DAY CARE DISCHARGE SUMMARY — SAMPLE
Patient: Rohan Verma (DEMO)   MRN: CC-DEMO-10002
Admitted: ${d(-76)}   Discharged: ${d(-75)}
Treating doctor: Dr. Arjun Menon

Reason for visit: Dizziness and headache, BP recorded 162/100 mmHg at triage.
Observations: BP on discharge 138/88 mmHg. Pulse 80/min. SpO2 98%.
Investigations: Creatinine 0.9 mg/dL (0.7-1.3). Sodium 139 mmol/L (135-145).
Potassium 4.1 mmol/L (3.5-5.1). ECG: documented in chart.

Medications on discharge (as prescribed by doctor):
 - Amlodipine 5 mg once daily in the morning for 30 days
Advice documented: Home BP log twice daily. Return if severe headache,
chest pain or vision changes.
Review in OPD on: ${d(-61)}`,
  },
];

const DISCLAIMER = 'AI-generated information is for demonstration and information purposes only and is not medical advice.';

/** Hand-written "model output" so the demo works offline. */
export const cannedExtractions: Record<string, Omit<AIExtraction, 'generatedAt' | 'model' | 'disclaimer'>> = {
  'DOC-LAB': {
    documentTitle: 'Lab report — Metabolic & vitamin panel',
    documentType: 'Laboratory report',
    keyInformation: [
      { label: 'Patient', value: 'Priya Sharma (DEMO), 35 F' },
      { label: 'Record number', value: 'CC-DEMO-10001' },
      { label: 'Laboratory', value: 'CareConnect Central Lab (Demo)' },
      { label: 'Referred by', value: 'Dr. Arjun Menon' },
    ],
    plainLanguageSummary:
      'This is a blood test report with eight results. Six results are inside the range the lab lists as its reference. Two results — hemoglobin and vitamin D — are marked by the lab as below its reference range. The report does not explain what these results mean for you; your doctor is the right person to interpret them.',
    importantDates: [
      { date: d(-32), context: 'Blood sample collected' },
      { date: d(-31), context: 'Report issued' },
    ],
    medications: [{ name: 'Paracetamol 500 mg', detail: 'Declared by patient, as needed' }],
    labValues: [
      { name: 'Hemoglobin', value: '11.8 g/dL', referenceRange: '12.0 – 15.5', outsideRange: true },
      { name: 'Fasting glucose', value: '94 mg/dL', referenceRange: '70 – 99', outsideRange: false },
      { name: 'HbA1c', value: '5.4 %', referenceRange: '< 5.7', outsideRange: false },
      { name: 'Total cholesterol', value: '186 mg/dL', referenceRange: '< 200', outsideRange: false },
      { name: 'LDL cholesterol', value: '112 mg/dL', referenceRange: '< 130', outsideRange: false },
      { name: 'HDL cholesterol', value: '52 mg/dL', referenceRange: '> 45', outsideRange: false },
      { name: '25-OH Vitamin D', value: '14.2 ng/mL', referenceRange: '30 – 100', outsideRange: true },
      { name: 'Blood pressure', value: '118/76 mmHg', referenceRange: '< 120/80', outsideRange: false },
    ],
    attentionItems: [
      { title: 'Two values flagged by the lab', detail: 'Hemoglobin and 25-OH Vitamin D are marked "L" (below reference range). Discuss these with your doctor.' },
      { title: 'Lab remark', detail: 'The lab asks for the results to be interpreted by the treating physician and repeated if advised.' },
    ],
  },
  'DOC-CONSULT': {
    documentTitle: 'Consultation letter — Endocrinology',
    documentType: 'Consultation letter',
    keyInformation: [
      { label: 'Patient', value: 'Priya Sharma (DEMO)' },
      { label: 'From', value: 'Dr. Sarah Thomas, Endocrinology' },
      { label: 'To', value: 'Dr. Arjun Menon, General Medicine' },
      { label: "Doctor's assessment (as written)", value: 'Vitamin D deficiency' },
      { label: 'Allergy on record', value: 'Penicillin' },
    ],
    plainLanguageSummary:
      'This is a letter from the endocrinology doctor back to your family doctor after your visit. It notes that you felt tired for about a month and lists two blood results from your recent tests. The doctor wrote down an assessment and a plan with two medicines for eight weeks, followed by repeat blood tests and a follow-up visit.',
    importantDates: [
      { date: d(-31), context: 'Blood reports referred to in the letter' },
      { date: d(-30), context: 'Consultation date' },
      { date: d(26), context: 'Follow-up appointment' },
    ],
    medications: [
      { name: 'Cholecalciferol 60,000 IU', detail: 'Once weekly for 8 weeks (as prescribed)' },
      { name: 'Calcium carbonate 500 mg', detail: 'Once daily after lunch for 8 weeks (as prescribed)' },
    ],
    labValues: [
      { name: '25-OH Vitamin D', value: '14.2 ng/mL', referenceRange: '30 – 100', outsideRange: true },
      { name: 'Hemoglobin', value: '11.8 g/dL', referenceRange: '12.0 – 15.5', outsideRange: true },
    ],
    attentionItems: [
      { title: 'Repeat tests planned', detail: 'The letter says Vitamin D and CBC should be repeated after 8 weeks.' },
      { title: 'Follow-up date', detail: `A follow-up visit is written for ${d(26)}. Check it appears in your appointments.` },
      { title: 'Allergy noted', detail: 'Penicillin allergy is recorded. Make sure every care team you visit knows this.' },
    ],
  },
  'DOC-DISCHARGE': {
    documentTitle: 'Discharge summary — Day care',
    documentType: 'Discharge summary',
    keyInformation: [
      { label: 'Patient', value: 'Rohan Verma (DEMO)' },
      { label: 'Record number', value: 'CC-DEMO-10002' },
      { label: 'Treating doctor', value: 'Dr. Arjun Menon' },
      { label: 'Reason for visit', value: 'Dizziness and headache' },
    ],
    plainLanguageSummary:
      'This summary covers a one-day hospital visit for dizziness and headache. Blood pressure was measured on arrival and again before going home, and a few blood tests were done. One medicine was prescribed for 30 days, and the document lists warning signs that should prompt a return to hospital, plus a date for a review visit.',
    importantDates: [
      { date: d(-76), context: 'Admitted to day care' },
      { date: d(-75), context: 'Discharged' },
      { date: d(-61), context: 'Outpatient review' },
    ],
    medications: [{ name: 'Amlodipine 5 mg', detail: 'Once daily in the morning for 30 days (as prescribed)' }],
    labValues: [
      { name: 'Blood pressure at triage', value: '162/100 mmHg', referenceRange: '< 120/80', outsideRange: true },
      { name: 'Blood pressure at discharge', value: '138/88 mmHg', referenceRange: '< 120/80', outsideRange: true },
      { name: 'Creatinine', value: '0.9 mg/dL', referenceRange: '0.7 – 1.3', outsideRange: false },
      { name: 'Sodium', value: '139 mmol/L', referenceRange: '135 – 145', outsideRange: false },
      { name: 'Potassium', value: '4.1 mmol/L', referenceRange: '3.5 – 5.1', outsideRange: false },
    ],
    attentionItems: [
      { title: 'Return-to-hospital signs listed', detail: 'The document lists severe headache, chest pain or vision changes as reasons to come back.' },
      { title: 'Home monitoring requested', detail: 'A home blood pressure log twice daily is documented.' },
    ],
  },
};

export { DISCLAIMER };
