import { useMemo } from 'react';
import { services } from '@/services';
import { useData } from './useData';

/** Reference data used across screens for name lookups. */
export function useLookups() {
  const { data: doctors = [] } = useData(() => services.users.listDoctors());
  const { data: departments = [] } = useData(() => services.users.listDepartments());
  const { data: patients = [] } = useData(() => services.users.listPatients());
  return useMemo(() => {
    const doctor = (id?: string) => doctors.find((d) => d.id === id);
    const department = (id?: string) => departments.find((d) => d.id === id);
    const patient = (id?: string) => patients.find((p) => p.id === id);
    return { doctors, departments, patients, doctor, department, patient, doctorName: (id?: string) => doctor(id)?.name ?? '—' };
  }, [doctors, departments, patients]);
}
