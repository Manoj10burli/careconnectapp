import { DependencyList, useCallback, useEffect, useRef, useState, useSyncExternalStore } from 'react';
import { db } from '@/services/mock/mockDb';

/**
 * Change feed. In the mock this is the local store; in production swap for
 * SignalR / Web PubSub events or React Query invalidation.
 */
export const useDataRevision = () => useSyncExternalStore(db.subscribe, db.revision);

/** Fetch data from a service and re-fetch whenever the data changes. */
export function useData<T>(fn: () => Promise<T>, deps: DependencyList = []) {
  const rev = useDataRevision();
  const [data, setData] = useState<T | undefined>(undefined);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const fnRef = useRef(fn);
  fnRef.current = fn;

  const run = useCallback(() => {
    let alive = true;
    fnRef.current()
      .then((d) => { if (alive) { setData(d); setError(null); } })
      .catch((e: Error) => { if (alive) setError(e.message); })
      .finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
  }, []);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(run, [rev, run, ...deps]);
  return { data, error, loading: loading && data === undefined };
}
