import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Bell, Building2, CalendarDays, FileUp, Hourglass, Pencil, Plus, RotateCcw, Search, Stethoscope, Users } from 'lucide-react';
import { services } from '@/services';
import { useData } from '@/hooks/useData';
import { useLookups } from '@/hooks/useLookups';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { Avatar, Badge, Button, cx, ErrorNote, Modal, PageHeader, Panel, Skeleton, Stat, StatusBadge, Tabs } from '@/components/ui';
import type { AppConfig, AppointmentStatus, Department, Doctor, NotificationChannel, Role } from '@/types';
import { addDays, fmtDate, fmtDateTime, fmtTime, parseISODate, timeAgo, today } from '@/utils/format';

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

/* -------------------------------- Dashboard -------------------------------- */

export function AdminDashboard() {
  const { user } = useAuth();
  const L = useLookups();
  const { data: appts = [] } = useData(() => services.appointments.list());
  const { data: labs = [] } = useData(() => services.records.listLabReports());
  const { data: notes = [] } = useData(() => services.notifications.list(user!.id), [user?.id]);
  const { data: audit = [] } = useData(() => services.admin.listAudit(6));

  const todays = appts.filter((a) => a.date === today() && a.status !== 'Cancelled');
  const pending = appts.filter((a) => a.status === 'Pending');
  const week = Array.from({ length: 7 }, (_, i) => addDays(i)).map((d) => ({ d, n: appts.filter((a) => a.date === d && a.status !== 'Cancelled').length }));
  const byDep = L.departments.map((d) => ({ name: d.name, n: appts.filter((a) => a.departmentId === d.id && a.status !== 'Cancelled').length }));
  const maxW = Math.max(1, ...week.map((w) => w.n));
  const maxD = Math.max(1, ...byDep.map((w) => w.n));

  return (
    <div>
      <PageHeader title="Hospital overview" subtitle={`${new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })} · all figures are demo data`} />
      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-3 xl:grid-cols-6">
        <Stat label="Total patients" value={L.patients.length} icon={<Users className="h-5 w-5" />} to="/admin/users" />
        <Stat label="Total doctors" value={L.doctors.length} icon={<Stethoscope className="h-5 w-5" />} to="/admin/doctors" tone="teal" />
        <Stat label="Today's appointments" value={todays.length} icon={<CalendarDays className="h-5 w-5" />} to="/admin/appointments" />
        <Stat label="Pending appointments" value={pending.length} icon={<Hourglass className="h-5 w-5" />} to="/admin/appointments" tone="amber" />
        <Stat label="Reports uploaded" value={labs.length} icon={<FileUp className="h-5 w-5" />} tone="teal" />
        <Stat label="System notifications" value={notes.filter((n) => !n.read).length} icon={<Bell className="h-5 w-5" />} to="/notifications" tone="amber" />
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Panel title="Appointments, next 7 days">
          <div className="flex h-44 items-end gap-2" role="img" aria-label="Appointments per day for the next 7 days">
            {week.map((w) => (
              <div key={w.d} className="flex flex-1 flex-col items-center gap-1.5">
                <span className="num text-xs font-bold">{w.n}</span>
                <div className="w-full rounded-t-[6px] bg-care-500" style={{ height: `${(w.n / maxW) * 120 + 4}px` }} />
                <span className="text-xs text-ink-faint">{w.d === today() ? 'Today' : DAYS[parseISODate(w.d).getDay()]}</span>
              </div>
            ))}
          </div>
        </Panel>
        <Panel title="Appointments by department">
          <ul className="space-y-3">
            {byDep.map((d) => (
              <li key={d.name}>
                <div className="mb-1 flex justify-between text-sm"><span>{d.name}</span><span className="num font-bold">{d.n}</span></div>
                <div className="h-2 rounded-full bg-canvas"><div className="h-2 rounded-full bg-teal-500" style={{ width: `${(d.n / maxD) * 100}%` }} /></div>
              </li>
            ))}
          </ul>
        </Panel>
        <Panel title="Awaiting confirmation" action={<Link to="/admin/appointments" className="text-sm font-semibold text-care-600">Manage</Link>} padded={false}>
          <ul className="divide-y divide-line">
            {pending.slice(0, 5).map((a) => (
              <li key={a.id} className="flex items-center gap-3 px-5 py-3 text-sm">
                <span className="flex-1"><b>{L.patient(a.patientId)?.name}</b> with {L.doctorName(a.doctorId)}<br /><span className="text-ink-soft">{fmtDate(a.date)} · {fmtTime(a.time)}</span></span>
                <Button size="sm" variant="secondary" onClick={() => services.appointments.setStatus(a.id, 'Confirmed')}>Confirm</Button>
              </li>
            ))}
            {!pending.length && <li className="px-5 py-6 text-sm text-ink-soft">Nothing waiting.</li>}
          </ul>
        </Panel>
        <Panel title="Recent activity" action={<Link to="/admin/audit" className="text-sm font-semibold text-care-600">Audit log</Link>} padded={false}>
          <ul className="divide-y divide-line">
            {audit.map((e) => (
              <li key={e.id} className="px-5 py-3 text-sm"><b>{e.actorName}</b> <span className="text-ink-soft">{e.action.toLowerCase()}</span>{e.entityId && <span className="text-ink-faint"> · {e.entityId}</span>}<p className="text-xs text-ink-faint">{timeAgo(e.at)}</p></li>
            ))}
          </ul>
        </Panel>
      </div>
    </div>
  );
}

/* ---------------------------------- Users ---------------------------------- */

export function UsersPage() {
  const toast = useToast();
  const [q, setQ] = useState('');
  const [role, setRole] = useState<'all' | Role>('all');
  const [adding, setAdding] = useState(false);
  const { data = [], loading } = useData(() => services.users.listUsers());
  const list = data.filter((u) => (role === 'all' || u.role === role) && (u.name + u.email).toLowerCase().includes(q.toLowerCase()));
  const toggle = async (id: string, active: boolean) => { await services.users.setActive(id, active); toast({ tone: 'info', title: active ? 'User activated' : 'User deactivated' }); };

  return (
    <div>
      <PageHeader title="Users" subtitle="Patients, clinicians and administrators with access to CareConnect." actions={<Button icon={<Plus className="h-4 w-4" />} onClick={() => setAdding(true)}>Add user</Button>} />
      <div className="mb-4 flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1"><Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-faint" /><input className="field pl-9" placeholder="Search by name or email" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search users" /></div>
        <select className="field sm:w-44" value={role} onChange={(e) => setRole(e.target.value as typeof role)} aria-label="Filter by role"><option value="all">All roles</option><option value="patient">Patients</option><option value="doctor">Doctors</option><option value="admin">Admins</option></select>
      </div>
      {loading ? <Skeleton rows={6} /> : (
        <div className="panel overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <thead className="border-b border-line bg-canvas text-left text-ink-soft"><tr><th className="px-5 py-3 font-semibold">User</th><th className="px-3 py-3 font-semibold">Role</th><th className="px-3 py-3 font-semibold">Phone</th><th className="px-3 py-3 font-semibold">Last sign-in</th><th className="px-3 py-3 font-semibold">Status</th><th className="px-5 py-3 text-right font-semibold">Access</th></tr></thead>
            <tbody className="divide-y divide-line">
              {list.map((u) => (
                <tr key={u.id} className={cx(!u.active && 'text-ink-faint')}>
                  <td className="px-5 py-3"><span className="flex items-center gap-3"><Avatar name={u.name} size={32} tone={u.role === 'patient' ? 'blue' : 'teal'} /><span><span className="block font-semibold text-ink">{u.name}</span><span className="text-xs text-ink-faint">{u.email}</span></span></span></td>
                  <td className="px-3 py-3"><Badge tone={u.role === 'admin' ? 'amber' : u.role === 'doctor' ? 'teal' : 'blue'}>{u.role}</Badge></td>
                  <td className="px-3 py-3">{u.phone}</td>
                  <td className="px-3 py-3">{u.lastLogin ? timeAgo(u.lastLogin) : 'Never'}</td>
                  <td className="px-3 py-3">{u.active ? <Badge tone="teal">Active</Badge> : <Badge tone="grey">Deactivated</Badge>}</td>
                  <td className="px-5 py-3 text-right"><Button size="sm" variant={u.active ? 'danger' : 'secondary'} onClick={() => toggle(u.id, !u.active)}>{u.active ? 'Deactivate' : 'Activate'}</Button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <AddUserModal open={adding} onClose={() => setAdding(false)} />
    </div>
  );
}

function AddUserModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const toast = useToast();
  const [f, setF] = useState({ name: '', email: '', phone: '', role: 'admin' as Role });
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const save = async () => {
    if (!f.name.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email)) return setErr('Enter a name and a valid email.');
    setBusy(true); setErr(null);
    try { await services.users.createUser(f); toast({ tone: 'success', title: 'User added', body: 'In production an invitation email is sent via Entra ID.' }); setF({ name: '', email: '', phone: '', role: 'admin' }); onClose(); }
    catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  };
  return (
    <Modal open={open} onClose={onClose} title="Add user" footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={save}>Add user</Button></>}>
      <div className="space-y-4">
        <div><label className="label" htmlFor="un">Full name</label><input id="un" className="field" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
        <div><label className="label" htmlFor="ue">Email</label><input id="ue" type="email" className="field" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></div>
        <div><label className="label" htmlFor="up">Phone</label><input id="up" type="tel" className="field" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></div>
        <div><label className="label" htmlFor="ur">Role</label><select id="ur" className="field" value={f.role} onChange={(e) => setF({ ...f, role: e.target.value as Role })}><option value="admin">Administrator</option><option value="patient">Patient (portal access only)</option></select><p className="mt-1 text-xs text-ink-faint">Add doctors from the Doctors page so they get a schedule.</p></div>
        <ErrorNote message={err} />
      </div>
    </Modal>
  );
}

/* --------------------------------- Doctors --------------------------------- */

const blankDoctor = (depId: string): Omit<Doctor, 'id'> & { id?: string } => ({ name: 'Dr. ', departmentId: depId, specialization: '', qualification: '', experienceYears: 5, email: '', phone: '', workingDays: [1, 2, 3, 4, 5], slots: ['09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '14:00', '14:30', '15:00', '15:30'], active: true, room: '' });

export function DoctorsPage() {
  const L = useLookups();
  const toast = useToast();
  const [editing, setEditing] = useState<(Omit<Doctor, 'id'> & { id?: string }) | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const save = async () => {
    if (!editing) return;
    if (editing.name.trim().length < 5 || !editing.email.includes('@')) return setErr('Enter the doctor\u2019s name and a valid email.');
    if (!editing.workingDays.length) return setErr('Choose at least one clinic day.');
    setBusy(true); setErr(null);
    await services.users.saveDoctor(editing);
    setBusy(false); toast({ tone: 'success', title: editing.id ? 'Doctor updated' : 'Doctor added' }); setEditing(null);
  };
  return (
    <div>
      <PageHeader title="Doctors" subtitle="Clinicians, their departments and clinic days." actions={<Button icon={<Plus className="h-4 w-4" />} onClick={() => setEditing(blankDoctor(L.departments[0]?.id ?? ''))}>Add doctor</Button>} />
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {L.doctors.map((d) => (
          <article key={d.id} className="panel p-5">
            <div className="flex items-start gap-3">
              <Avatar name={d.name} size={48} tone="teal" />
              <div className="flex-1"><p className="font-bold">{d.name}</p><p className="text-sm text-ink-soft">{d.specialization}</p><p className="text-sm text-ink-soft">{L.department(d.departmentId)?.name}</p></div>
              <button onClick={() => { setErr(null); setEditing({ ...d }); }} className="rounded-full p-2 text-ink-soft hover:bg-canvas" aria-label={`Edit ${d.name}`}><Pencil className="h-4 w-4" /></button>
            </div>
            <div className="mt-4 flex gap-1">{DAYS.map((x, i) => <span key={x} className={cx('flex-1 rounded py-1 text-center text-[11px] font-semibold', d.workingDays.includes(i) ? 'bg-teal-50 text-teal-700' : 'bg-canvas text-ink-faint')}>{x[0]}</span>)}</div>
            <p className="mt-3 text-xs text-ink-faint">{d.slots.length} slots/day · Room {d.room || '—'} · {d.active ? 'Accepting bookings' : 'Not accepting bookings'}</p>
          </article>
        ))}
      </div>
      <Modal wide open={!!editing} onClose={() => setEditing(null)} title={editing?.id ? 'Edit doctor' : 'Add doctor'} footer={<><Button variant="secondary" onClick={() => setEditing(null)}>Cancel</Button><Button loading={busy} onClick={save}>Save doctor</Button></>}>
        {editing && (
          <div className="grid gap-4 sm:grid-cols-2">
            <div><label className="label" htmlFor="dn">Name</label><input id="dn" className="field" value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} /></div>
            <div><label className="label" htmlFor="dd">Department</label><select id="dd" className="field" value={editing.departmentId} onChange={(e) => setEditing({ ...editing, departmentId: e.target.value })}>{L.departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></div>
            <div><label className="label" htmlFor="ds">Specialization</label><input id="ds" className="field" value={editing.specialization} onChange={(e) => setEditing({ ...editing, specialization: e.target.value })} /></div>
            <div><label className="label" htmlFor="dq">Qualification</label><input id="dq" className="field" value={editing.qualification} onChange={(e) => setEditing({ ...editing, qualification: e.target.value })} /></div>
            <div><label className="label" htmlFor="de">Email</label><input id="de" className="field" value={editing.email} onChange={(e) => setEditing({ ...editing, email: e.target.value })} /></div>
            <div><label className="label" htmlFor="dr">Room</label><input id="dr" className="field" value={editing.room} onChange={(e) => setEditing({ ...editing, room: e.target.value })} /></div>
            <fieldset className="sm:col-span-2"><legend className="label">Clinic days</legend>
              <div className="flex flex-wrap gap-2">{DAYS.map((x, i) => {
                const on = editing.workingDays.includes(i);
                return <button key={x} type="button" aria-pressed={on} onClick={() => setEditing({ ...editing, workingDays: on ? editing.workingDays.filter((d) => d !== i) : [...editing.workingDays, i].sort() })} className={cx('rounded-item border px-3 py-1.5 text-sm font-semibold', on ? 'border-teal-500 bg-teal-50 text-teal-700' : 'border-line text-ink-soft')}>{x}</button>;
              })}</div>
            </fieldset>
            <label className="flex items-center gap-2 text-sm font-semibold sm:col-span-2"><input type="checkbox" className="h-4 w-4 accent-care-500" checked={editing.active} onChange={(e) => setEditing({ ...editing, active: e.target.checked })} />Accepting online bookings</label>
            <div className="sm:col-span-2"><ErrorNote message={err} /></div>
          </div>
        )}
      </Modal>
    </div>
  );
}

/* ------------------------------- Departments ------------------------------- */

export function DepartmentsPage() {
  const L = useLookups();
  const toast = useToast();
  const [editing, setEditing] = useState<(Omit<Department, 'id'> & { id?: string }) | null>(null);
  const [busy, setBusy] = useState(false);
  const save = async () => {
    if (!editing?.name.trim()) return;
    setBusy(true); await services.users.saveDepartment(editing); setBusy(false);
    toast({ tone: 'success', title: editing.id ? 'Department updated' : 'Department added' }); setEditing(null);
  };
  return (
    <div>
      <PageHeader title="Departments" subtitle="Specialities patients can book into." actions={<Button icon={<Plus className="h-4 w-4" />} onClick={() => setEditing({ name: '', description: '', location: '', active: true })}>Add department</Button>} />
      <div className="panel divide-y divide-line">
        {L.departments.map((d) => (
          <div key={d.id} className="flex flex-wrap items-center gap-4 px-5 py-4">
            <span className="rounded-item bg-care-50 p-2.5 text-care-600"><Building2 className="h-5 w-5" /></span>
            <div className="min-w-[200px] flex-1"><p className="font-bold">{d.name}</p><p className="text-sm text-ink-soft">{d.description} · {d.location}</p></div>
            <span className="text-sm text-ink-soft">{L.doctors.filter((x) => x.departmentId === d.id).length} doctors</span>
            {d.active ? <Badge tone="teal">Open for booking</Badge> : <Badge tone="grey">Hidden</Badge>}
            <Button size="sm" variant="secondary" icon={<Pencil className="h-3.5 w-3.5" />} onClick={() => setEditing({ ...d })}>Edit</Button>
          </div>
        ))}
      </div>
      <Modal open={!!editing} onClose={() => setEditing(null)} title={editing?.id ? 'Edit department' : 'Add department'} footer={<><Button variant="secondary" onClick={() => setEditing(null)}>Cancel</Button><Button loading={busy} disabled={!editing?.name.trim()} onClick={save}>Save department</Button></>}>
        {editing && (
          <div className="space-y-4">
            <div><label className="label" htmlFor="pn2">Name</label><input id="pn2" className="field" value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} /></div>
            <div><label className="label" htmlFor="pd2">Description</label><input id="pd2" className="field" value={editing.description} onChange={(e) => setEditing({ ...editing, description: e.target.value })} /></div>
            <div><label className="label" htmlFor="pl2">Location</label><input id="pl2" className="field" value={editing.location} onChange={(e) => setEditing({ ...editing, location: e.target.value })} /></div>
            <label className="flex items-center gap-2 text-sm font-semibold"><input type="checkbox" className="h-4 w-4 accent-care-500" checked={editing.active} onChange={(e) => setEditing({ ...editing, active: e.target.checked })} />Show to patients when booking</label>
          </div>
        )}
      </Modal>
    </div>
  );
}

/* ------------------------------- Appointments ------------------------------- */

export function AdminAppointmentsPage() {
  const L = useLookups();
  const toast = useToast();
  const [status, setStatus] = useState<'all' | AppointmentStatus>('all');
  const [dep, setDep] = useState('all');
  const { data = [], loading } = useData(() => services.appointments.list());
  const list = data.filter((a) => (status === 'all' || a.status === status) && (dep === 'all' || a.departmentId === dep)).reverse();
  const count = (s: AppointmentStatus) => data.filter((a) => a.status === s).length;
  const act = async (id: string, s: AppointmentStatus) => { s === 'Cancelled' ? await services.appointments.cancel(id) : await services.appointments.setStatus(id, s); toast({ tone: 'success', title: `Appointment ${s.toLowerCase()}` }); };
  return (
    <div>
      <PageHeader title="Appointments" subtitle="Every booking across departments." />
      <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
        <Tabs value={status} onChange={setStatus} tabs={[{ id: 'all', label: 'All', count: data.length }, { id: 'Pending', label: 'Pending', count: count('Pending') }, { id: 'Confirmed', label: 'Confirmed', count: count('Confirmed') }, { id: 'Completed', label: 'Completed', count: count('Completed') }, { id: 'Cancelled', label: 'Cancelled', count: count('Cancelled') }]} />
        <select className="field mb-5 md:w-56" value={dep} onChange={(e) => setDep(e.target.value)} aria-label="Department"><option value="all">All departments</option>{L.departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select>
      </div>
      {loading ? <Skeleton rows={6} /> : (
        <div className="panel overflow-x-auto">
          <table className="w-full min-w-[800px] text-sm">
            <thead className="border-b border-line bg-canvas text-left text-ink-soft"><tr><th className="px-5 py-3 font-semibold">Date</th><th className="px-3 py-3 font-semibold">Patient</th><th className="px-3 py-3 font-semibold">Doctor</th><th className="px-3 py-3 font-semibold">Department</th><th className="px-3 py-3 font-semibold">Status</th><th className="px-5 py-3 text-right font-semibold">Actions</th></tr></thead>
            <tbody className="divide-y divide-line">
              {list.map((a) => (
                <tr key={a.id}>
                  <td className="whitespace-nowrap px-5 py-3 font-semibold">{fmtDate(a.date)}<span className="block font-normal text-ink-soft">{fmtTime(a.time)}</span></td>
                  <td className="px-3 py-3">{L.patient(a.patientId)?.name}</td>
                  <td className="px-3 py-3">{L.doctorName(a.doctorId)}</td>
                  <td className="px-3 py-3 text-ink-soft">{L.department(a.departmentId)?.name}</td>
                  <td className="px-3 py-3"><StatusBadge status={a.status} /></td>
                  <td className="whitespace-nowrap px-5 py-3 text-right"><span className="inline-flex gap-2">
                    {a.status === 'Pending' && <Button size="sm" variant="secondary" onClick={() => act(a.id, 'Confirmed')}>Confirm</Button>}
                    {(a.status === 'Pending' || a.status === 'Confirmed') && <Button size="sm" variant="danger" onClick={() => act(a.id, 'Cancelled')}>Cancel</Button>}
                  </span></td>
                </tr>
              ))}
              {!list.length && <tr><td colSpan={6} className="px-5 py-10 text-center text-ink-soft">No appointments match these filters.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/* ------------------------------ Configuration ------------------------------ */

export function SettingsPage() {
  const toast = useToast();
  const nav = useNavigate();
  const { logout } = useAuth();
  const { data } = useData(() => services.admin.getConfig());
  const [c, setC] = useState<AppConfig | null>(null);
  const [busy, setBusy] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  useEffect(() => { if (data && !c) setC(data); }, [data, c]);
  if (!c) return <Skeleton rows={5} />;
  const save = async () => { setBusy(true); setC(await services.admin.updateConfig(c)); setBusy(false); toast({ tone: 'success', title: 'Configuration saved' }); };
  const reset = async () => { await services.admin.resetDemoData(); await logout(); nav('/login'); };
  const Toggle = ({ on, onChange, label, hint }: { on: boolean; onChange: (v: boolean) => void; label: string; hint?: string }) => (
    <label className="flex cursor-pointer items-start justify-between gap-4 py-3">
      <span><span className="block font-semibold">{label}</span>{hint && <span className="text-sm text-ink-soft">{hint}</span>}</span>
      <input type="checkbox" role="switch" className="peer sr-only" checked={on} onChange={(e) => onChange(e.target.checked)} />
      <span className={cx('relative mt-1 h-6 w-11 shrink-0 rounded-full transition-colors peer-focus-visible:ring-2 peer-focus-visible:ring-care-500', on ? 'bg-teal-500' : 'bg-line')}><span className={cx('absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all', on ? 'left-[22px]' : 'left-0.5')} /></span>
    </label>
  );
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader title="Configuration" subtitle="Basic settings for this CareConnect workspace." actions={<Button loading={busy} onClick={save}>Save changes</Button>} />
      <div className="space-y-5">
        <Panel title="Organisation">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2"><label className="label" htmlFor="on">Organisation name</label><input id="on" className="field" value={c.organizationName} onChange={(e) => setC({ ...c, organizationName: e.target.value })} /></div>
            <div><label className="label" htmlFor="sm">Appointment length</label><select id="sm" className="field" value={c.slotMinutes} onChange={(e) => setC({ ...c, slotMinutes: Number(e.target.value) })}>{[15, 20, 30, 45].map((m) => <option key={m} value={m}>{m} minutes</option>)}</select></div>
            <div><label className="label" htmlFor="bw">Booking window</label><select id="bw" className="field" value={c.bookingWindowDays} onChange={(e) => setC({ ...c, bookingWindowDays: Number(e.target.value) })}>{[7, 14, 30, 60].map((m) => <option key={m} value={m}>{m} days ahead</option>)}</select></div>
          </div>
        </Panel>
        <Panel title="Bookings and AI">
          <div className="divide-y divide-line">
            <Toggle on={c.autoConfirmBookings} onChange={(v) => setC({ ...c, autoConfirmBookings: v })} label="Confirm online bookings automatically" hint="When off, new bookings stay Pending until staff confirm them." />
            <Toggle on={c.aiAssistantEnabled} onChange={(v) => setC({ ...c, aiAssistantEnabled: v })} label="AI Health Document Assistant" hint="Summarises documents only. Never diagnoses or recommends treatment." />
          </div>
        </Panel>
        <Panel title="Notification channels">
          <div className="divide-y divide-line">
            {(Object.keys(c.channels) as NotificationChannel[]).map((ch) => <Toggle key={ch} on={c.channels[ch]} onChange={(v) => setC({ ...c, channels: { ...c.channels, [ch]: v } })} label={ch} hint={ch === 'In-app' ? 'Always recommended' : 'Simulated in the demo'} />)}
            <div className="py-3"><label className="label" htmlFor="rh">Send appointment reminders</label><select id="rh" className="field sm:w-64" value={c.reminderHoursBefore} onChange={(e) => setC({ ...c, reminderHoursBefore: Number(e.target.value) })}>{[2, 12, 24, 48].map((h) => <option key={h} value={h}>{h} hours before</option>)}</select></div>
          </div>
        </Panel>
        <Panel title="Demo data">
          <p className="text-sm text-ink-soft">Restore every patient, appointment and record to the original sample set. Use this before each customer presentation.</p>
          <Button variant="danger" className="mt-3" icon={<RotateCcw className="h-4 w-4" />} onClick={() => setConfirmReset(true)}>Reset demo data</Button>
        </Panel>
      </div>
      <Modal open={confirmReset} onClose={() => setConfirmReset(false)} title="Reset demo data?" footer={<><Button variant="secondary" onClick={() => setConfirmReset(false)}>Keep current data</Button><Button variant="danger" onClick={reset}>Reset and sign out</Button></>}>
        <p className="text-ink-soft">Bookings, notes, prescriptions and uploads made during this session will be removed and you will be signed out.</p>
      </Modal>
    </div>
  );
}

/* -------------------------------- Audit log -------------------------------- */

export function AuditPage() {
  const { data = [], loading } = useData(() => services.admin.listAudit(200));
  return (
    <div>
      <PageHeader title="Audit log" subtitle="Who did what, and when. Production writes to tamper-evident storage and Application Insights." />
      {loading ? <Skeleton rows={6} /> : (
        <div className="panel overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <thead className="border-b border-line bg-canvas text-left text-ink-soft"><tr><th className="px-5 py-3 font-semibold">Time</th><th className="px-3 py-3 font-semibold">User</th><th className="px-3 py-3 font-semibold">Role</th><th className="px-3 py-3 font-semibold">Action</th><th className="px-5 py-3 font-semibold">Record</th></tr></thead>
            <tbody className="divide-y divide-line">
              {data.map((e) => (
                <tr key={e.id}><td className="num whitespace-nowrap px-5 py-2.5 text-ink-soft">{fmtDateTime(e.at)}</td><td className="px-3 py-2.5 font-semibold">{e.actorName}</td><td className="px-3 py-2.5"><Badge tone="grey">{e.role}</Badge></td><td className="px-3 py-2.5">{e.action}</td><td className="px-5 py-2.5 text-ink-soft">{e.entity}{e.entityId ? ` · ${e.entityId}` : ''}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
