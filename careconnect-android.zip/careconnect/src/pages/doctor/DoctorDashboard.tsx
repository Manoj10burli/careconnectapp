import { useState } from 'react';
import { Link } from 'react-router-dom';
import { CalendarCheck2, CalendarDays, CheckCircle2, Clock, Hourglass, Repeat, Users, Video } from 'lucide-react';
import { services } from '@/services';
import { useData } from '@/hooks/useData';
import { useLookups } from '@/hooks/useLookups';
import { useAuth, useProfileId } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { Avatar, Badge, Button, cx, Empty, PageHeader, Panel, Skeleton, Stat, StatusBadge, Tabs } from '@/components/ui';
import type { Appointment } from '@/types';
import { ageFrom, fmtDate, fmtDay, fmtTime, timeAgo, today } from '@/utils/format';

export default function DoctorDashboard() {
  const did = useProfileId();
  const { user } = useAuth();
  const L = useLookups();
  const { data: appts = [], loading } = useData(() => services.appointments.list({ doctorId: did }), [did]);
  const { data: notes = [] } = useData(() => services.notifications.list(user!.id), [user?.id]);
  const todays = appts.filter((a) => a.date === today() && a.status !== 'Cancelled');
  const upcoming = appts.filter((a) => a.date > today() && a.status !== 'Cancelled' && a.status !== 'Completed').slice(0, 6);
  const newest = [...appts].filter((a) => a.status !== 'Cancelled' && a.date >= today()).sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0];
  const justBooked = newest && Date.now() - new Date(newest.createdAt).getTime() < 3 * 3600e3 ? newest : undefined;
  const myPatients = new Set(appts.map((a) => a.patientId));
  const followUps = L.patients.filter((p) => myPatients.has(p.id)).length;

  return (
    <div>
      <PageHeader title={`Good ${new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 17 ? 'afternoon' : 'evening'}, ${user?.name}`} subtitle={`${new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })} · ${L.department(L.doctor(did)?.departmentId)?.name} · Room ${L.doctor(did)?.room ?? ''}`} />

      {justBooked && (
        <Link to={`/doctor/patients/${justBooked.patientId}?appointment=${justBooked.id}`} className="rise mb-5 flex items-center gap-4 rounded-panel border border-teal-500/40 bg-teal-50 p-4 hover:border-teal-500">
          <span className="rounded-full bg-teal-500 p-2 text-white"><CalendarCheck2 className="h-5 w-5" /></span>
          <span className="flex-1">
            <span className="block font-bold">New booking: {L.patient(justBooked.patientId)?.name}</span>
            <span className="text-sm text-ink-soft">{fmtDay(justBooked.date)} at {fmtTime(justBooked.time)} · {justBooked.reason} · booked {timeAgo(justBooked.createdAt)}</span>
          </span>
          <span className="hidden text-sm font-semibold text-teal-700 sm:block">Open patient record</span>
        </Link>
      )}

      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Today's appointments" value={todays.length} icon={<CalendarDays className="h-5 w-5" />} to="/doctor/appointments" />
        <Stat label="Waiting to be seen" value={todays.filter((a) => a.status === 'Confirmed' || a.status === 'Pending').length} icon={<Hourglass className="h-5 w-5" />} tone="amber" />
        <Stat label="Seen today" value={todays.filter((a) => a.status === 'Completed').length} icon={<CheckCircle2 className="h-5 w-5" />} tone="teal" />
        <Stat label="My patients" value={followUps} icon={<Users className="h-5 w-5" />} to="/doctor/patients" />
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        <Panel title="Today's schedule" action={<Link to="/doctor/appointments" className="text-sm font-semibold text-care-600">All appointments</Link>} className="lg:col-span-2" padded={false}>
          {loading ? <div className="p-5"><Skeleton /></div> : todays.length ? (
            <ul className="divide-y divide-line">
              {todays.map((a) => <ScheduleRow key={a.id} a={a} />)}
            </ul>
          ) : <Empty icon={<CalendarDays className="h-5 w-5" />} title="No appointments today" />}
        </Panel>

        <div className="space-y-5">
          <Panel title="Coming up" padded={false}>
            <ul className="divide-y divide-line">
              {upcoming.map((a) => (
                <li key={a.id}>
                  <Link to={`/doctor/patients/${a.patientId}?appointment=${a.id}`} className="block px-5 py-3 hover:bg-canvas">
                    <p className="text-sm font-semibold">{L.patient(a.patientId)?.name}</p>
                    <p className="text-xs text-ink-soft">{fmtDay(a.date)} · {fmtTime(a.time)} · {a.status}</p>
                  </Link>
                </li>
              ))}
              {!upcoming.length && <li className="px-5 py-5 text-sm text-ink-soft">Nothing scheduled.</li>}
            </ul>
          </Panel>
          <Panel title="Updates" action={<Link to="/notifications" className="text-sm font-semibold text-care-600">All</Link>} padded={false}>
            <ul className="divide-y divide-line">
              {notes.slice(0, 4).map((n) => (
                <li key={n.id} className="px-5 py-3">
                  <p className={cx('text-sm', n.read ? 'text-ink-soft' : 'font-semibold')}>{n.title}</p>
                  <p className="line-clamp-2 text-xs text-ink-soft">{n.message}</p>
                </li>
              ))}
            </ul>
          </Panel>
        </div>
      </div>
    </div>
  );
}

function ScheduleRow({ a }: { a: Appointment }) {
  const L = useLookups();
  const p = L.patient(a.patientId);
  const done = a.status === 'Completed';
  return (
    <li className={cx('flex flex-col gap-3 px-5 py-3.5 sm:flex-row sm:items-center', done && 'opacity-60')}>
      <span className="num w-24 shrink-0 whitespace-nowrap font-bold text-care-600">{fmtTime(a.time)}</span>
      <div className="flex flex-1 items-center gap-3">
        <Avatar name={p?.name ?? ''} size={36} />
        <div className="min-w-0">
          <p className="font-semibold">{p?.name} <span className="font-normal text-ink-faint">· {p && ageFrom(p.dob)}{p?.gender[0]}</span></p>
          <p className="truncate text-sm text-ink-soft">{a.type === 'Video' && <Video className="mr-1 inline h-3.5 w-3.5" />}{a.reason}</p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <StatusBadge status={a.status} />
        <Link to={`/doctor/patients/${a.patientId}?appointment=${a.id}${done ? '' : '&action=consult'}`}><Button size="sm" variant={done ? 'secondary' : 'primary'}>{done ? 'View record' : 'Start consultation'}</Button></Link>
      </div>
    </li>
  );
}

/* ------------------------- Appointments list ------------------------- */

export function DoctorAppointmentsPage() {
  const did = useProfileId();
  const L = useLookups();
  const toast = useToast();
  const [tab, setTab] = useState<'today' | 'upcoming' | 'past'>('today');
  const { data = [], loading } = useData(() => services.appointments.list({ doctorId: did }), [did]);
  const groups = {
    today: data.filter((a) => a.date === today()),
    upcoming: data.filter((a) => a.date > today()),
    past: data.filter((a) => a.date < today()).reverse(),
  };
  const act = async (id: string, s: Appointment['status']) => {
    await services.appointments.setStatus(id, s);
    toast({ tone: 'success', title: `Appointment ${s.toLowerCase()}` });
  };
  return (
    <div>
      <PageHeader title="Appointments" subtitle="Your schedule across today, upcoming and past visits." />
      <Tabs value={tab} onChange={setTab} tabs={[{ id: 'today', label: 'Today', count: groups.today.length }, { id: 'upcoming', label: 'Upcoming', count: groups.upcoming.length }, { id: 'past', label: 'Past', count: groups.past.length }]} />
      {loading ? <Skeleton rows={5} /> : (
        <div className="panel overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <thead className="border-b border-line bg-canvas text-left text-ink-soft">
              <tr><th className="px-5 py-3 font-semibold">When</th><th className="px-3 py-3 font-semibold">Patient</th><th className="px-3 py-3 font-semibold">Reason</th><th className="px-3 py-3 font-semibold">Status</th><th className="px-5 py-3 text-right font-semibold">Actions</th></tr>
            </thead>
            <tbody className="divide-y divide-line">
              {groups[tab].map((a) => (
                <tr key={a.id}>
                  <td className="whitespace-nowrap px-5 py-3"><p className="font-semibold">{fmtDate(a.date, { day: 'numeric', month: 'short' })}</p><p className="flex items-center gap-1 text-ink-soft"><Clock className="h-3.5 w-3.5" />{fmtTime(a.time)}</p></td>
                  <td className="px-3 py-3"><Link to={`/doctor/patients/${a.patientId}`} className="font-semibold text-care-600 hover:underline">{L.patient(a.patientId)?.name}</Link><p className="text-ink-faint">{L.patient(a.patientId)?.mrn}</p></td>
                  <td className="max-w-[240px] px-3 py-3 text-ink-soft">{a.reason} {a.type === 'Video' && <Badge tone="blue">Video</Badge>}</td>
                  <td className="px-3 py-3"><StatusBadge status={a.status} /></td>
                  <td className="whitespace-nowrap px-5 py-3 text-right">
                    <span className="inline-flex gap-2">
                      {a.status === 'Pending' && <Button size="sm" variant="secondary" onClick={() => act(a.id, 'Confirmed')}>Confirm</Button>}
                      {(a.status === 'Confirmed' || a.status === 'Pending') && <Link to={`/doctor/patients/${a.patientId}?appointment=${a.id}&action=consult`}><Button size="sm">Consult</Button></Link>}
                      {a.status === 'Completed' && <Link to={`/doctor/patients/${a.patientId}`}><Button size="sm" variant="secondary" icon={<Repeat className="h-3.5 w-3.5" />}>Record</Button></Link>}
                    </span>
                  </td>
                </tr>
              ))}
              {!groups[tab].length && <tr><td colSpan={5} className="px-5 py-10 text-center text-ink-soft">No appointments.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
