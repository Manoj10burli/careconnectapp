import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { AlertTriangle, ArrowLeft, ClipboardPlus, FlaskConical, Phone, Pill, Plus, Search, Trash2, Users } from 'lucide-react';
import { services } from '@/services';
import { useData } from '@/hooks/useData';
import { useLookups } from '@/hooks/useLookups';
import { useProfileId } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { Avatar, Badge, Button, DemoTag, Empty, ErrorNote, LabStatusBadge, Modal, PageHeader, Skeleton, StatusBadge, Tabs } from '@/components/ui';
import { RecordTimeline } from '@/components/RecordTimeline';
import { PrescriptionCard } from '@/components/PrescriptionCard';
import { LabReportView } from '@/components/LabReportView';
import type { LabReport, Medication } from '@/types';
import { addDays, ageFrom, fmtDate, fmtDay, fmtTime, today } from '@/utils/format';

/* ------------------------------ Patient list ------------------------------ */

export function PatientListPage() {
  const did = useProfileId();
  const L = useLookups();
  const [q, setQ] = useState('');
  const [mine, setMine] = useState(true);
  const { data: appts = [] } = useData(() => services.appointments.list({ doctorId: did }), [did]);
  const seen = new Set(appts.map((a) => a.patientId));
  const lastVisit = (pid: string) => appts.filter((a) => a.patientId === pid && a.status === 'Completed').pop()?.date;
  const nextVisit = (pid: string) => appts.find((a) => a.patientId === pid && a.date >= today() && a.status !== 'Cancelled' && a.status !== 'Completed');
  const list = L.patients.filter((p) => (!mine || seen.has(p.id) || p.primaryDoctorId === did) && (p.name + p.mrn).toLowerCase().includes(q.toLowerCase()));

  return (
    <div>
      <PageHeader title="Patients" subtitle="Search and open patient records. Access is logged for audit." />
      <div className="mb-4 flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-faint" />
          <input className="field pl-9" placeholder="Search by name or MRN" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search patients" />
        </div>
        <div className="flex rounded-item bg-canvas p-1 text-sm font-semibold">
          <button onClick={() => setMine(true)} className={`rounded-[8px] px-3 py-1.5 ${mine ? 'bg-white text-care-600 shadow-sm' : 'text-ink-soft'}`}>My patients</button>
          <button onClick={() => setMine(false)} className={`rounded-[8px] px-3 py-1.5 ${!mine ? 'bg-white text-care-600 shadow-sm' : 'text-ink-soft'}`}>All patients</button>
        </div>
      </div>
      {!L.patients.length ? <Skeleton rows={5} /> : (
        <div className="panel overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <thead className="border-b border-line bg-canvas text-left text-ink-soft">
              <tr><th className="px-5 py-3 font-semibold">Patient</th><th className="px-3 py-3 font-semibold">Age / sex</th><th className="px-3 py-3 font-semibold">Blood</th><th className="px-3 py-3 font-semibold">Conditions on file</th><th className="px-3 py-3 font-semibold">Last visit</th><th className="px-5 py-3 font-semibold">Next visit</th></tr>
            </thead>
            <tbody className="divide-y divide-line">
              {list.map((p) => {
                const nv = nextVisit(p.id);
                return (
                  <tr key={p.id} className="hover:bg-canvas">
                    <td className="px-5 py-3"><Link to={`/doctor/patients/${p.id}`} className="flex items-center gap-3"><Avatar name={p.name} size={34} /><span><span className="block font-semibold text-care-600">{p.name}</span><span className="text-xs text-ink-faint">{p.mrn}</span></span></Link></td>
                    <td className="px-3 py-3">{ageFrom(p.dob)} / {p.gender[0]}</td>
                    <td className="px-3 py-3"><Badge tone="blue">{p.bloodGroup}</Badge></td>
                    <td className="px-3 py-3 text-ink-soft">{p.conditions.join(', ') || '—'}</td>
                    <td className="px-3 py-3">{fmtDate(lastVisit(p.id))}</td>
                    <td className="px-5 py-3">{nv ? <span className="font-semibold">{fmtDate(nv.date, { day: 'numeric', month: 'short' })}, {fmtTime(nv.time)}</span> : '—'}</td>
                  </tr>
                );
              })}
              {!list.length && <tr><td colSpan={6}><Empty icon={<Users className="h-5 w-5" />} title="No patients match your search" /></td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/* ----------------------------- Patient record ----------------------------- */

type Tab = 'timeline' | 'labs' | 'rx' | 'appts';

export default function PatientRecordPage() {
  const { id = '' } = useParams();
  const [params, setParams] = useSearchParams();
  const did = useProfileId();
  const L = useLookups();
  const nav = useNavigate();
  const [tab, setTab] = useState<Tab>('timeline');
  const [modal, setModal] = useState<'consult' | 'prescribe' | 'lab' | null>(null);
  const [openLab, setOpenLab] = useState<LabReport | null>(null);
  const apptId = params.get('appointment') ?? undefined;

  const { data: patient, loading } = useData(() => services.users.getPatient(id), [id]);
  const { data: records = [] } = useData(() => services.records.listRecords(id), [id]);
  const { data: rx = [] } = useData(() => services.records.listPrescriptions({ patientId: id }), [id]);
  const { data: labs = [] } = useData(() => services.records.listLabReports(id), [id]);
  const { data: appts = [] } = useData(() => services.appointments.list({ patientId: id }), [id]);
  const appt = appts.find((a) => a.id === apptId) ?? appts.find((a) => a.doctorId === did && a.date === today() && a.status !== 'Completed' && a.status !== 'Cancelled');

  useEffect(() => {
    const a = params.get('action');
    if (a === 'consult' || a === 'prescribe' || a === 'lab') setModal(a);
  }, [params]);
  const closeModal = () => { setModal(null); if (params.get('action')) { params.delete('action'); setParams(params, { replace: true }); } };

  if (loading) return <Skeleton rows={6} />;
  if (!patient) return <Empty icon={<Users className="h-5 w-5" />} title="Patient not found" action={<Button onClick={() => nav('/doctor/patients')}>Back to patients</Button>} />;

  const activeRx = rx.filter((r) => r.status === 'Active');

  return (
    <div>
      <Link to="/doctor/patients" className="mb-4 inline-flex items-center gap-1.5 text-sm font-semibold text-care-600"><ArrowLeft className="h-4 w-4" />Patients</Link>

      {/* Header */}
      <section className="panel mb-5 overflow-hidden">
        <div className="flex flex-col gap-5 p-5 md:flex-row md:items-center">
          <div className="flex flex-1 items-center gap-4">
            <Avatar name={patient.name} size={64} />
            <div>
              <h1 className="text-2xl font-extrabold">{patient.name}</h1>
              <p className="text-ink-soft">{patient.mrn} · {ageFrom(patient.dob)} years · {patient.gender} · <b className="text-ink">{patient.bloodGroup}</b> · {patient.heightCm} cm, {patient.weightKg} kg</p>
              <p className="mt-1 flex items-center gap-1.5 text-sm text-ink-soft"><Phone className="h-3.5 w-3.5" />Emergency: {patient.emergencyContact.name} ({patient.emergencyContact.relation}) {patient.emergencyContact.phone}</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button icon={<ClipboardPlus className="h-4 w-4" />} onClick={() => setModal('consult')}>Add consultation note</Button>
            <Button variant="teal" icon={<Pill className="h-4 w-4" />} onClick={() => setModal('prescribe')}>Add prescription</Button>
            <Button variant="secondary" icon={<FlaskConical className="h-4 w-4" />} onClick={() => setModal('lab')}>Request lab test</Button>
          </div>
        </div>
        <div className="flex flex-wrap gap-x-6 gap-y-2 border-t border-line bg-canvas px-5 py-3 text-sm">
          <span className="flex items-center gap-1.5"><AlertTriangle className="h-4 w-4 text-alert-600" /><b>Allergies:</b> {patient.allergies.join(', ') || 'None recorded'}</span>
          <span><b>Conditions:</b> {patient.conditions.join(', ') || 'None recorded'}</span>
          <span><b>Active medicines:</b> {activeRx.flatMap((r) => r.medications.map((m) => m.name.replace(' (demo)', ''))).join(', ') || 'None'}</span>
          <DemoTag />
        </div>
        {appt && (
          <div className="flex flex-wrap items-center gap-3 border-t border-line px-5 py-3 text-sm">
            <span className="font-semibold">Current visit:</span> {fmtDay(appt.date)}, {fmtTime(appt.time)} with {L.doctorName(appt.doctorId)} — {appt.reason} <StatusBadge status={appt.status} />
          </div>
        )}
      </section>

      <Tabs value={tab} onChange={setTab} tabs={[
        { id: 'timeline', label: 'Consultations', count: records.length },
        { id: 'labs', label: 'Lab reports', count: labs.length },
        { id: 'rx', label: 'Prescriptions', count: rx.length },
        { id: 'appts', label: 'Appointments', count: appts.length },
      ]} />

      {tab === 'timeline' && (records.length ? <RecordTimeline records={records} prescriptions={rx} labs={labs} /> : <div className="panel"><Empty icon={<ClipboardPlus className="h-5 w-5" />} title="No consultations yet" action={<Button onClick={() => setModal('consult')}>Add consultation note</Button>} /></div>)}
      {tab === 'labs' && (
        <div className="panel divide-y divide-line">
          {labs.map((l) => (
            <button key={l.id} onClick={() => setOpenLab(l)} className="flex w-full items-center gap-4 px-5 py-3.5 text-left hover:bg-canvas">
              <FlaskConical className="h-5 w-5 text-care-500" />
              <div className="flex-1"><p className="font-semibold">{l.testName}</p><p className="text-sm text-ink-soft">{l.category} · {fmtDate(l.date)} · {l.orderedById ? L.doctorName(l.orderedById) : 'Uploaded by patient'}</p></div>
              {l.parameters.some((p) => p.flag !== 'Normal') && <Badge tone="amber">Flagged</Badge>}
              <LabStatusBadge status={l.status} />
            </button>
          ))}
          {!labs.length && <Empty icon={<FlaskConical className="h-5 w-5" />} title="No lab reports" />}
        </div>
      )}
      {tab === 'rx' && <div className="space-y-4">{rx.map((p) => <PrescriptionCard key={p.id} rx={p} doctorName={L.doctorName(p.doctorId)} />)}{!rx.length && <div className="panel"><Empty icon={<Pill className="h-5 w-5" />} title="No prescriptions" /></div>}</div>}
      {tab === 'appts' && (
        <div className="panel divide-y divide-line">
          {[...appts].reverse().map((a) => (
            <div key={a.id} className="flex flex-wrap items-center gap-3 px-5 py-3 text-sm">
              <span className="w-40 font-semibold">{fmtDay(a.date)}, {fmtTime(a.time)}</span>
              <span className="flex-1 text-ink-soft">{L.doctorName(a.doctorId)} · {a.reason}</span>
              <StatusBadge status={a.status} />
            </div>
          ))}
        </div>
      )}

      <ConsultModal open={modal === 'consult'} onClose={closeModal} patientId={id} doctorId={did} appointmentId={appt?.doctorId === did ? appt.id : undefined} onSaved={() => { closeModal(); setTab('timeline'); }} />
      <PrescribeModal open={modal === 'prescribe'} onClose={closeModal} patientId={id} doctorId={did} allergies={patient.allergies} recordId={records.find((r) => r.date === today() && r.doctorId === did)?.id} onSaved={() => { closeModal(); setTab('rx'); }} />
      <LabModal open={modal === 'lab'} onClose={closeModal} patientId={id} doctorId={did} onSaved={() => { closeModal(); setTab('labs'); }} />
      <Modal wide open={!!openLab} onClose={() => setOpenLab(null)} title={openLab?.testName ?? ''}>{openLab && <LabReportView report={openLab} patient={patient} showAiLink={false} />}</Modal>
    </div>
  );
}

/* --------------------------------- Modals --------------------------------- */

function ConsultModal({ open, onClose, patientId, doctorId, appointmentId, onSaved }: { open: boolean; onClose: () => void; patientId: string; doctorId: string; appointmentId?: string; onSaved: () => void }) {
  const toast = useToast();
  const [f, setF] = useState({ chiefComplaint: '', consultationNotes: '', diagnosisByDoctor: '', followUp: addDays(14), bp: '', pulse: '', tempC: '', spo2: '' });
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const { data: appts = [] } = useData(() => services.appointments.list({ patientId }), [patientId]);
  useEffect(() => {
    const a = appts.find((x) => x.id === appointmentId);
    if (open && a && !f.chiefComplaint) setF((s) => ({ ...s, chiefComplaint: a.reason }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, appointmentId, appts.length]);
  const set = (k: keyof typeof f, v: string) => setF({ ...f, [k]: v });

  const save = async () => {
    if (!f.chiefComplaint.trim() || !f.consultationNotes.trim()) return setErr('Add the reason for visit and your notes.');
    if (f.bp && !/^\d{2,3}\/\d{2,3}$/.test(f.bp)) return setErr('Enter blood pressure as systolic/diastolic, e.g. 120/80.');
    setBusy(true); setErr(null);
    try {
      await services.records.addConsultation({
        patientId, doctorId, appointmentId, chiefComplaint: f.chiefComplaint, consultationNotes: f.consultationNotes, diagnosisByDoctor: f.diagnosisByDoctor, followUp: f.followUp || undefined,
        vitals: f.bp ? { bp: f.bp, pulse: Number(f.pulse) || 0, tempC: Number(f.tempC) || 0, spo2: Number(f.spo2) || 0 } : undefined,
      });
      toast({ tone: 'success', title: 'Consultation note saved', body: appointmentId ? 'The appointment is marked completed.' : undefined });
      setF({ chiefComplaint: '', consultationNotes: '', diagnosisByDoctor: '', followUp: addDays(14), bp: '', pulse: '', tempC: '', spo2: '' });
      onSaved();
    } catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  };

  const fill = () => setF({ ...f, chiefComplaint: f.chiefComplaint || 'Follow-up visit', consultationNotes: 'Patient reports feeling better. Energy levels improved since last visit. Advised to continue current plan and repeat blood tests as scheduled.', diagnosisByDoctor: 'Vitamin D deficiency — improving (demo entry)', bp: '118/78', pulse: '76', tempC: '36.8', spo2: '99' });

  return (
    <Modal wide open={open} onClose={onClose} title="Add consultation note"
      footer={<><Button variant="ghost" onClick={fill} className="mr-auto">Fill sample note</Button><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={save}>Save note</Button></>}>
      <div className="space-y-4">
        <div><label className="label" htmlFor="cc">Reason for visit</label><input id="cc" className="field" value={f.chiefComplaint} onChange={(e) => set('chiefComplaint', e.target.value)} /></div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <div><label className="label" htmlFor="bp">BP (mmHg)</label><input id="bp" className="field" placeholder="120/80" value={f.bp} onChange={(e) => set('bp', e.target.value)} /></div>
          <div><label className="label" htmlFor="pu">Pulse</label><input id="pu" inputMode="numeric" className="field" value={f.pulse} onChange={(e) => set('pulse', e.target.value.replace(/\D/g, ''))} /></div>
          <div><label className="label" htmlFor="tc">Temp (°C)</label><input id="tc" inputMode="decimal" className="field" value={f.tempC} onChange={(e) => set('tempC', e.target.value)} /></div>
          <div><label className="label" htmlFor="sp">SpO₂ (%)</label><input id="sp" inputMode="numeric" className="field" value={f.spo2} onChange={(e) => set('spo2', e.target.value.replace(/\D/g, ''))} /></div>
        </div>
        <div><label className="label" htmlFor="cn">Consultation notes</label><textarea id="cn" rows={4} className="field" value={f.consultationNotes} onChange={(e) => set('consultationNotes', e.target.value)} placeholder="History, examination findings, advice given" /></div>
        <div>
          <label className="label" htmlFor="dx">Diagnosis (entered by you)</label>
          <input id="dx" className="field" value={f.diagnosisByDoctor} onChange={(e) => set('diagnosisByDoctor', e.target.value)} />
          <p className="mt-1 text-xs text-ink-faint">CareConnect records your clinical judgement. It does not suggest diagnoses.</p>
        </div>
        <div className="sm:w-1/2"><label className="label" htmlFor="fu">Follow-up date</label><input id="fu" type="date" min={today()} className="field" value={f.followUp} onChange={(e) => set('followUp', e.target.value)} /></div>
        <ErrorNote message={err} />
      </div>
    </Modal>
  );
}

const blankMed = (): Medication => ({ name: '', dosage: '', frequency: '', duration: '', instructions: '' });

function PrescribeModal({ open, onClose, patientId, doctorId, allergies, recordId, onSaved }: { open: boolean; onClose: () => void; patientId: string; doctorId: string; allergies: string[]; recordId?: string; onSaved: () => void }) {
  const toast = useToast();
  const [meds, setMeds] = useState<Medication[]>([blankMed()]);
  const [notes, setNotes] = useState('');
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const upd = (i: number, k: keyof Medication, v: string) => setMeds(meds.map((m, j) => (j === i ? { ...m, [k]: v } : m)));
  const allergyHit = meds.find((m) => allergies.some((a) => m.name && m.name.toLowerCase().includes(a.toLowerCase().slice(0, 5))));

  const save = async () => {
    const incomplete = meds.some((m) => m.name.trim() && (!m.dosage.trim() || !m.frequency.trim() || !m.duration.trim()));
    if (incomplete) return setErr('Each medicine needs a dosage, frequency and duration.');
    setBusy(true); setErr(null);
    try {
      await services.records.addPrescription({ patientId, doctorId, medications: meds, notes: notes || undefined, recordId });
      toast({ tone: 'success', title: 'Prescription added', body: 'The patient has been notified.' });
      setMeds([blankMed()]); setNotes('');
      onSaved();
    } catch (e) { setErr((e as Error).message); } finally { setBusy(false); }
  };
  const fill = () => setMeds([{ name: 'Cholecalciferol 60,000 IU (demo)', dosage: '1 sachet', frequency: 'Once weekly', duration: '4 weeks', instructions: 'Take with milk after a meal' }, { name: 'Ferrous sulphate 200 mg (demo)', dosage: '1 tablet', frequency: 'Once daily after breakfast', duration: '30 days', instructions: '' }]);

  return (
    <Modal wide open={open} onClose={onClose} title="Add prescription"
      footer={<><Button variant="ghost" onClick={fill} className="mr-auto">Fill sample</Button><Button variant="secondary" onClick={onClose}>Cancel</Button><Button variant="teal" loading={busy} onClick={save}>Save prescription</Button></>}>
      <div className="space-y-4">
        {allergies.length > 0 && <p className="flex items-center gap-2 rounded-item bg-alert-50 px-3 py-2 text-sm font-semibold text-alert-600"><AlertTriangle className="h-4 w-4" />Recorded allergies: {allergies.join(', ')}</p>}
        {meds.map((m, i) => (
          <fieldset key={i} className="rounded-item border border-line p-4">
            <div className="mb-3 flex items-center justify-between"><legend className="text-sm font-bold">Medicine {i + 1}</legend>{meds.length > 1 && <button onClick={() => setMeds(meds.filter((_, j) => j !== i))} className="rounded p-1 text-ink-faint hover:text-alert-600" aria-label={`Remove medicine ${i + 1}`}><Trash2 className="h-4 w-4" /></button>}</div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="sm:col-span-2"><label className="label" htmlFor={`mn${i}`}>Medicine name and strength</label><input id={`mn${i}`} className="field" value={m.name} onChange={(e) => upd(i, 'name', e.target.value)} placeholder="e.g. Paracetamol 500 mg" /></div>
              <div><label className="label" htmlFor={`md${i}`}>Dosage</label><input id={`md${i}`} className="field" value={m.dosage} onChange={(e) => upd(i, 'dosage', e.target.value)} placeholder="1 tablet" /></div>
              <div><label className="label" htmlFor={`mf${i}`}>Frequency</label><input id={`mf${i}`} className="field" value={m.frequency} onChange={(e) => upd(i, 'frequency', e.target.value)} placeholder="Twice daily after meals" list="freq" /></div>
              <div><label className="label" htmlFor={`mdu${i}`}>Duration</label><input id={`mdu${i}`} className="field" value={m.duration} onChange={(e) => upd(i, 'duration', e.target.value)} placeholder="5 days" /></div>
              <div><label className="label" htmlFor={`mi${i}`}>Instructions (optional)</label><input id={`mi${i}`} className="field" value={m.instructions} onChange={(e) => upd(i, 'instructions', e.target.value)} /></div>
            </div>
          </fieldset>
        ))}
        <datalist id="freq"><option>Once daily</option><option>Twice daily</option><option>Three times daily</option><option>At bedtime</option><option>When needed</option></datalist>
        {allergyHit && <p className="rounded-item bg-attn-50 px-3 py-2 text-sm text-attn-600">"{allergyHit.name}" resembles a recorded allergy. Please double-check.</p>}
        <Button variant="secondary" size="sm" icon={<Plus className="h-4 w-4" />} onClick={() => setMeds([...meds, blankMed()])}>Add another medicine</Button>
        <div><label className="label" htmlFor="rxn">Note to patient (optional)</label><textarea id="rxn" rows={2} className="field" value={notes} onChange={(e) => setNotes(e.target.value)} /></div>
        <ErrorNote message={err} />
      </div>
    </Modal>
  );
}

const TESTS: [string, string][] = [['Complete Blood Count', 'Hematology'], ['Lipid Profile', 'Biochemistry'], ['HbA1c', 'Biochemistry'], ['Vitamin D (25-OH)', 'Biochemistry'], ['Thyroid Profile', 'Endocrinology'], ['Kidney Function Test', 'Biochemistry'], ['Liver Function Test', 'Biochemistry'], ['Iron Studies', 'Hematology'], ['Chest X-ray', 'Radiology']];

function LabModal({ open, onClose, patientId, doctorId, onSaved }: { open: boolean; onClose: () => void; patientId: string; doctorId: string; onSaved: () => void }) {
  const toast = useToast();
  const [test, setTest] = useState(TESTS[0][0]);
  const [comments, setComments] = useState('');
  const [busy, setBusy] = useState(false);
  const save = async () => {
    setBusy(true);
    await services.records.requestLabTest({ patientId, doctorId, testName: test, category: TESTS.find((t) => t[0] === test)![1], comments: comments || undefined });
    setBusy(false); setComments('');
    toast({ tone: 'success', title: 'Lab test requested', body: `${test} — the patient has been notified.` });
    onSaved();
  };
  return (
    <Modal open={open} onClose={onClose} title="Request lab test" footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button loading={busy} onClick={save}>Request test</Button></>}>
      <div className="space-y-4">
        <div><label className="label" htmlFor="lt">Test</label><select id="lt" className="field" value={test} onChange={(e) => setTest(e.target.value)}>{TESTS.map(([t, c]) => <option key={t} value={t}>{t} — {c}</option>)}</select></div>
        <div><label className="label" htmlFor="lc">Instructions for the lab (optional)</label><textarea id="lc" rows={3} className="field" value={comments} onChange={(e) => setComments(e.target.value)} placeholder="e.g. Fasting sample" /></div>
        <p className="text-xs text-ink-faint">Production: sent to the laboratory system as an HL7 FHIR ServiceRequest.</p>
      </div>
    </Modal>
  );
}
