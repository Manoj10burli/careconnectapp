import { Link } from 'react-router-dom';
import { AlertTriangle, CalendarPlus, ClipboardList, Droplet, FlaskConical, HeartPulse, Phone, Pill, Sparkles } from 'lucide-react';
import { services } from '@/services';
import { useData } from '@/hooks/useData';
import { useLookups } from '@/hooks/useLookups';
import { useAuth, useProfileId } from '@/context/AuthContext';
import { Badge, Button, DemoTag, Empty, FlagBadge, Panel, Skeleton } from '@/components/ui';
import { ageFrom, fmtDate, fmtTime, parseISODate, today } from '@/utils/format';

export default function PatientDashboard() {
  const pid = useProfileId();
  const { user } = useAuth();
  const L = useLookups();
  const { data: patient } = useData(() => services.users.getPatient(pid), [pid]);
  const { data: appts, loading: la } = useData(() => services.appointments.list({ patientId: pid }), [pid]);
  const { data: labs = [] } = useData(() => services.records.listLabReports(pid), [pid]);
  const { data: rx = [] } = useData(() => services.records.listPrescriptions({ patientId: pid }), [pid]);
  const { data: records = [] } = useData(() => services.records.listRecords(pid), [pid]);

  const upcoming = (appts ?? []).filter((a) => a.date >= today() && a.status !== 'Cancelled' && a.status !== 'Completed');
  const next = upcoming[0];
  const activeRx = rx.filter((r) => r.status === 'Active');
  const followUp = records.find((r) => r.followUp && r.followUp >= today());
  const flagged = labs.flatMap((l) => l.parameters.filter((p) => p.flag !== 'Normal').map((p) => ({ ...p, report: l.testName })));
  const first = user?.name.split(' ')[0];

  return (
    <div>
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-ink-soft">{new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })}</p>
          <h1 className="text-[28px] font-extrabold tracking-tight">Hello, {first}</h1>
        </div>
        <Link to="/appointments/book"><Button icon={<CalendarPlus className="h-4 w-4" />}>Book appointment</Button></Link>
      </div>

      {/* Identity strip */}
      {patient && (
        <div className="panel mb-6 grid grid-cols-2 divide-line sm:grid-cols-4 sm:divide-x">
          {[
            ['Patient', patient.name, patient.mrn],
            ['Age', `${ageFrom(patient.dob)} years`, patient.gender],
            ['Blood group', patient.bloodGroup, <span key="d" className="inline-flex items-center gap-1"><Droplet className="h-3.5 w-3.5" />On file</span>],
            ['Allergies', patient.allergies.join(', ') || 'None recorded', patient.allergies.length ? 'Shared with your care team' : ''],
          ].map(([k, v, s], i) => (
            <div key={i} className="px-5 py-4">
              <p className="text-xs font-semibold text-ink-faint">{k}</p>
              <p className="mt-0.5 font-bold">{v}</p>
              <p className="text-xs text-ink-soft">{s}</p>
            </div>
          ))}
        </div>
      )}

      <div className="grid gap-5 lg:grid-cols-3">
        {/* Next appointment */}
        <section className="overflow-hidden rounded-panel bg-care-500 text-white lg:col-span-2">
          <div className="flex items-center justify-between px-5 pt-4">
            <h2 className="font-bold">Next Appointment</h2>
            <Link to="/appointments" className="text-sm font-semibold text-care-50 hover:text-white">All appointments</Link>
          </div>
          {la ? <div className="p-5"><div className="h-24 animate-pulse rounded-item bg-white/10" /></div> : next ? (
            <div className="flex flex-col gap-5 p-5 sm:flex-row sm:items-center">
              <div className="flex h-24 w-24 shrink-0 flex-col items-center justify-center rounded-panel bg-white text-care-600">
                <span className="text-xs font-bold">{parseISODate(next.date).toLocaleDateString('en-GB', { month: 'short' })}</span>
                <span className="num text-4xl font-extrabold leading-none">{parseISODate(next.date).getDate()}</span>
                <span className="text-xs font-semibold">{parseISODate(next.date).toLocaleDateString('en-GB', { weekday: 'short' })}</span>
              </div>
              <div className="flex-1">
                <p className="text-xl font-extrabold">{L.doctorName(next.doctorId)}</p>
                <p className="text-care-50">{L.department(next.departmentId)?.name} · Room {L.doctor(next.doctorId)?.room}</p>
                <p className="mt-2 text-sm text-care-50">{fmtTime(next.time)} · {next.type} · {next.reason}</p>
              </div>
              <Badge className="self-start bg-white/15 text-white sm:self-center">{next.status}</Badge>
            </div>
          ) : (
            <div className="p-5">
              <p className="text-care-50">No upcoming appointments.</p>
              <Link to="/appointments/book" className="mt-3 inline-block rounded-item bg-white px-4 py-2 text-sm font-semibold text-care-600">Book one now</Link>
            </div>
          )}
          {upcoming.length > 1 && <p className="border-t border-white/15 px-5 py-2.5 text-sm text-care-50">+{upcoming.length - 1} more upcoming</p>}
        </section>

        {/* Emergency contact */}
        <Panel title="Emergency contact" action={<Link to="/profile" className="text-sm font-semibold text-care-600">Edit</Link>}>
          {patient ? (
            <div>
              <p className="text-lg font-bold">{patient.emergencyContact.name}</p>
              <p className="text-sm text-ink-soft">{patient.emergencyContact.relation}</p>
              <a href={`tel:${patient.emergencyContact.phone}`} className="mt-3 inline-flex items-center gap-2 rounded-item bg-teal-50 px-3 py-2 text-sm font-semibold text-teal-700"><Phone className="h-4 w-4" />{patient.emergencyContact.phone}</a>
              <p className="mt-4 text-xs text-ink-faint">In an emergency, call your local emergency number (112 in India).</p>
            </div>
          ) : <Skeleton rows={2} />}
        </Panel>

        {/* Recent reports */}
        <Panel title={<span className="flex items-center gap-2"><FlaskConical className="h-4 w-4 text-care-500" />Recent Reports</span>} action={<Link to="/lab-reports" className="text-sm font-semibold text-care-600">View all</Link>} padded={false}>
          <ul className="divide-y divide-line">
            {labs.slice(0, 4).map((l) => (
              <li key={l.id}>
                <Link to={`/lab-reports?open=${l.id}`} className="flex items-center gap-3 px-5 py-3 hover:bg-canvas">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{l.testName}</p>
                    <p className="text-xs text-ink-soft">{fmtDate(l.date)}</p>
                  </div>
                  {l.parameters.some((p) => p.flag !== 'Normal') ? <Badge tone="amber">Review</Badge> : <Badge tone="teal">{l.status}</Badge>}
                </Link>
              </li>
            ))}
            {!labs.length && <li className="px-5 py-6 text-sm text-ink-soft">No reports yet.</li>}
          </ul>
        </Panel>

        {/* Prescriptions */}
        <Panel title={<span className="flex items-center gap-2"><Pill className="h-4 w-4 text-care-500" />Prescriptions</span>} action={<Link to="/prescriptions" className="text-sm font-semibold text-care-600">View all</Link>} padded={false}>
          <ul className="divide-y divide-line">
            {activeRx.flatMap((r) => r.medications.map((m, i) => (
              <li key={r.id + i} className="px-5 py-3">
                <p className="text-sm font-semibold">{m.name}</p>
                <p className="text-xs text-ink-soft">{m.dosage} · {m.frequency} · {m.duration}</p>
              </li>
            ))).slice(0, 4)}
            {!activeRx.length && <li className="px-5 py-6 text-sm text-ink-soft">No active prescriptions.</li>}
          </ul>
        </Panel>

        {/* Health records */}
        <Panel title={<span className="flex items-center gap-2"><ClipboardList className="h-4 w-4 text-care-500" />Health Records</span>} action={<Link to="/records" className="text-sm font-semibold text-care-600">Timeline</Link>} padded={false}>
          <ul className="divide-y divide-line">
            {records.slice(0, 3).map((r) => (
              <li key={r.id} className="px-5 py-3">
                <p className="text-xs text-ink-faint">{fmtDate(r.date)} · {L.doctorName(r.doctorId)}</p>
                <p className="text-sm font-semibold">{r.chiefComplaint}</p>
              </li>
            ))}
            {!records.length && <li className="px-5 py-6 text-sm text-ink-soft">No records yet.</li>}
          </ul>
        </Panel>

        {/* Reminders */}
        <Panel title={<span className="flex items-center gap-2"><HeartPulse className="h-4 w-4 text-teal-500" />Health reminders</span>} className="lg:col-span-2">
          <ul className="grid gap-3 sm:grid-cols-2">
            {followUp && (
              <li className="rounded-item border border-line p-3.5">
                <p className="text-sm font-semibold">Follow-up due {fmtDate(followUp.followUp)}</p>
                <p className="mt-0.5 text-sm text-ink-soft">Requested by {L.doctorName(followUp.doctorId)}.</p>
                <Link to="/appointments/book" className="mt-2 inline-block text-sm font-semibold text-care-600">Book follow-up</Link>
              </li>
            )}
            {activeRx.length > 0 && (
              <li className="rounded-item border border-line p-3.5">
                <p className="text-sm font-semibold">{activeRx.reduce((n, r) => n + r.medications.length, 0)} medicines active</p>
                <p className="mt-0.5 text-sm text-ink-soft">Take them as written on your prescription.</p>
              </li>
            )}
            {flagged.length > 0 && (
              <li className="rounded-item border border-attn-600/30 bg-attn-50 p-3.5">
                <p className="flex items-center gap-1.5 text-sm font-semibold text-attn-600"><AlertTriangle className="h-4 w-4" />{flagged.length} lab values flagged by the lab</p>
                <p className="mt-0.5 text-sm text-ink-soft">{flagged.slice(0, 2).map((f) => f.name).join(', ')}. Discuss with your doctor.</p>
              </li>
            )}
            <li className="rounded-item border border-line p-3.5">
              <p className="flex items-center gap-1.5 text-sm font-semibold"><Sparkles className="h-4 w-4 text-teal-500" />Understand a report</p>
              <p className="mt-0.5 text-sm text-ink-soft">Get a plain-language summary of any document.</p>
              <Link to="/ai-assistant" className="mt-2 inline-block text-sm font-semibold text-care-600">Open AI Assistant</Link>
            </li>
          </ul>
        </Panel>

        {/* Latest values */}
        <Panel title="Latest values" action={<DemoTag />}>
          {labs.length ? (
            <ul className="space-y-2.5">
              {labs.flatMap((l) => l.parameters).filter((p) => ['Hemoglobin', 'Fasting glucose', 'Total cholesterol', 'Blood pressure'].includes(p.name)).slice(0, 4).map((p) => (
                <li key={p.name} className="flex items-center justify-between gap-2">
                  <span className="text-sm text-ink-soft">{p.name}</span>
                  <span className="flex items-center gap-2"><span className="num text-sm font-bold">{p.value} <span className="font-normal text-ink-faint">{p.unit}</span></span><FlagBadge flag={p.flag} /></span>
                </li>
              ))}
            </ul>
          ) : <Empty icon={<FlaskConical className="h-5 w-5" />} title="No values yet" />}
        </Panel>
      </div>

    </div>
  );
}
