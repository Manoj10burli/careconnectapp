import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Bell, CalendarCheck2, Check, MapPin, Video } from 'lucide-react';
import { services } from '@/services';
import { useData } from '@/hooks/useData';
import { useLookups } from '@/hooks/useLookups';
import { useProfileId } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { Avatar, Button, cx, ErrorNote, Panel } from '@/components/ui';
import type { Appointment } from '@/types';
import { addDays, fmtDay, fmtTime, parseISODate } from '@/utils/format';

const STEPS = ['Department', 'Doctor', 'Date & time', 'Confirm'];

export default function BookAppointmentPage() {
  const pid = useProfileId();
  const L = useLookups();
  const toast = useToast();
  const nav = useNavigate();
  const { data: config } = useData(() => services.admin.getConfig());
  const [step, setStep] = useState(0);
  const [depId, setDepId] = useState('');
  const [docId, setDocId] = useState('');
  const [date, setDate] = useState(addDays(0));
  const [time, setTime] = useState('');
  const [type, setType] = useState<Appointment['type']>('In-person');
  const [reason, setReason] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [booked, setBooked] = useState<Appointment | null>(null);

  const deps = L.departments.filter((d) => d.active);
  const docs = L.doctors.filter((d) => d.departmentId === depId && d.active);
  const doc = L.doctor(docId);
  const days = useMemo(() => Array.from({ length: Math.min(config?.bookingWindowDays ?? 14, 14) }, (_, i) => addDays(i)), [config]);
  const { data: slots, loading: slotsLoading } = useData(() => (docId ? services.appointments.availableSlots(docId, date) : Promise.resolve([])), [docId, date]);
  useEffect(() => setTime(''), [docId, date]);

  const canNext = [!!depId, !!docId, !!time, true][step];

  const confirm = async () => {
    setError(null); setBusy(true);
    try {
      const a = await services.appointments.book({ patientId: pid, doctorId: docId, date, time, type, reason });
      setBooked(a);
      toast({ tone: 'success', title: a.status === 'Confirmed' ? 'Appointment confirmed' : 'Appointment requested', body: 'A notification has been sent to you and your doctor.' });
    } catch (e) { setError((e as Error).message); } finally { setBusy(false); }
  };

  if (booked) {
    return (
      <div className="mx-auto max-w-lg py-6 text-center">
        <div className="rise mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-teal-500 text-white"><CalendarCheck2 className="h-8 w-8" /></div>
        <h1 className="mt-5 text-2xl font-extrabold">{booked.status === 'Confirmed' ? 'Your appointment is confirmed' : 'Your request has been sent'}</h1>
        <p className="mt-2 text-ink-soft">{booked.status === 'Confirmed' ? 'We have sent you a confirmation and will remind you before the visit.' : 'The clinic will confirm shortly. You will get a notification.'}</p>
        <div className="panel mt-6 p-5 text-left">
          <div className="flex items-center gap-3"><Avatar name={doc?.name ?? ''} tone="teal" /><div><p className="font-bold">{doc?.name}</p><p className="text-sm text-ink-soft">{L.department(depId)?.name}</p></div></div>
          <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
            <div><dt className="text-ink-faint">Date</dt><dd className="font-semibold">{fmtDay(booked.date)}</dd></div>
            <div><dt className="text-ink-faint">Time</dt><dd className="font-semibold">{fmtTime(booked.time)}</dd></div>
            <div><dt className="text-ink-faint">Type</dt><dd className="font-semibold">{booked.type}</dd></div>
            <div><dt className="text-ink-faint">Booking ID</dt><dd className="font-semibold">{booked.id.toUpperCase()}</dd></div>
          </dl>
        </div>
        <div className="mt-6 flex flex-col justify-center gap-2 sm:flex-row">
          <Button variant="secondary" icon={<Bell className="h-4 w-4" />} onClick={() => nav('/notifications')}>See notification</Button>
          <Button onClick={() => nav('/appointments')}>Go to appointments</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl">
      <Link to="/appointments" className="mb-4 inline-flex items-center gap-1.5 text-sm font-semibold text-care-600"><ArrowLeft className="h-4 w-4" />Appointments</Link>
      <h1 className="text-[28px] font-extrabold tracking-tight">Book an appointment</h1>

      <ol className="my-6 flex items-center gap-2" aria-label="Progress">
        {STEPS.map((s, i) => (
          <li key={s} className="flex flex-1 items-center gap-2">
            <span className={cx('num flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-sm font-bold', i < step ? 'bg-teal-500 text-white' : i === step ? 'bg-care-500 text-white' : 'bg-canvas text-ink-faint')}>{i < step ? <Check className="h-4 w-4" /> : i + 1}</span>
            <span className={cx('hidden text-sm font-semibold sm:block', i === step ? 'text-ink' : 'text-ink-faint')}>{s}</span>
            {i < STEPS.length - 1 && <span className="h-px flex-1 bg-line" />}
          </li>
        ))}
      </ol>

      <Panel>
        {step === 0 && (
          <fieldset>
            <legend className="mb-4 text-lg font-bold">Which department do you need?</legend>
            <div className="grid gap-3 sm:grid-cols-2">
              {deps.map((d) => (
                <button key={d.id} onClick={() => { setDepId(d.id); setDocId(''); }} aria-pressed={depId === d.id}
                  className={cx('rounded-item border p-4 text-left transition-colors', depId === d.id ? 'border-care-500 bg-care-50 ring-2 ring-care-100' : 'border-line hover:border-care-500')}>
                  <p className="font-bold">{d.name}</p>
                  <p className="mt-0.5 text-sm text-ink-soft">{d.description}</p>
                </button>
              ))}
            </div>
          </fieldset>
        )}

        {step === 1 && (
          <fieldset>
            <legend className="mb-4 text-lg font-bold">Choose a doctor in {L.department(depId)?.name}</legend>
            <div className="space-y-3">
              {docs.map((d) => (
                <button key={d.id} onClick={() => setDocId(d.id)} aria-pressed={docId === d.id}
                  className={cx('flex w-full items-center gap-4 rounded-item border p-4 text-left transition-colors', docId === d.id ? 'border-care-500 bg-care-50 ring-2 ring-care-100' : 'border-line hover:border-care-500')}>
                  <Avatar name={d.name} size={48} tone="teal" />
                  <div className="flex-1">
                    <p className="font-bold">{d.name}</p>
                    <p className="text-sm text-ink-soft">{d.specialization} · {d.qualification}</p>
                    <p className="text-xs text-ink-faint">{d.experienceYears} years experience · Room {d.room}</p>
                  </div>
                </button>
              ))}
              {!docs.length && <p className="text-ink-soft">No doctors available in this department right now.</p>}
            </div>
          </fieldset>
        )}

        {step === 2 && doc && (
          <div>
            <h2 className="mb-4 text-lg font-bold">Pick a date and time with {doc.name}</h2>
            <div className="-mx-1 flex gap-2 overflow-x-auto px-1 pb-2" role="listbox" aria-label="Date">
              {days.map((d) => {
                const dt = parseISODate(d);
                const works = doc.workingDays.includes(dt.getDay());
                return (
                  <button key={d} role="option" aria-selected={date === d} disabled={!works} onClick={() => setDate(d)}
                    className={cx('flex w-16 shrink-0 flex-col items-center rounded-item border py-2.5 transition-colors', date === d ? 'border-care-500 bg-care-500 text-white' : works ? 'border-line hover:border-care-500' : 'border-line bg-canvas text-ink-faint line-through')}>
                    <span className="text-xs font-semibold">{d === addDays(0) ? 'Today' : dt.toLocaleDateString('en-GB', { weekday: 'short' })}</span>
                    <span className="num text-xl font-extrabold">{dt.getDate()}</span>
                    <span className="text-[11px]">{dt.toLocaleDateString('en-GB', { month: 'short' })}</span>
                  </button>
                );
              })}
            </div>
            <p className="mb-3 mt-5 text-sm font-semibold">Available times on {fmtDay(date)}</p>
            {slotsLoading ? <div className="h-24 animate-pulse rounded-item bg-canvas" /> : slots && slots.length ? (
              <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
                {slots.map((s) => (
                  <button key={s.time} disabled={!s.available} onClick={() => setTime(s.time)} aria-pressed={time === s.time}
                    className={cx('num rounded-item border py-2 text-sm font-semibold transition-colors', time === s.time ? 'border-care-500 bg-care-500 text-white' : s.available ? 'border-line hover:border-care-500' : 'border-line bg-canvas text-ink-faint line-through')}>
                    {fmtTime(s.time)}
                  </button>
                ))}
              </div>
            ) : <p className="rounded-item bg-canvas p-4 text-sm text-ink-soft">{doc.name} is not available on this day. Choose another date.</p>}
            {slots && slots.length > 0 && !slots.some((s) => s.available) && <p className="mt-3 text-sm text-ink-soft">All slots are taken on this day. Try another date.</p>}
          </div>
        )}

        {step === 3 && doc && (
          <div className="space-y-5">
            <h2 className="text-lg font-bold">Review and confirm</h2>
            <div className="grid gap-3 rounded-item bg-canvas p-4 text-sm sm:grid-cols-2">
              <div><p className="text-ink-faint">Doctor</p><p className="font-semibold">{doc.name}</p></div>
              <div><p className="text-ink-faint">Department</p><p className="font-semibold">{L.department(depId)?.name}</p></div>
              <div><p className="text-ink-faint">Date</p><p className="font-semibold">{fmtDay(date)}</p></div>
              <div><p className="text-ink-faint">Time</p><p className="font-semibold">{fmtTime(time)}</p></div>
            </div>
            <fieldset>
              <legend className="label">Visit type</legend>
              <div className="grid grid-cols-2 gap-2">
                {(['In-person', 'Video'] as const).map((t) => (
                  <button key={t} onClick={() => setType(t)} aria-pressed={type === t} className={cx('flex items-center justify-center gap-2 rounded-item border py-2.5 text-sm font-semibold', type === t ? 'border-care-500 bg-care-50 text-care-600' : 'border-line')}>
                    {t === 'Video' ? <Video className="h-4 w-4" /> : <MapPin className="h-4 w-4" />}{t}
                  </button>
                ))}
              </div>
            </fieldset>
            <div>
              <label className="label" htmlFor="reason">Reason for visit</label>
              <textarea id="reason" rows={3} maxLength={300} className="field" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="For example: follow-up on recent blood tests" />
              <p className="mt-1 text-xs text-ink-faint">{reason.length}/300 · Visible to your doctor only</p>
            </div>
            <ErrorNote message={error} />
          </div>
        )}
      </Panel>

      <div className="mt-5 flex justify-between">
        <Button variant="secondary" onClick={() => (step ? setStep(step - 1) : nav('/appointments'))}>{step ? 'Back' : 'Cancel'}</Button>
        {step < 3 ? <Button disabled={!canNext} onClick={() => setStep(step + 1)}>Continue</Button>
          : <Button variant="teal" loading={busy} disabled={!reason.trim()} onClick={confirm}>Confirm appointment</Button>}
      </div>
    </div>
  );
}
