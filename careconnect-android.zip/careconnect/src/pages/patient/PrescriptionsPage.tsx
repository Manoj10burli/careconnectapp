import { useState } from 'react';
import { Pill } from 'lucide-react';
import { services } from '@/services';
import { useData } from '@/hooks/useData';
import { useLookups } from '@/hooks/useLookups';
import { useProfileId } from '@/context/AuthContext';
import { Badge, DemoTag, Empty, PageHeader, Skeleton, Tabs } from '@/components/ui';
import { PrescriptionCard } from '@/components/PrescriptionCard';

export default function PrescriptionsPage() {
  const pid = useProfileId();
  const L = useLookups();
  const [tab, setTab] = useState<'Active' | 'Completed'>('Active');
  const { data = [], loading } = useData(() => services.records.listPrescriptions({ patientId: pid }), [pid]);
  const list = data.filter((p) => p.status === tab);
  return (
    <div>
      <PageHeader title="Prescriptions" subtitle={<span className="inline-flex flex-wrap items-center gap-2">Medicines prescribed by your doctors. <DemoTag /></span>} />
      <Tabs value={tab} onChange={setTab} tabs={[{ id: 'Active', label: 'Current', count: data.filter((p) => p.status === 'Active').length }, { id: 'Completed', label: 'Past', count: data.filter((p) => p.status === 'Completed').length }]} />
      {loading ? <Skeleton /> : list.length ? (
        <div className="space-y-4">{list.map((p) => <PrescriptionCard key={p.id} rx={p} doctorName={L.doctorName(p.doctorId)} department={L.department(L.doctor(p.doctorId)?.departmentId)?.name} />)}</div>
      ) : <div className="panel"><Empty icon={<Pill className="h-5 w-5" />} title={tab === 'Active' ? 'No current prescriptions' : 'No past prescriptions'} /></div>}
      <p className="mt-6 text-xs text-ink-faint">Always take medicines exactly as your doctor prescribed. <Badge tone="grey">Sample prescriptions only</Badge></p>
    </div>
  );
}
