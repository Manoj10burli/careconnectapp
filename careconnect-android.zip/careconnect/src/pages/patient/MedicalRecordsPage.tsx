import { ClipboardList } from 'lucide-react';
import { services } from '@/services';
import { useData } from '@/hooks/useData';
import { useProfileId } from '@/context/AuthContext';
import { DemoTag, Empty, PageHeader, Skeleton } from '@/components/ui';
import { RecordTimeline } from '@/components/RecordTimeline';

export default function MedicalRecordsPage() {
  const pid = useProfileId();
  const { data: records = [], loading } = useData(() => services.records.listRecords(pid), [pid]);
  const { data: rx = [] } = useData(() => services.records.listPrescriptions({ patientId: pid }), [pid]);
  const { data: labs = [] } = useData(() => services.records.listLabReports(pid), [pid]);
  return (
    <div>
      <PageHeader title="Medical records" subtitle={<span className="inline-flex flex-wrap items-center gap-2">Every consultation, from the doctor's notes to your follow-up. <DemoTag /></span>} />
      {loading ? <Skeleton rows={4} /> : records.length ? <RecordTimeline records={records} prescriptions={rx} labs={labs} />
        : <div className="panel"><Empty icon={<ClipboardList className="h-5 w-5" />} title="No records yet" body="Records appear here after your first consultation." /></div>}
      <p className="mt-8 text-xs text-ink-faint">Diagnoses shown are entered by your treating doctor. CareConnect does not generate diagnoses.</p>
    </div>
  );
}
