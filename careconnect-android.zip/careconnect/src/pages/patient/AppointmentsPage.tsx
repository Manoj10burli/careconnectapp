import { useState } from 'react';
import { Link } from 'react-router-dom';
import { CalendarDays, CalendarPlus, Clock, MapPin, Video } from 'lucide-react';
import { services } from '@/services';
import { useData } from '@/hooks/useData';
import { useLookups } from '@/hooks/useLookups';
import { useProfileId } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { Avatar, Button, Empty, Modal, PageHeader, Skeleton, StatusBadge, Tabs } from '@/components/ui';
import type { Appointment } from '@/types';
import { fmtDay, fmtTime, today } from '@/utils/format';

type Tab = 'upcoming' | 'past' | 'cancelled';

export default function AppointmentsPage() {
  const pid = useProfileId();
  const L = useLookups();
  const toast = useToast();
  const [tab, setTab] = useState<Tab>('upcoming');
  const [cancelling, setCancelling] = useState<Appointment | null>(null);
  const [busy, setBusy] = useState(false);
  const { data = [], loading } = useData(() => services.appointments.list({ patientId: pid }), [pid]);

  const groups: Record<Tab, Appointment[]> = {
    upcoming: data.filter((a) => a.date >= today() && (a.status === 'Confirmed' || a.status === 'Pending')),
    past: data.filter((a) => a.status === 'Completed' || (a.date < today() && a.status !== 'Cancelled')).reverse(),
    cancelled: data.filter((a) => a.status === 'Cancelled').reverse(),
  };
  const list = groups[tab];

  const confirmCancel = async () => {
    if (!cancelling) return;
    setBusy(true);
    await services.appointments.cancel(cancelling.id);
    setBusy(false);
    setCancelling(null);
    toast({ tone: 'info', title: 'Appointment cancelled', body: 'The slot has been released and you have been notified.' });
  };

  return (
    <div>
      <PageHeader title="Appointments" subtitle="Your visits with CareConnect doctors." actions={<Link to="/appointments/book"><Button icon={<CalendarPlus className="h-4 w-4" />}>Book appointment</Button></Link>} />
      <Tabs value={tab} onChange={setTab} tabs={[{ id: 'upcoming', label: 'Upcoming', count: groups.upcoming.length }, { id: 'past', label: 'Previous', count: groups.past.length }, { id: 'cancelled', label: 'Cancelled', count: groups.cancelled.length }]} />
      {loading ? <Skeleton /> : list.length === 0 ? (
        <div className="panel"><Empty icon={<CalendarDays className="h-5 w-5" />} title={tab === 'upcoming' ? 'No upcoming appointments' : 'Nothing here yet'} body={tab === 'upcoming' ? 'Book a visit with any of our departments.' : undefined} action={tab === 'upcoming' && <Link to="/appointments/book"><Button>Book appointment</Button></Link>} /></div>
      ) : (
        <ul className="space-y-3">
          {list.map((a) => {
            const doc = L.doctor(a.doctorId);
            return (
              <li key={a.id} className="panel rise flex flex-col gap-4 p-4 sm:flex-row sm:items-center">
                <div className="flex items-center gap-3 sm:w-64">
                  <Avatar name={doc?.name ?? ''} tone="teal" />
                  <div>
                    <p className="font-bold">{doc?.name}</p>
                    <p className="text-sm text-ink-soft">{L.department(a.departmentId)?.name}</p>
                  </div>
                </div>
                <div className="flex-1 space-y-1 text-sm text-ink-soft">
                  <p className="flex items-center gap-2 font-semibold text-ink"><CalendarDays className="h-4 w-4 text-care-500" />{fmtDay(a.date)} <Clock className="ml-2 h-4 w-4 text-care-500" />{fmtTime(a.time)}</p>
                  <p className="flex items-center gap-2">{a.type === 'Video' ? <Video className="h-4 w-4" /> : <MapPin className="h-4 w-4" />}{a.type === 'Video' ? 'Video consultation' : `Room ${doc?.room}`} · {a.reason}</p>
                </div>
                <div className="flex items-center gap-2">
                  <StatusBadge status={a.status} />
                  {tab === 'upcoming' && <Button variant="danger" size="sm" onClick={() => setCancelling(a)}>Cancel</Button>}
                  {tab === 'past' && <Link to="/records"><Button variant="secondary" size="sm">View record</Button></Link>}
                </div>
              </li>
            );
          })}
        </ul>
      )}

      <Modal open={!!cancelling} onClose={() => setCancelling(null)} title="Cancel this appointment?"
        footer={<><Button variant="secondary" onClick={() => setCancelling(null)}>Keep appointment</Button><Button variant="danger" loading={busy} onClick={confirmCancel}>Cancel appointment</Button></>}>
        {cancelling && <p className="text-ink-soft">Your appointment with <b className="text-ink">{L.doctorName(cancelling.doctorId)}</b> on <b className="text-ink">{fmtDay(cancelling.date)} at {fmtTime(cancelling.time)}</b> will be cancelled and the slot released to other patients.</p>}
      </Modal>
    </div>
  );
}
