import { DragEvent, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { FileUp, FlaskConical, ShieldCheck, UploadCloud } from 'lucide-react';
import { services } from '@/services';
import { useData } from '@/hooks/useData';
import { useLookups } from '@/hooks/useLookups';
import { useProfileId } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { Badge, Button, cx, DemoTag, Empty, ErrorNote, LabStatusBadge, Modal, PageHeader, Skeleton } from '@/components/ui';
import { LabReportView } from '@/components/LabReportView';
import { fmtBytes, fmtDate } from '@/utils/format';

const CATEGORIES = ['Hematology', 'Biochemistry', 'Endocrinology', 'Radiology', 'Other'];

export default function LabReportsPage() {
  const pid = useProfileId();
  const L = useLookups();
  const toast = useToast();
  const [params, setParams] = useSearchParams();
  const openId = params.get('open');
  const [filter, setFilter] = useState('All');
  const [uploadOpen, setUploadOpen] = useState(false);
  const { data = [], loading } = useData(() => services.records.listLabReports(pid), [pid]);
  const open = data.find((r) => r.id === openId);
  const cats = ['All', ...Array.from(new Set(data.map((d) => d.category)))];
  const list = data.filter((r) => filter === 'All' || r.category === filter);

  return (
    <div>
      <PageHeader title="Lab reports" subtitle={<span className="inline-flex flex-wrap items-center gap-2">Results from CareConnect labs and reports you upload. <DemoTag /></span>}
        actions={<Button icon={<FileUp className="h-4 w-4" />} onClick={() => setUploadOpen(true)}>Upload report</Button>} />

      <div className="mb-4 flex gap-2 overflow-x-auto">
        {cats.map((c) => (
          <button key={c} onClick={() => setFilter(c)} className={cx('whitespace-nowrap rounded-full border px-3.5 py-1.5 text-sm font-semibold', filter === c ? 'border-care-500 bg-care-500 text-white' : 'border-line text-ink-soft hover:border-care-500')}>{c}</button>
        ))}
      </div>

      {loading ? <Skeleton rows={4} /> : !list.length ? (
        <div className="panel"><Empty icon={<FlaskConical className="h-5 w-5" />} title="No reports yet" body="Upload a report from another lab, or wait for your doctor to request tests." action={<Button onClick={() => setUploadOpen(true)}>Upload report</Button>} /></div>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {list.map((r) => {
            const flagged = r.parameters.filter((p) => p.flag !== 'Normal');
            return (
              <button key={r.id} onClick={() => setParams({ open: r.id })} className="panel rise p-4 text-left transition-colors hover:border-care-500">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-bold">{r.testName}</p>
                    <p className="text-sm text-ink-soft">{r.category} · {fmtDate(r.date)}</p>
                  </div>
                  <LabStatusBadge status={r.status} />
                </div>
                {r.parameters.length > 0 && (
                  <ul className="mt-3 space-y-1">
                    {r.parameters.slice(0, 3).map((p) => (
                      <li key={p.name} className="flex justify-between text-sm">
                        <span className="text-ink-soft">{p.name}</span>
                        <span className={cx('num font-semibold', p.flag !== 'Normal' && 'text-alert-600')}>{p.value} {p.unit}</span>
                      </li>
                    ))}
                  </ul>
                )}
                {r.file && <p className="mt-3 text-sm text-ink-soft">{r.file.fileName} · {fmtBytes(r.file.sizeBytes)}</p>}
                <div className="mt-3 flex items-center justify-between">
                  <span className="text-xs text-ink-faint">{r.orderedById ? `Ordered by ${L.doctorName(r.orderedById)}` : r.labName}</span>
                  {flagged.length > 0 && <Badge tone="amber">{flagged.length} outside range</Badge>}
                </div>
              </button>
            );
          })}
        </div>
      )}

      <Modal wide open={!!open} onClose={() => setParams({})} title={open?.testName ?? 'Report'}>
        {open && <LabReportView report={open} patient={L.patient(pid)} />}
      </Modal>

      <UploadModal open={uploadOpen} onClose={() => setUploadOpen(false)} onUploaded={(id) => { setUploadOpen(false); toast({ tone: 'success', title: 'Report uploaded', body: 'Stored securely and shared with your care team.' }); setParams({ open: id }); }} patientId={pid} />
    </div>
  );
}

function UploadModal({ open, onClose, onUploaded, patientId }: { open: boolean; onClose: () => void; onUploaded: (id: string) => void; patientId: string }) {
  const [file, setFile] = useState<File | null>(null);
  const [name, setName] = useState('');
  const [cat, setCat] = useState('Biochemistry');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [drag, setDrag] = useState(false);
  const input = useRef<HTMLInputElement>(null);

  const pick = (f?: File | null) => {
    if (!f) return;
    const err = services.documents.validate(f);
    setError(err);
    setFile(err ? null : f);
    if (!err && !name) setName(f.name.replace(/\.[^.]+$/, '').replace(/[-_]+/g, ' '));
  };
  const onDrop = (e: DragEvent) => { e.preventDefault(); setDrag(false); pick(e.dataTransfer.files[0]); };
  const submit = async () => {
    if (!file) return setError('Choose a file to upload.');
    if (!name.trim()) return setError('Give the report a name.');
    setBusy(true);
    try { const r = await services.documents.upload(file, { patientId, testName: name.trim(), category: cat }); reset(); onUploaded(r.id); }
    catch (e) { setError((e as Error).message); } finally { setBusy(false); }
  };
  const reset = () => { setFile(null); setName(''); setError(null); };

  return (
    <Modal open={open} onClose={() => { reset(); onClose(); }} title="Upload a report"
      footer={<><Button variant="secondary" onClick={() => { reset(); onClose(); }}>Cancel</Button><Button loading={busy} onClick={submit} disabled={!file}>{busy ? 'Scanning and uploading…' : 'Upload report'}</Button></>}>
      <div className="space-y-4">
        <div onDragOver={(e) => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)} onDrop={onDrop}
          className={cx('flex flex-col items-center rounded-item border-2 border-dashed px-4 py-8 text-center transition-colors', drag ? 'border-care-500 bg-care-50' : 'border-line')}>
          <UploadCloud className="h-8 w-8 text-care-500" />
          {file ? <p className="mt-2 font-semibold">{file.name} <span className="font-normal text-ink-soft">· {fmtBytes(file.size)}</span></p> : <p className="mt-2 font-semibold">Drag a file here</p>}
          <p className="text-sm text-ink-soft">PDF, PNG, JPG or TXT, up to 10 MB</p>
          <Button variant="secondary" size="sm" className="mt-3" onClick={() => input.current?.click()}>{file ? 'Choose another file' : 'Choose file'}</Button>
          <input ref={input} type="file" accept=".pdf,.png,.jpg,.jpeg,.txt,application/pdf,image/png,image/jpeg,text/plain" className="sr-only" onChange={(e) => pick(e.target.files?.[0])} />
        </div>
        <div><label className="label" htmlFor="rname">Report name</label><input id="rname" className="field" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Thyroid profile from City Lab" maxLength={80} /></div>
        <div><label className="label" htmlFor="rcat">Category</label><select id="rcat" className="field" value={cat} onChange={(e) => setCat(e.target.value)}>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></div>
        <ErrorNote message={error} />
        <p className="flex items-start gap-2 text-xs text-ink-faint"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" />In the demo, files stay in your browser. In production they are virus-scanned and stored encrypted in Azure Blob Storage, visible only to you and your care team. Please don't upload real medical documents to this demo.</p>
      </div>
    </Modal>
  );
}
