import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, CalendarCheck2, CalendarClock, CalendarX2, FlaskConical, Info, Pill, Repeat } from 'lucide-react';
import { services } from '@/services';
import { useData } from '@/hooks/useData';
import { useAuth } from '@/context/AuthContext';
import { Badge, Button, cx, Empty, PageHeader, Skeleton, Tabs } from '@/components/ui';
import type { NotificationKind } from '@/types';
import { fmtDateTime, timeAgo } from '@/utils/format';

const icon: Record<NotificationKind, JSX.Element> = {
  appointment_confirmed: <CalendarCheck2 className="h-5 w-5" />,
  appointment_reminder: <CalendarClock className="h-5 w-5" />,
  appointment_cancelled: <CalendarX2 className="h-5 w-5" />,
  lab_available: <FlaskConical className="h-5 w-5" />,
  lab_requested: <FlaskConical className="h-5 w-5" />,
  prescription_added: <Pill className="h-5 w-5" />,
  follow_up: <Repeat className="h-5 w-5" />,
  system: <Info className="h-5 w-5" />,
};
const tint: Partial<Record<NotificationKind, string>> = {
  appointment_confirmed: 'bg-teal-50 text-teal-600',
  prescription_added: 'bg-care-50 text-care-600',
  lab_available: 'bg-care-50 text-care-600',
  follow_up: 'bg-attn-50 text-attn-600',
  appointment_cancelled: 'bg-alert-50 text-alert-600',
};

export default function NotificationsPage() {
  const { user } = useAuth();
  const nav = useNavigate();
  const [tab, setTab] = useState<'all' | 'unread'>('all');
  const { data = [], loading } = useData(() => services.notifications.list(user!.id), [user?.id]);
  const list = tab === 'all' ? data : data.filter((n) => !n.read);
  const unread = data.filter((n) => !n.read).length;

  return (
    <div className="mx-auto max-w-3xl">
      <PageHeader title="Notifications" subtitle="Appointment, report, prescription and follow-up updates."
        actions={unread > 0 && <Button variant="secondary" onClick={() => services.notifications.markAllRead(user!.id)}>Mark all as read</Button>} />
      <Tabs value={tab} onChange={setTab} tabs={[{ id: 'all', label: 'All', count: data.length }, { id: 'unread', label: 'Unread', count: unread }]} />
      {loading ? <Skeleton rows={5} /> : !list.length ? <div className="panel"><Empty icon={<Bell className="h-5 w-5" />} title="You're all caught up" body="New updates will appear here." /></div> : (
        <ul className="panel divide-y divide-line overflow-hidden">
          {list.map((n) => (
            <li key={n.id}>
              <button onClick={() => { services.notifications.markRead(n.id); if (n.link) nav(n.link); }} className={cx('flex w-full gap-4 px-4 py-4 text-left transition-colors hover:bg-canvas sm:px-5', !n.read && 'bg-care-50/50')}>
                <span className={cx('flex h-10 w-10 shrink-0 items-center justify-center rounded-full', tint[n.kind] ?? 'bg-canvas text-ink-soft')}>{icon[n.kind]}</span>
                <span className="min-w-0 flex-1">
                  <span className="flex items-start justify-between gap-3">
                    <span className="font-bold text-ink">{n.title}</span>
                    <span className="shrink-0 text-xs text-ink-faint" title={fmtDateTime(n.createdAt)}>{timeAgo(n.createdAt)}</span>
                  </span>
                  <span className="mt-0.5 block text-sm text-ink-soft">{n.message}</span>
                  <span className="mt-2 flex flex-wrap gap-1.5">
                    {n.channels.map((c) => <Badge key={c} tone="grey">{c}</Badge>)}
                    {!n.read && <Badge tone="blue">Unread</Badge>}
                  </span>
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
      <p className="mt-4 text-xs text-ink-faint">Email, SMS and push are simulated in the demo. Production delivery uses Azure Communication Services and a push provider.</p>
    </div>
  );
}
