import { FormEvent, useEffect, useState } from 'react';
import { Mail, Phone, ShieldCheck } from 'lucide-react';
import { services } from '@/services';
import { useData } from '@/hooks/useData';
import { useLookups } from '@/hooks/useLookups';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { Avatar, Badge, Button, DemoTag, ErrorNote, PageHeader, Panel, Skeleton } from '@/components/ui';
import type { Patient } from '@/types';
import { ageFrom, fmtDate, fmtDateTime } from '@/utils/format';

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE = /^\+?[0-9 ()-]{8,18}$/;

export default function ProfilePage() {
  const { user } = useAuth();
  if (!user) return null;
  return user.role === 'patient' ? <PatientProfile /> : <StaffProfile />;
}

function PatientProfile() {
  const { user } = useAuth();
  const toast = useToast();
  const L = useLookups();
  const { data: patient } = useData(() => services.users.getPatient(user!.profileId!), [user?.profileId]);
  const [form, setForm] = useState<Patient | null>(null);
  const [allergies, setAllergies] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (patient && !form) { setForm(patient); setAllergies(patient.allergies.join(', ')); } }, [patient, form]);
  if (!form) return <Skeleton rows={6} />;

  const set = <K extends keyof Patient>(k: K, v: Patient[K]) => setForm({ ...form, [k]: v });
  const setEC = (k: keyof Patient['emergencyContact'], v: string) => setForm({ ...form, emergencyContact: { ...form.emergencyContact, [k]: v } });

  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!EMAIL.test(form.email)) return setError('Enter a valid email address.');
    if (!PHONE.test(form.phone) || !PHONE.test(form.emergencyContact.phone)) return setError('Enter phone numbers with 8–15 digits.');
    if (!form.emergencyContact.name.trim()) return setError('Emergency contact name is required.');
    setError(null); setBusy(true);
    const updated = await services.users.updatePatient(form.id, { ...form, allergies: allergies.split(',').map((a) => a.trim()).filter(Boolean) });
    setForm(updated); setBusy(false);
    toast({ tone: 'success', title: 'Profile saved' });
  };

  return (
    <form onSubmit={save} noValidate>
      <PageHeader title="My profile" subtitle="Keep your contact details and emergency contact up to date." actions={<Button type="submit" loading={busy}>Save changes</Button>} />
      <div className="grid gap-5 lg:grid-cols-3">
        <Panel className="lg:row-span-2">
          <div className="flex flex-col items-center text-center">
            <Avatar name={form.name} size={84} />
            <p className="mt-3 text-xl font-extrabold">{form.name}</p>
            <p className="text-sm text-ink-soft">{form.mrn}</p>
            <div className="mt-3 flex gap-2"><Badge tone="blue">{form.bloodGroup}</Badge><Badge tone="grey">{ageFrom(form.dob)} years</Badge><Badge tone="grey">{form.gender}</Badge></div>
          </div>
          <dl className="mt-6 space-y-3 text-sm">
            <div className="flex justify-between"><dt className="text-ink-faint">Date of birth</dt><dd className="font-semibold">{fmtDate(form.dob)}</dd></div>
            <div className="flex justify-between"><dt className="text-ink-faint">Height / weight</dt><dd className="num font-semibold">{form.heightCm} cm / {form.weightKg} kg</dd></div>
            <div className="flex justify-between"><dt className="text-ink-faint">Primary doctor</dt><dd className="font-semibold">{L.doctorName(form.primaryDoctorId)}</dd></div>
            <div className="flex justify-between"><dt className="text-ink-faint">Conditions on file</dt><dd className="text-right font-semibold">{form.conditions.join(', ') || 'None'}</dd></div>
          </dl>
          <p className="mt-6 flex items-center gap-2 text-xs text-ink-faint"><ShieldCheck className="h-4 w-4" />Clinical details are managed by your care team. <DemoTag /></p>
        </Panel>

        <Panel title="Contact details" className="lg:col-span-2">
          <div className="grid gap-4 sm:grid-cols-2">
            <div><label className="label" htmlFor="pn">Full name</label><input id="pn" className="field" value={form.name} onChange={(e) => set('name', e.target.value)} /></div>
            <div><label className="label" htmlFor="pe">Email</label><input id="pe" type="email" className="field" value={form.email} onChange={(e) => set('email', e.target.value)} /></div>
            <div><label className="label" htmlFor="pp">Phone</label><input id="pp" type="tel" className="field" value={form.phone} onChange={(e) => set('phone', e.target.value)} /></div>
            <div><label className="label" htmlFor="pa">Allergies</label><input id="pa" className="field" value={allergies} onChange={(e) => setAllergies(e.target.value)} placeholder="Separate with commas" /></div>
            <div className="sm:col-span-2"><label className="label" htmlFor="pad">Address</label><input id="pad" className="field" value={form.address} onChange={(e) => set('address', e.target.value)} /></div>
          </div>
        </Panel>

        <Panel title="Emergency contact" className="lg:col-span-2">
          <div className="grid gap-4 sm:grid-cols-3">
            <div><label className="label" htmlFor="en">Name</label><input id="en" className="field" value={form.emergencyContact.name} onChange={(e) => setEC('name', e.target.value)} /></div>
            <div><label className="label" htmlFor="er">Relationship</label><input id="er" className="field" value={form.emergencyContact.relation} onChange={(e) => setEC('relation', e.target.value)} /></div>
            <div><label className="label" htmlFor="ep">Phone</label><input id="ep" type="tel" className="field" value={form.emergencyContact.phone} onChange={(e) => setEC('phone', e.target.value)} /></div>
          </div>
          <div className="mt-4"><ErrorNote message={error} /></div>
        </Panel>
      </div>
    </form>
  );
}

function StaffProfile() {
  const { user } = useAuth();
  const L = useLookups();
  const doc = L.doctor(user!.profileId);
  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Profile" />
      <Panel>
        <div className="flex items-center gap-4">
          <Avatar name={user!.name} size={72} tone="teal" />
          <div>
            <p className="text-xl font-extrabold">{user!.name}</p>
            <p className="text-ink-soft">{doc ? `${doc.specialization} · ${L.department(doc.departmentId)?.name}` : 'Administrator'}</p>
          </div>
        </div>
        <dl className="mt-6 grid gap-4 text-sm sm:grid-cols-2">
          <div><dt className="text-ink-faint">Email</dt><dd className="flex items-center gap-2 font-semibold"><Mail className="h-4 w-4" />{user!.email}</dd></div>
          <div><dt className="text-ink-faint">Phone</dt><dd className="flex items-center gap-2 font-semibold"><Phone className="h-4 w-4" />{user!.phone}</dd></div>
          {doc && <>
            <div><dt className="text-ink-faint">Qualification</dt><dd className="font-semibold">{doc.qualification}</dd></div>
            <div><dt className="text-ink-faint">Room</dt><dd className="font-semibold">{doc.room}</dd></div>
            <div><dt className="text-ink-faint">Experience</dt><dd className="font-semibold">{doc.experienceYears} years</dd></div>
            <div><dt className="text-ink-faint">Clinic days</dt><dd className="font-semibold">{doc.workingDays.map((d) => ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][d]).join(', ')}</dd></div>
          </>}
          <div><dt className="text-ink-faint">Role</dt><dd><Badge tone="teal">{user!.role}</Badge></dd></div>
          <div><dt className="text-ink-faint">Last sign-in</dt><dd className="font-semibold">{user!.lastLogin ? fmtDateTime(user!.lastLogin) : '—'}</dd></div>
        </dl>
        <p className="mt-6 text-xs text-ink-faint">Staff profiles are managed by administrators. In production, identity comes from Microsoft Entra ID.</p>
      </Panel>
    </div>
  );
}
