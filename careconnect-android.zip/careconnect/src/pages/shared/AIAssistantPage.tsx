import { forwardRef, useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { AlertTriangle, CalendarDays, Check, FileSearch, FileText, FlaskConical, Info, Loader2, Pill, ShieldAlert, Sparkles, Upload } from 'lucide-react';
import { services } from '@/services';
import { useData } from '@/hooks/useData';
import { useAuth } from '@/context/AuthContext';
import { useLookups } from '@/hooks/useLookups';
import { useToast } from '@/context/ToastContext';
import { Badge, Button, cx, ErrorNote, PageHeader, Panel } from '@/components/ui';
import type { AIExtraction, LabReport, Patient } from '@/types';
import { fmtDate, fmtDateTime } from '@/utils/format';
import { DISCLAIMER } from '@/data/sampleDocuments';

interface Source { id: string; title: string; kind: string; text: string; note?: string }

const reportToText = (r: LabReport, p?: Patient, orderedBy?: string): string => [
  `${r.labName.toUpperCase()} — ${r.testName.toUpperCase()} — DEMO DATA`,
  `Patient: ${p?.name ?? ''} (DEMO)   MRN: ${p?.mrn ?? ''}`,
  `Referred by: ${orderedBy ?? '—'}`,
  `Report date: ${r.date}`,
  '',
  ...r.parameters.map((x) => `${x.name}: ${x.value.replace(/,/g, '')} ${x.unit} (ref ${x.referenceRange})${x.flag !== 'Normal' ? ` ${x.flag}` : ''}`),
  '',
  r.comments ?? 'Please correlate clinically. Repeat testing as advised by treating physician.',
].join('\n');

const STAGES = ['Reading the document', 'Finding dates, medicines and values', 'Writing a plain-language summary'];

export default function AIAssistantPage() {
  const { user } = useAuth();
  const L = useLookups();
  const toast = useToast();
  const [params] = useSearchParams();
  const { data: config } = useData(() => services.admin.getConfig());
  const { data: myReports = [] } = useData(() => (user?.role === 'patient' ? services.records.listLabReports(user.profileId) : Promise.resolve([])), [user?.id]);
  const samples = services.documents.listSampleDocuments();
  const [source, setSource] = useState<Source | null>(null);
  const [result, setResult] = useState<AIExtraction | null>(null);
  const [stage, setStage] = useState(-1);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const resultRef = useRef<HTMLDivElement>(null);

  // Deep link from a lab report: /ai-assistant?report=LR001
  useEffect(() => {
    const id = params.get('report');
    const r = myReports.find((x) => x.id === id);
    if (r && source?.id !== r.id) choose({ id: r.id, title: r.testName, kind: 'Your lab report', text: reportToText(r, L.patient(r.patientId), L.doctorName(r.orderedById)) });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params, myReports.length]);

  const choose = (s: Source) => { setSource(s); setResult(null); setError(null); };

  const onFile = async (f?: File) => {
    if (!f) return;
    try {
      const stored = await services.documents.readText(f);
      if (stored.textContent) choose({ id: stored.id, title: f.name, kind: 'Uploaded text file', text: stored.textContent.slice(0, 20000) });
      else choose({ id: stored.id, title: f.name, kind: 'Uploaded ' + (f.type === 'application/pdf' ? 'PDF' : 'image'), text: samples[0].text, note: 'Text recognition (OCR) for PDFs and images is simulated in this demo, so the sample lab report text is used. Production would use Azure AI Document Intelligence.' });
    } catch (e) { setError((e as Error).message); }
  };

  const analyze = async () => {
    if (!source) return;
    setResult(null); setError(null); setStage(0);
    const t1 = setTimeout(() => setStage(1), 550);
    const t2 = setTimeout(() => setStage(2), 1100);
    try {
      const r = await services.ai.analyzeDocument({ title: source.title, text: source.text });
      setResult(r);
      setTimeout(() => resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 50);
      if (user?.role === 'patient') {
        await services.notifications.send({ userId: user.id, kind: 'system', title: 'Document summary ready', message: `The AI Assistant finished summarising "${source.title}". Review it with your doctor.`, channels: ['In-app'], link: '/ai-assistant' });
        toast({ tone: 'success', title: 'Summary ready', body: 'We also added it to your notifications.' });
      }
    } catch (e) { setError((e as Error).message); } finally { clearTimeout(t1); clearTimeout(t2); setStage(-1); }
  };

  const flaggedNames = useMemo(() => (result?.labValues ?? []).filter((v) => v.outsideRange).map((v) => v.name.toLowerCase().split(' (')[0]), [result]);

  if (config && !config.aiAssistantEnabled) {
    return <div><PageHeader title="AI Health Document Assistant" /><Panel><p className="text-ink-soft">The AI Assistant has been turned off by your administrator.</p></Panel></div>;
  }

  return (
    <div>
      <PageHeader title="AI Health Document Assistant" subtitle="Pick a document and get the key facts in plain language. The assistant explains what a document says — it does not diagnose or suggest treatment." />
      <Disclaimer />

      <div className="mt-5 grid gap-5 lg:grid-cols-[340px_1fr]">
        {/* Source picker */}
        <div className="space-y-5">
          <Panel title="Sample documents" padded={false}>
            <ul className="divide-y divide-line">
              {samples.map((s) => (
                <li key={s.id}>
                  <button onClick={() => choose({ id: s.id, title: s.title, kind: s.kind, text: s.text })} className={cx('flex w-full items-start gap-3 px-5 py-3 text-left hover:bg-canvas', source?.id === s.id && 'bg-care-50')}>
                    <FileText className="mt-0.5 h-5 w-5 shrink-0 text-care-500" />
                    <span><span className="block text-sm font-semibold">{s.title}</span><span className="text-xs text-ink-soft">{s.kind} · {fmtDate(s.date)}</span></span>
                    {source?.id === s.id && <Check className="ml-auto h-4 w-4 text-care-600" />}
                  </button>
                </li>
              ))}
            </ul>
          </Panel>
          {myReports.filter((r) => r.parameters.length).length > 0 && (
            <Panel title="From my lab reports" padded={false}>
              <ul className="max-h-60 divide-y divide-line overflow-y-auto">
                {myReports.filter((r) => r.parameters.length).map((r) => (
                  <li key={r.id}>
                    <button onClick={() => choose({ id: r.id, title: r.testName, kind: 'Your lab report', text: reportToText(r, L.patient(r.patientId), L.doctorName(r.orderedById)) })} className={cx('flex w-full items-center gap-3 px-5 py-3 text-left hover:bg-canvas', source?.id === r.id && 'bg-care-50')}>
                      <FlaskConical className="h-5 w-5 shrink-0 text-teal-500" />
                      <span className="flex-1"><span className="block text-sm font-semibold">{r.testName}</span><span className="text-xs text-ink-soft">{fmtDate(r.date)}</span></span>
                      {source?.id === r.id && <Check className="h-4 w-4 text-care-600" />}
                    </button>
                  </li>
                ))}
              </ul>
            </Panel>
          )}
          <Panel title="Upload a document">
            <p className="text-sm text-ink-soft">TXT files are read directly. PDF and image uploads use simulated text recognition.</p>
            <Button variant="secondary" className="mt-3 w-full" icon={<Upload className="h-4 w-4" />} onClick={() => fileRef.current?.click()}>Choose file</Button>
            <input ref={fileRef} type="file" className="sr-only" accept=".txt,.pdf,.png,.jpg,.jpeg" onChange={(e) => { onFile(e.target.files?.[0]); e.target.value = ''; }} />
            <p className="mt-3 text-xs text-ink-faint">Use sample documents only. Don't upload real patient information to this demo.</p>
          </Panel>
        </div>

        {/* Preview + result */}
        <div className="min-w-0 space-y-5">
          {!source ? (
            <div className="panel flex flex-col items-center px-6 py-16 text-center">
              <div className="rounded-full bg-teal-50 p-4 text-teal-600"><FileSearch className="h-7 w-7" /></div>
              <p className="mt-4 text-lg font-bold">Choose a document to start</p>
              <p className="mt-1 max-w-sm text-sm text-ink-soft">Try the sample lab report — the assistant pulls out the dates, medicines and values and flags anything the lab marked out of range.</p>
              <Button className="mt-5" variant="teal" onClick={() => choose({ id: samples[0].id, title: samples[0].title, kind: samples[0].kind, text: samples[0].text })}>Use sample lab report</Button>
            </div>
          ) : (
            <Panel title={<span className="flex items-center gap-2"><FileText className="h-4 w-4 text-care-500" />{source.title}</span>} action={<Badge tone="grey">{source.kind}</Badge>} padded={false}>
              {source.note && <p className="flex gap-2 border-b border-line bg-care-50 px-5 py-3 text-sm text-care-700"><Info className="mt-0.5 h-4 w-4 shrink-0" />{source.note}</p>}
              <pre className="max-h-72 overflow-auto whitespace-pre-wrap break-words px-5 py-4 font-mono text-[12.5px] leading-relaxed text-ink-soft">
                {source.text.split('\n').map((line, i) => {
                  const hit = result && flaggedNames.some((n) => line.toLowerCase().includes(n));
                  return <span key={i} className={cx('block', hit && '-mx-2 rounded bg-attn-50 px-2 font-semibold text-attn-600')}>{line || ' '}</span>;
                })}
              </pre>
              <div className="flex flex-wrap items-center gap-3 border-t border-line px-5 py-3.5">
                <Button variant="teal" icon={<Sparkles className="h-4 w-4" />} onClick={analyze} loading={stage >= 0}>{result ? 'Analyse again' : 'Analyse document'}</Button>
                {result && <span className="text-sm text-ink-soft">Highlighted lines contain values the document marks as out of range.</span>}
              </div>
            </Panel>
          )}

          <ErrorNote message={error} />

          {stage >= 0 && (
            <div className="panel p-5" aria-live="polite">
              <ol className="space-y-2.5">
                {STAGES.map((s, i) => (
                  <li key={s} className={cx('flex items-center gap-3 text-sm', i > stage ? 'text-ink-faint' : 'font-semibold')}>
                    {i < stage ? <Check className="h-4 w-4 text-teal-500" /> : i === stage ? <Loader2 className="h-4 w-4 animate-spin text-care-500" /> : <span className="h-4 w-4 rounded-full border border-line" />}{s}
                  </li>
                ))}
              </ol>
            </div>
          )}

          {result && <Result ref={resultRef} r={result} />}
        </div>
      </div>
    </div>
  );
}

function Disclaimer() {
  return (
    <div role="note" className="flex gap-3 rounded-item border border-attn-600/30 bg-attn-50 px-4 py-3 text-sm text-ink">
      <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-attn-600" />
      <p><b>{DISCLAIMER}</b> It will never diagnose a condition or recommend treatment. Always talk to your doctor about your results.</p>
    </div>
  );
}

const Result = forwardRef<HTMLDivElement, { r: AIExtraction }>(({ r }, ref) => (
  <div ref={ref} className="rise scroll-mt-24 space-y-5">
    <section className="rounded-panel border border-teal-500/30 bg-teal-50 p-5">
      <p className="flex items-center gap-2 text-sm font-bold text-teal-700"><Sparkles className="h-4 w-4" />Summary in simple language</p>
      <p className="mt-2 text-[16px] leading-relaxed text-ink">{r.plainLanguageSummary}</p>
      <p className="mt-3 text-xs text-ink-soft">{r.documentType} · {r.model} · {fmtDateTime(r.generatedAt)}</p>
    </section>

    <div className="grid gap-5 md:grid-cols-2">
      <Panel title="Key information">
        <dl className="space-y-2.5 text-sm">
          {r.keyInformation.map((k) => <div key={k.label} className="grid grid-cols-[130px_1fr] gap-2"><dt className="text-ink-faint">{k.label}</dt><dd className="font-semibold">{k.value}</dd></div>)}
        </dl>
      </Panel>
      <Panel title={<span className="flex items-center gap-2"><CalendarDays className="h-4 w-4 text-care-500" />Important dates</span>}>
        {r.importantDates.length ? <ul className="space-y-2.5 text-sm">{r.importantDates.map((d, i) => <li key={i} className="flex gap-3"><span className="num w-28 shrink-0 font-bold">{d.date}</span><span className="text-ink-soft">{d.context}</span></li>)}</ul> : <p className="text-sm text-ink-soft">No dates found.</p>}
      </Panel>
      <Panel title={<span className="flex items-center gap-2"><Pill className="h-4 w-4 text-care-500" />Medications mentioned</span>}>
        {r.medications.length ? <ul className="space-y-2.5 text-sm">{r.medications.map((m, i) => <li key={i}><p className="font-bold">{m.name}</p><p className="text-ink-soft">{m.detail}</p></li>)}</ul> : <p className="text-sm text-ink-soft">No medications found.</p>}
      </Panel>
      <Panel title={<span className="flex items-center gap-2"><AlertTriangle className="h-4 w-4 text-attn-600" />Needs attention</span>}>
        <ul className="space-y-3 text-sm">{r.attentionItems.map((a, i) => <li key={i} className="border-l-2 border-attn-600 pl-3"><p className="font-bold">{a.title}</p><p className="text-ink-soft">{a.detail}</p></li>)}</ul>
      </Panel>
    </div>

    <Panel title={<span className="flex items-center gap-2"><FlaskConical className="h-4 w-4 text-care-500" />Laboratory values</span>} padded={false}>
      {r.labValues.length ? (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[480px] text-sm">
            <thead className="bg-canvas text-left text-ink-soft"><tr><th className="px-5 py-2.5 font-semibold">Test</th><th className="px-3 py-2.5 font-semibold">Value</th><th className="px-3 py-2.5 font-semibold">Reference range</th><th className="px-5 py-2.5 font-semibold">As marked in document</th></tr></thead>
            <tbody className="divide-y divide-line">
              {r.labValues.map((v, i) => (
                <tr key={i} className={v.outsideRange ? 'bg-attn-50/60' : ''}>
                  <td className="px-5 py-2.5 font-semibold">{v.name}</td>
                  <td className="num px-3 py-2.5 font-bold">{v.value}</td>
                  <td className="num px-3 py-2.5 text-ink-soft">{v.referenceRange ?? '—'}</td>
                  <td className="px-5 py-2.5">{v.outsideRange ? <Badge tone="amber">Outside range</Badge> : <Badge tone="teal">Within range</Badge>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : <p className="p-5 text-sm text-ink-soft">No laboratory values found.</p>}
    </Panel>
    <p className="text-xs text-ink-faint">{r.disclaimer}</p>
  </div>
));
Result.displayName = 'Result';
