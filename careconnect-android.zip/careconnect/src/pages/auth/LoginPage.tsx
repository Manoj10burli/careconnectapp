import { FormEvent, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldCheck, Stethoscope, User, UserCog } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import type { Role } from '@/types';
import { Button, cx, ErrorNote } from '@/components/ui';
import { Logo } from '@/components/layout/AppShell';

const roles: { id: Role; label: string; icon: JSX.Element; email: string; who: string }[] = [
  { id: 'patient', label: 'Patient', icon: <User className="h-4 w-4" />, email: 'priya.sharma@example.demo', who: 'Priya Sharma' },
  { id: 'doctor', label: 'Doctor', icon: <Stethoscope className="h-4 w-4" />, email: 'arjun.menon@careconnect.demo', who: 'Dr. Arjun Menon' },
  { id: 'admin', label: 'Admin', icon: <UserCog className="h-4 w-4" />, email: 'admin@careconnect.demo', who: 'Neha Kulkarni' },
];

export const homeFor = (r: Role) => (r === 'patient' ? '/' : `/${r}`);

export default function LoginPage() {
  const { login, demoLogin } = useAuth();
  const nav = useNavigate();
  const [role, setRole] = useState<Role>('patient');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null); setBusy('form');
    try { await login(email, password, role); nav(homeFor(role)); } catch (err) { setError((err as Error).message); } finally { setBusy(null); }
  };
  const demo = async (r: Role) => {
    setBusy(r);
    await demoLogin(r);
    nav(homeFor(r));
  };
  const current = roles.find((r) => r.id === role)!;

  return (
    <div className="grid min-h-full lg:grid-cols-[1.05fr_1fr]">
      {/* Brand side */}
      <section className="relative flex flex-col justify-between overflow-hidden bg-teal-900 px-6 py-8 text-white sm:px-12 lg:py-12">
        <Logo light />
        <div className="relative z-10 my-10 max-w-xl lg:my-0">
          <h1 className="text-[34px] font-extrabold leading-[1.08] tracking-tight sm:text-5xl lg:text-[56px]">
            Connected Healthcare.<br />
            <span className="text-teal-100">Simpler Patient Experience.</span>
          </h1>
          <p className="mt-5 max-w-md text-[17px] leading-relaxed text-teal-50/80">
            Appointments, records, prescriptions and lab reports in one place — for patients, clinicians and hospital teams.
          </p>
        </div>
        <svg viewBox="0 0 900 120" className="pointer-events-none -mx-6 -mt-6 mb-6 block w-[calc(100%+3rem)] max-w-none opacity-60 sm:-mx-12 sm:w-[calc(100%+6rem)] lg:absolute lg:inset-x-0 lg:bottom-40 lg:m-0 lg:w-full" aria-hidden>
          <path className="ecg-line" d="M0 70 H250 L270 70 L285 40 L300 100 L318 10 L338 110 L352 70 H520 L535 55 L550 70 H900" fill="none" stroke="#5FD3C7" strokeWidth="2.5" strokeLinejoin="round" />
        </svg>
        <div className="relative z-10 flex flex-wrap gap-x-8 gap-y-2 text-sm text-teal-50/70">
          <span className="flex items-center gap-2"><ShieldCheck className="h-4 w-4" /> Role-based access</span>
          <span>Prototype build · sample data only</span>
        </div>
      </section>

      {/* Sign-in side */}
      <section className="flex items-center justify-center px-5 py-10 sm:px-10">
        <div className="w-full max-w-md">
          <h2 className="text-2xl font-extrabold">Sign in</h2>
          <p className="mt-1 text-ink-soft">Choose how you use CareConnect.</p>

          <div role="tablist" className="mt-6 grid grid-cols-3 gap-1 rounded-item bg-canvas p-1">
            {roles.map((r) => (
              <button key={r.id} role="tab" aria-selected={role === r.id} onClick={() => { setRole(r.id); setError(null); }}
                className={cx('flex items-center justify-center gap-1.5 rounded-[8px] py-2 text-sm font-semibold transition-colors', role === r.id ? 'bg-white text-care-600 shadow-sm' : 'text-ink-soft hover:text-ink')}>
                {r.icon}{r.label} login
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="mt-6 space-y-4" noValidate>
            <div>
              <label className="label" htmlFor="email">Email</label>
              <input id="email" type="email" autoComplete="username" className="field" value={email} onChange={(e) => setEmail(e.target.value)} placeholder={current.email} />
            </div>
            <div>
              <label className="label" htmlFor="password">Password</label>
              <input id="password" type="password" autoComplete="current-password" className="field" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Any password works in the demo" />
            </div>
            <ErrorNote message={error} />
            <Button type="submit" className="w-full py-3" loading={busy === 'form'}>Sign in as {current.label.toLowerCase()}</Button>
            <p className="text-center text-xs text-ink-faint">Production sign-in will use Microsoft Entra ID with multi-factor authentication.</p>
          </form>

          <div className="my-7 flex items-center gap-3 text-sm text-ink-faint"><span className="h-px flex-1 bg-line" />Demo login<span className="h-px flex-1 bg-line" /></div>

          <div className="space-y-2">
            {roles.map((r) => (
              <button key={r.id} onClick={() => demo(r.id)} disabled={!!busy}
                className="flex w-full items-center gap-3 rounded-item border border-line px-4 py-3 text-left transition-colors hover:border-teal-500 hover:bg-teal-50 disabled:opacity-60">
                <span className="rounded-full bg-teal-50 p-2 text-teal-600">{r.icon}</span>
                <span className="flex-1">
                  <span className="block text-sm font-semibold">Continue as demo {r.label.toLowerCase()}</span>
                  <span className="block text-xs text-ink-soft">{r.who}</span>
                </span>
                {busy === r.id && <span className="text-xs font-semibold text-teal-600">Signing in…</span>}
              </button>
            ))}
          </div>
          <p className="mt-6 text-center text-xs leading-relaxed text-ink-faint">
            All patients, doctors and clinical values in this prototype are fictional. CareConnect does not provide diagnosis or treatment advice.
          </p>
        </div>
      </section>
    </div>
  );
}
