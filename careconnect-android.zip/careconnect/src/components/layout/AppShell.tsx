import { ReactNode, useEffect, useRef, useState } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import {
  Activity, Bell, Building2, CalendarDays, ClipboardList, FileText, FlaskConical, LayoutDashboard,
  LogOut, Menu, Pill, PlayCircle, ScrollText, Settings, Sparkles, Stethoscope, User, Users, X,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { services } from '@/services';
import { useData } from '@/hooks/useData';
import type { Role } from '@/types';
import { Avatar, cx } from '@/components/ui';
import { timeAgo } from '@/utils/format';
import { DemoGuide } from './DemoGuide';

interface NavItem { to: string; label: string; icon: ReactNode; end?: boolean; mobile?: boolean; short?: string }
const I = 'h-[18px] w-[18px]';

export const NAV: Record<Role, NavItem[]> = {
  patient: [
    { to: '/', label: 'Dashboard', short: 'Home', icon: <LayoutDashboard className={I} />, end: true, mobile: true },
    { to: '/appointments', label: 'Appointments', short: 'Visits', icon: <CalendarDays className={I} />, mobile: true },
    { to: '/records', label: 'Medical Records', icon: <ClipboardList className={I} /> },
    { to: '/lab-reports', label: 'Lab Reports', short: 'Reports', icon: <FlaskConical className={I} />, mobile: true },
    { to: '/prescriptions', label: 'Prescriptions', icon: <Pill className={I} /> },
    { to: '/ai-assistant', label: 'AI Assistant', short: 'AI', icon: <Sparkles className={I} />, mobile: true },
    { to: '/notifications', label: 'Notifications', icon: <Bell className={I} /> },
    { to: '/profile', label: 'Profile', icon: <User className={I} /> },
  ],
  doctor: [
    { to: '/doctor', label: 'Dashboard', short: 'Home', icon: <LayoutDashboard className={I} />, end: true, mobile: true },
    { to: '/doctor/appointments', label: 'Appointments', short: 'Visits', icon: <CalendarDays className={I} />, mobile: true },
    { to: '/doctor/patients', label: 'Patients', icon: <Users className={I} />, mobile: true },
    { to: '/ai-assistant', label: 'AI Assistant', short: 'AI', icon: <Sparkles className={I} />, mobile: true },
    { to: '/notifications', label: 'Notifications', icon: <Bell className={I} /> },
    { to: '/profile', label: 'Profile', icon: <User className={I} /> },
  ],
  admin: [
    { to: '/admin', label: 'Dashboard', short: 'Home', icon: <LayoutDashboard className={I} />, end: true, mobile: true },
    { to: '/admin/users', label: 'Users', icon: <Users className={I} />, mobile: true },
    { to: '/admin/doctors', label: 'Doctors', icon: <Stethoscope className={I} /> },
    { to: '/admin/departments', label: 'Departments', icon: <Building2 className={I} /> },
    { to: '/admin/appointments', label: 'Appointments', short: 'Visits', icon: <CalendarDays className={I} />, mobile: true },
    { to: '/admin/audit', label: 'Audit log', icon: <ScrollText className={I} /> },
    { to: '/admin/settings', label: 'Configuration', short: 'Settings', icon: <Settings className={I} />, mobile: true },
    { to: '/notifications', label: 'Notifications', icon: <Bell className={I} /> },
  ],
};

const roleLabel: Record<Role, string> = { patient: 'Patient portal', doctor: 'Clinician workspace', admin: 'Administration' };

export function Logo({ light }: { light?: boolean }) {
  return (
    <span className="flex items-center gap-2.5">
      <span className={cx('flex h-9 w-9 items-center justify-center rounded-item', light ? 'bg-white/15 text-white' : 'bg-teal-500 text-white')}>
        <Activity className="h-5 w-5" strokeWidth={2.5} />
      </span>
      <span className={cx('text-lg font-extrabold tracking-tight', light ? 'text-white' : 'text-ink')}>CareConnect</span>
    </span>
  );
}

function NotificationBell() {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const nav = useNavigate();
  const { data = [] } = useData(() => services.notifications.list(user!.id), [user?.id]);
  const unread = data.filter((n) => !n.read).length;
  useEffect(() => {
    const h = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);
  return (
    <div ref={ref} className="relative">
      <button onClick={() => setOpen(!open)} className="relative rounded-full p-2 text-ink-soft hover:bg-canvas" aria-label={`Notifications, ${unread} unread`}>
        <Bell className="h-5 w-5" />
        {unread > 0 && <span className="num absolute right-0.5 top-0.5 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-alert-600 px-1 text-[11px] font-bold text-white">{unread}</span>}
      </button>
      {open && (
        <div className="rise absolute right-0 z-50 mt-2 w-[min(22rem,calc(100vw-2rem))] overflow-hidden rounded-panel border border-line bg-white shadow-xl shadow-ink/10">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <p className="font-bold">Notifications</p>
            {unread > 0 && <button className="text-sm font-semibold text-care-600" onClick={() => services.notifications.markAllRead(user!.id)}>Mark all read</button>}
          </div>
          <ul className="max-h-80 overflow-y-auto">
            {data.slice(0, 6).map((n) => (
              <li key={n.id}>
                <button onClick={() => { services.notifications.markRead(n.id); setOpen(false); if (n.link) nav(n.link); }} className={cx('flex w-full gap-3 px-4 py-3 text-left hover:bg-canvas', !n.read && 'bg-care-50/60')}>
                  <span className={cx('mt-1.5 h-2 w-2 shrink-0 rounded-full', n.read ? 'bg-transparent' : 'bg-care-500')} />
                  <span className="min-w-0">
                    <span className="block text-sm font-semibold text-ink">{n.title}</span>
                    <span className="line-clamp-2 block text-sm text-ink-soft">{n.message}</span>
                    <span className="mt-0.5 block text-xs text-ink-faint">{timeAgo(n.createdAt)}</span>
                  </span>
                </button>
              </li>
            ))}
            {!data.length && <li className="px-4 py-6 text-center text-sm text-ink-soft">No notifications yet.</li>}
          </ul>
          <Link to="/notifications" onClick={() => setOpen(false)} className="block border-t border-line px-4 py-2.5 text-center text-sm font-semibold text-care-600 hover:bg-canvas">View all notifications</Link>
        </div>
      )}
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth();
  const [drawer, setDrawer] = useState(false);
  const [guide, setGuide] = useState(false);
  const loc = useLocation();
  const nav = useNavigate();
  useEffect(() => { setDrawer(false); window.scrollTo(0, 0); }, [loc.pathname]);
  useEffect(() => {
    if (!drawer) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setDrawer(false);
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [drawer]);
  if (!user) return null;
  const items = NAV[user.role];

  const doLogout = async () => { await logout(); nav('/login'); };

  const sidebar = (
    <nav aria-label="Main" className="flex h-full flex-col">
      <div className="px-5 pb-2 pt-5"><Logo /></div>
      <p className="px-5 pb-4 text-sm text-ink-faint">{roleLabel[user.role]}</p>
      <ul className="flex-1 space-y-0.5 px-3">
        {items.map((it) => (
          <li key={it.to}>
            <NavLink to={it.to} end={it.end} className={({ isActive }) => cx('flex items-center gap-3 rounded-item px-3 py-2.5 text-[15px] font-semibold transition-colors', isActive ? 'bg-care-50 text-care-600' : 'text-ink-soft hover:bg-canvas hover:text-ink')}>
              {it.icon}{it.label}
            </NavLink>
          </li>
        ))}
      </ul>
      <div className="m-3 rounded-item border border-line p-3">
        <div className="flex items-center gap-3">
          <Avatar name={user.name} size={36} tone={user.role === 'patient' ? 'blue' : 'teal'} />
          <div className="min-w-0">
            <p className="truncate text-sm font-bold">{user.name}</p>
            <p className="truncate text-xs text-ink-faint">{user.email}</p>
          </div>
        </div>
        <button onClick={doLogout} className="mt-3 flex w-full items-center justify-center gap-2 rounded-item border border-line py-2 text-sm font-semibold text-ink-soft hover:border-alert-600/40 hover:text-alert-600">
          <LogOut className="h-4 w-4" /> Sign out
        </button>
      </div>
    </nav>
  );

  const mobileItems = items.filter((i) => i.mobile).slice(0, 4);

  return (
    <div className="min-h-full bg-white">
      <div className="no-print bg-attn-50 px-4 py-1.5 text-center text-xs font-semibold text-attn-600">
        Demo prototype — all people and clinical values are fictional. Not for medical use.
      </div>
      <aside className="fixed bottom-0 left-0 top-[28px] hidden w-64 border-r border-line bg-white lg:block">{sidebar}</aside>

      {drawer && (
        <div className="fixed inset-0 z-50 bg-ink/40 lg:hidden" onClick={() => setDrawer(false)}>
          <aside role="dialog" aria-modal="true" aria-label="Menu" className="rise h-full w-72 bg-white pt-[env(safe-area-inset-top,0px)]" onClick={(e) => e.stopPropagation()}>
            <button className="absolute left-60 top-5 rounded-full p-1.5 text-ink-soft" onClick={() => setDrawer(false)} aria-label="Close menu"><X className="h-5 w-5" /></button>
            {sidebar}
          </aside>
        </div>
      )}

      <div className="lg:pl-64">
        <header className="sticky top-[env(safe-area-inset-top,0px)] z-40 flex h-16 items-center gap-3 border-b border-line bg-white/95 px-4 backdrop-blur sm:px-6">
          <button className="rounded-full p-2 text-ink-soft hover:bg-canvas lg:hidden" onClick={() => setDrawer(true)} aria-label="Open menu"><Menu className="h-5 w-5" /></button>
          <div className="lg:hidden"><Logo /></div>
          <div className="ml-auto flex items-center gap-1.5">
            <button onClick={() => setGuide(true)} className="hidden items-center gap-2 rounded-full border border-teal-500/40 bg-teal-50 px-3.5 py-1.5 text-sm font-semibold text-teal-700 hover:bg-teal-100 sm:flex">
              <PlayCircle className="h-4 w-4" /> Demo walkthrough
            </button>
            <button onClick={() => setGuide(true)} className="rounded-full p-2 text-teal-600 sm:hidden" aria-label="Demo walkthrough"><PlayCircle className="h-5 w-5" /></button>
            <NotificationBell />
            <Link to="/profile" className="ml-1 hidden sm:block" aria-label="Profile"><Avatar name={user.name} size={34} tone={user.role === 'patient' ? 'blue' : 'teal'} /></Link>
          </div>
        </header>
        <main className="mx-auto max-w-6xl px-4 pb-28 pt-6 sm:px-6 lg:pb-12">{children}</main>
      </div>

      <nav aria-label="Quick" className="no-print fixed inset-x-0 bottom-0 z-40 grid border-t border-line bg-white pb-[env(safe-area-inset-bottom,0px)] lg:hidden" style={{ gridTemplateColumns: `repeat(${mobileItems.length + 1}, 1fr)` }}>
        {mobileItems.map((it) => (
          <NavLink key={it.to} to={it.to} end={it.end} className={({ isActive }) => cx('flex flex-col items-center gap-0.5 py-2 text-[11px] font-semibold', isActive ? 'text-care-600' : 'text-ink-faint')}>
            {it.icon}<span className="truncate">{it.short ?? it.label}</span>
          </NavLink>
        ))}
        <button onClick={() => setDrawer(true)} className="flex flex-col items-center gap-0.5 py-2 text-[11px] font-semibold text-ink-faint"><FileText className={I} />More</button>
      </nav>

      <DemoGuide open={guide} onClose={() => setGuide(false)} />
    </div>
  );
}
