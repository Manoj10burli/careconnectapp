import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Check, Loader2, X } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import type { Role } from '@/types';
import { cx } from '@/components/ui';

interface Step { role: Role; path: string; title: string; hint: string }

/** The customer-demo storyline, in order. */
export const DEMO_STEPS: Step[] = [
  { role: 'patient', path: '/', title: 'Patient signs in and sees the dashboard', hint: 'Priya Sharma, the demo patient, sees her next visit, reports and medicines at a glance.' },
  { role: 'patient', path: '/appointments/book', title: 'Patient books an appointment', hint: 'Choose General Medicine → Dr. Arjun Menon → today or tomorrow → a free slot → confirm.' },
  { role: 'patient', path: '/notifications', title: 'Patient receives confirmation', hint: 'A confirmation arrives instantly (in-app, plus email/SMS once connected).' },
  { role: 'doctor', path: '/doctor', title: 'Doctor signs in and sees the appointment', hint: "Dr. Arjun Menon's day, including the new booking from Priya." },
  { role: 'doctor', path: '/doctor/patients/P001', title: 'Doctor opens the patient record', hint: 'Review previous consultations, labs and prescriptions on the timeline.' },
  { role: 'doctor', path: '/doctor/patients/P001?action=consult', title: 'Doctor adds a consultation note', hint: 'Record notes, the doctor-entered diagnosis and a follow-up date.' },
  { role: 'doctor', path: '/doctor/patients/P001?action=prescribe', title: 'Doctor adds a prescription', hint: 'Add one or more medicines. The patient is notified.' },
  { role: 'patient', path: '/prescriptions', title: 'Patient sees the updated prescription', hint: 'The new prescription appears at the top, marked Active.' },
  { role: 'patient', path: '/lab-reports', title: 'Patient uploads or selects a lab report', hint: 'Upload a PDF/image/TXT or open an existing report.' },
  { role: 'patient', path: '/ai-assistant', title: 'AI Assistant summarises the sample report', hint: 'Extracts dates, medicines and lab values in plain language — no diagnosis.' },
  { role: 'patient', path: '/notifications', title: 'Patient receives notifications', hint: 'Prescription, lab and follow-up notifications in one place.' },
];

export function DemoGuide({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { user, demoLogin } = useAuth();
  const nav = useNavigate();
  const loc = useLocation();
  const [busy, setBusy] = useState<number | null>(null);
  const [done, setDone] = useState<Set<number>>(new Set());
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;

  const go = async (i: number) => {
    const s = DEMO_STEPS[i];
    setBusy(i);
    if (user?.role !== s.role || (s.role === 'patient' && user.profileId !== 'P001') || (s.role === 'doctor' && user.profileId !== 'D001')) await demoLogin(s.role);
    setBusy(null);
    setDone((d) => new Set(d).add(i));
    nav(s.path);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[65] flex justify-end bg-ink/30" onClick={onClose}>
      <aside onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true" aria-label="Demo walkthrough" className="rise flex h-full w-full max-w-md flex-col bg-white pt-[env(safe-area-inset-top,0px)] shadow-2xl">
        <header className="flex items-start justify-between border-b border-line p-5">
          <div>
            <h2 className="text-lg font-extrabold">Demo walkthrough</h2>
            <p className="mt-1 text-sm text-ink-soft">The end-to-end story for a customer presentation. Each step signs in as the right person and opens the right screen.</p>
          </div>
          <button onClick={onClose} className="rounded-full p-1.5 text-ink-soft hover:bg-canvas" aria-label="Close"><X className="h-5 w-5" /></button>
        </header>
        <ol className="flex-1 overflow-y-auto p-3">
          {DEMO_STEPS.map((s, i) => {
            const here = user?.role === s.role && loc.pathname === s.path.split('?')[0];
            return (
              <li key={i}>
                <button onClick={() => go(i)} className={cx('flex w-full gap-3 rounded-item p-3 text-left hover:bg-canvas', here && 'bg-care-50')}>
                  <span className={cx('num mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-sm font-bold', done.has(i) ? 'bg-teal-500 text-white' : 'border border-line text-ink-soft')}>
                    {busy === i ? <Loader2 className="h-4 w-4 animate-spin" /> : done.has(i) ? <Check className="h-4 w-4" /> : i + 1}
                  </span>
                  <span>
                    <span className="block text-[15px] font-semibold text-ink">{s.title}</span>
                    <span className="mt-0.5 block text-sm text-ink-soft">{s.hint}</span>
                    <span className="mt-1 inline-block text-xs font-semibold capitalize text-teal-600">As {s.role}</span>
                  </span>
                </button>
              </li>
            );
          })}
        </ol>
      </aside>
    </div>
  );
}
