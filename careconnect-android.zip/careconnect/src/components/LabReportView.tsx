import { Download, FileText, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { LabReport, Patient } from '@/types';
import { useLookups } from '@/hooks/useLookups';
import { useToast } from '@/context/ToastContext';
import { Button, DemoTag, FlagBadge, LabStatusBadge } from './ui';
import { ageFrom, fmtBytes, fmtDate } from '@/utils/format';
import { buildSamplePdf, saveFile } from '@/utils/samplePdf';

export function LabReportView({ report, patient, showAiLink = true }: { report: LabReport; patient?: Patient; showAiLink?: boolean }) {
  const L = useLookups();
  const toast = useToast();

  const download = async () => {
    const lines = [
      `Patient: ${patient?.name ?? ''} (DEMO)   MRN: ${patient?.mrn ?? ''}`,
      `Test: ${report.testName}   Category: ${report.category}`,
      `Date: ${fmtDate(report.date)}   Lab: ${report.labName}`,
      `Ordered by: ${L.doctorName(report.orderedById)}`,
      '',
      'PARAMETER / RESULT / UNIT / REFERENCE RANGE / FLAG',
      ...report.parameters.map((p) => `${p.name}: ${p.value} ${p.unit}   (ref ${p.referenceRange})   ${p.flag}`),
      '',
      report.comments ?? 'Please correlate clinically.',
    ];
    try {
      const how = await saveFile(buildSamplePdf(`CareConnect - ${report.testName}`, lines), `${report.testName.replace(/\W+/g, '-')}-sample.pdf`);
      if (how === 'downloaded') toast({ tone: 'success', title: 'Sample PDF generated', body: 'If your browser blocks downloads here, open the demo in a new tab.' });
    } catch {
      toast({ tone: 'error', title: 'Could not save the PDF', body: 'Check storage space and try again.' });
    }
  };

  return (
    <div>
      {/* Paper-style document */}
      <article className="rounded-item border border-line bg-white shadow-sm">
        <header className="flex flex-wrap items-start justify-between gap-3 border-b-2 border-teal-500 p-5">
          <div>
            <p className="text-lg font-extrabold text-teal-700">{report.labName}</p>
            <p className="text-xs text-ink-faint">Sample laboratory report · generated for demonstration</p>
          </div>
          <DemoTag />
        </header>
        <dl className="grid grid-cols-2 gap-x-6 gap-y-2 border-b border-line p-5 text-sm sm:grid-cols-3">
          <div><dt className="text-ink-faint">Patient</dt><dd className="font-semibold">{patient?.name ?? '—'}</dd></div>
          <div><dt className="text-ink-faint">Age / Sex</dt><dd className="font-semibold">{patient ? `${ageFrom(patient.dob)} / ${patient.gender[0]}` : '—'}</dd></div>
          <div><dt className="text-ink-faint">MRN</dt><dd className="font-semibold">{patient?.mrn ?? '—'}</dd></div>
          <div><dt className="text-ink-faint">Test</dt><dd className="font-semibold">{report.testName}</dd></div>
          <div><dt className="text-ink-faint">Report date</dt><dd className="font-semibold">{fmtDate(report.date)}</dd></div>
          <div><dt className="text-ink-faint">Status</dt><dd><LabStatusBadge status={report.status} /></dd></div>
        </dl>
        {report.parameters.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[520px] text-sm">
              <thead className="bg-canvas text-left text-ink-soft">
                <tr><th className="px-5 py-2.5 font-semibold">Parameter</th><th className="px-3 py-2.5 font-semibold">Result</th><th className="px-3 py-2.5 font-semibold">Reference range</th><th className="px-5 py-2.5 font-semibold">Flag</th></tr>
              </thead>
              <tbody className="divide-y divide-line">
                {report.parameters.map((p) => (
                  <tr key={p.name}>
                    <td className="px-5 py-3 font-semibold">{p.name}</td>
                    <td className={`num px-3 py-3 font-bold ${p.flag !== 'Normal' ? 'text-alert-600' : ''}`}>{p.value} <span className="font-normal text-ink-faint">{p.unit}</span></td>
                    <td className="num px-3 py-3 text-ink-soft">{p.referenceRange}</td>
                    <td className="px-5 py-3"><FlagBadge flag={p.flag} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : report.file ? (
          <div className="flex items-center gap-3 p-5">
            <FileText className="h-8 w-8 text-care-500" />
            <div><p className="font-semibold">{report.file.fileName}</p><p className="text-sm text-ink-soft">{report.file.mimeType} · {fmtBytes(report.file.sizeBytes)} · uploaded {fmtDate(report.file.uploadedAt)}</p></div>
          </div>
        ) : (
          <p className="p-5 text-sm text-ink-soft">{report.status === 'Requested' ? 'This test has been requested. Results will appear here once the lab publishes them.' : 'No structured values — see attached document.'}</p>
        )}
        <footer className="border-t border-line p-5 text-xs text-ink-faint">
          {report.comments ?? 'Flags compare each value with the laboratory reference range only. Your doctor interprets results in the context of your health.'}
          <br />Ordered by {L.doctorName(report.orderedById)}.
        </footer>
      </article>
      <div className="mt-4 flex flex-wrap gap-2">
        {report.status !== 'Requested' && <Button variant="secondary" icon={<Download className="h-4 w-4" />} onClick={download}>Download sample PDF</Button>}
        {showAiLink && report.status !== 'Requested' && <Link to={`/ai-assistant?report=${report.id}`}><Button variant="teal" icon={<Sparkles className="h-4 w-4" />}>Explain with AI Assistant</Button></Link>}
      </div>
    </div>
  );
}
