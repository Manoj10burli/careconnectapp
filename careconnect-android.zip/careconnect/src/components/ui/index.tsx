import { ButtonHTMLAttributes, ReactNode, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Loader2, X } from 'lucide-react';
import type { AppointmentStatus, LabFlag, LabStatus } from '@/types';
import { initials } from '@/utils/format';

export const cx = (...c: (string | false | null | undefined)[]) => c.filter(Boolean).join(' ');

/* ---------- Button ---------- */
type Variant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'teal';
const variants: Record<Variant, string> = {
  primary: 'bg-care-500 text-white hover:bg-care-600 disabled:bg-care-100 disabled:text-care-500',
  teal: 'bg-teal-500 text-white hover:bg-teal-600 disabled:opacity-50',
  secondary: 'border border-line bg-white text-ink hover:border-care-500 hover:text-care-600 disabled:opacity-50',
  ghost: 'text-care-600 hover:bg-care-50 disabled:opacity-50',
  danger: 'border border-alert-600/30 bg-white text-alert-600 hover:bg-alert-50 disabled:opacity-50',
};
export function Button({ variant = 'primary', size = 'md', loading, icon, children, className, ...rest }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; size?: 'sm' | 'md'; loading?: boolean; icon?: ReactNode }) {
  return (
    <button {...rest} disabled={rest.disabled || loading} className={cx('inline-flex items-center justify-center gap-2 rounded-item font-semibold transition-colors', size === 'sm' ? 'px-3 py-1.5 text-sm' : 'px-4 py-2.5 text-sm', variants[variant], className)}>
      {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : icon}
      {children}
    </button>
  );
}

/* ---------- Panel ---------- */
export function Panel({ title, action, children, className, padded = true }: { title?: ReactNode; action?: ReactNode; children: ReactNode; className?: string; padded?: boolean }) {
  return (
    <section className={cx('panel', className)}>
      {(title || action) && (
        <header className="flex items-center justify-between gap-3 border-b border-line px-5 py-3.5">
          <h2 className="text-[15px] font-bold text-ink">{title}</h2>
          {action}
        </header>
      )}
      <div className={padded ? 'p-5' : ''}>{children}</div>
    </section>
  );
}

/* ---------- Page header ---------- */
export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-ink sm:text-[28px]">{title}</h1>
        {subtitle && <p className="mt-1 text-[15px] text-ink-soft">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

/* ---------- Badges ---------- */
const tones = {
  blue: 'bg-care-50 text-care-700',
  teal: 'bg-teal-50 text-teal-700',
  amber: 'bg-attn-50 text-attn-600',
  red: 'bg-alert-50 text-alert-600',
  grey: 'bg-canvas text-ink-soft border border-line',
};
export type Tone = keyof typeof tones;
export function Badge({ tone = 'grey', children, className }: { tone?: Tone; children: ReactNode; className?: string }) {
  return <span className={cx('inline-flex items-center gap-1 whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold', tones[tone], className)}>{children}</span>;
}
export const StatusBadge = ({ status }: { status: AppointmentStatus }) => (
  <Badge tone={({ Pending: 'amber', Confirmed: 'blue', Completed: 'teal', Cancelled: 'grey' } as const)[status]}>{status}</Badge>
);
export const FlagBadge = ({ flag }: { flag: LabFlag }) => (
  <Badge tone={flag === 'Normal' ? 'teal' : flag === 'High' ? 'red' : 'amber'}>{flag === 'Normal' ? 'In range' : flag}</Badge>
);
export const LabStatusBadge = ({ status }: { status: LabStatus }) => (
  <Badge tone={status === 'Available' ? 'teal' : status === 'Requested' ? 'amber' : 'blue'}>{status}</Badge>
);

/** Small marker that makes demo data unmistakable wherever values appear. */
export const DemoTag = ({ className }: { className?: string }) => (
  <span className={cx('rounded border border-attn-600/30 bg-attn-50 px-1.5 py-px text-[11px] font-bold text-attn-600', className)}>Demo data</span>
);

/* ---------- Avatar ---------- */
export function Avatar({ name, size = 40, tone = 'blue' }: { name: string; size?: number; tone?: 'blue' | 'teal' }) {
  return (
    <span aria-hidden style={{ width: size, height: size, fontSize: size * 0.36 }} className={cx('inline-flex shrink-0 items-center justify-center rounded-full font-bold', tone === 'blue' ? 'bg-care-100 text-care-700' : 'bg-teal-100 text-teal-700')}>
      {initials(name)}
    </span>
  );
}

/* ---------- Modal ---------- */
export function Modal({ open, onClose, title, children, footer, wide }: { open: boolean; onClose: () => void; title: string; children: ReactNode; footer?: ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    ref.current?.querySelector<HTMLElement>('input,select,textarea,button')?.focus();
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center bg-ink/40 p-0 sm:items-center sm:p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div ref={ref} role="dialog" aria-modal="true" aria-label={title} className={cx('rise flex max-h-[92vh] w-full flex-col rounded-t-panel bg-white shadow-2xl sm:rounded-panel', wide ? 'sm:max-w-3xl' : 'sm:max-w-lg')}>
        <header className="flex items-center justify-between border-b border-line px-5 py-4">
          <h2 className="text-lg font-bold text-ink">{title}</h2>
          <button onClick={onClose} className="rounded-full p-1.5 text-ink-soft hover:bg-canvas" aria-label="Close"><X className="h-5 w-5" /></button>
        </header>
        <div className="overflow-y-auto px-5 py-5">{children}</div>
        {footer && <footer className="flex justify-end gap-2 border-t border-line px-5 py-3.5">{footer}</footer>}
      </div>
    </div>
  );
}

/* ---------- States ---------- */
export function Empty({ icon, title, body, action }: { icon: ReactNode; title: string; body?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center px-6 py-10 text-center">
      <div className="mb-3 rounded-full bg-care-50 p-3 text-care-500">{icon}</div>
      <p className="font-semibold text-ink">{title}</p>
      {body && <p className="mt-1 max-w-sm text-sm text-ink-soft">{body}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export const Skeleton = ({ rows = 3 }: { rows?: number }) => (
  <div className="space-y-3" aria-busy="true" aria-label="Loading">
    {Array.from({ length: rows }).map((_, i) => <div key={i} className="h-14 animate-pulse rounded-item bg-canvas" />)}
  </div>
);

/* ---------- Tabs ---------- */
export function Tabs<T extends string>({ tabs, value, onChange }: { tabs: { id: T; label: string; count?: number }[]; value: T; onChange: (t: T) => void }) {
  return (
    <div role="tablist" className="mb-5 flex gap-1 overflow-x-auto border-b border-line">
      {tabs.map((t) => (
        <button key={t.id} role="tab" aria-selected={value === t.id} onClick={() => onChange(t.id)}
          className={cx('-mb-px whitespace-nowrap border-b-2 px-3.5 py-2.5 text-sm font-semibold transition-colors', value === t.id ? 'border-care-500 text-care-600' : 'border-transparent text-ink-soft hover:text-ink')}>
          {t.label}{t.count !== undefined && <span className="ml-1.5 text-ink-faint">{t.count}</span>}
        </button>
      ))}
    </div>
  );
}

/* ---------- Stat tile ---------- */
export function Stat({ label, value, icon, to, tone = 'blue' }: { label: string; value: ReactNode; icon: ReactNode; to?: string; tone?: 'blue' | 'teal' | 'amber' }) {
  const inner = (
    <div className="flex items-center gap-4 p-4">
      <div className={cx('rounded-item p-2.5', tone === 'blue' ? 'bg-care-50 text-care-600' : tone === 'teal' ? 'bg-teal-50 text-teal-600' : 'bg-attn-50 text-attn-600')}>{icon}</div>
      <div>
        <p className="num text-2xl font-extrabold text-ink">{value}</p>
        <p className="text-sm text-ink-soft">{label}</p>
      </div>
    </div>
  );
  return to ? <Link to={to} className="panel block hover:border-care-500">{inner}</Link> : <div className="panel">{inner}</div>;
}

/* ---------- Form field ---------- */
export function Field({ label, hint, children, htmlFor }: { label: string; hint?: string; children: ReactNode; htmlFor?: string }) {
  return (
    <div>
      <label className="label" htmlFor={htmlFor}>{label}</label>
      {children}
      {hint && <p className="mt-1 text-xs text-ink-faint">{hint}</p>}
    </div>
  );
}

export function ErrorNote({ message }: { message: string | null }) {
  if (!message) return null;
  return <p role="alert" className="rounded-item bg-alert-50 px-3 py-2 text-sm font-medium text-alert-600">{message}</p>;
}
