import type { Prescription } from '@/types';
import { Badge } from './ui';
import { fmtDate, today } from '@/utils/format';

export function PrescriptionCard({ rx, doctorName, department }: { rx: Prescription; doctorName: string; department?: string }) {
  return (
    <article className="panel rise overflow-hidden">
      <header className="flex flex-wrap items-center justify-between gap-2 border-b border-line bg-canvas px-5 py-3">
        <div>
          <p className="font-bold">{doctorName}{department && <span className="font-normal text-ink-soft"> · {department}</span>}</p>
          <p className="text-sm text-ink-soft">Prescribed {fmtDate(rx.date)} · {rx.id.toUpperCase()}</p>
        </div>
        <div className="flex gap-2">
          {rx.date === today() && <Badge tone="blue">New</Badge>}
          <Badge tone={rx.status === 'Active' ? 'teal' : 'grey'}>{rx.status}</Badge>
        </div>
      </header>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[560px] text-sm">
          <thead className="text-left text-ink-faint">
            <tr><th className="px-5 pb-1 pt-3 font-semibold">Medicine</th><th className="px-3 pb-1 pt-3 font-semibold">Dosage</th><th className="px-3 pb-1 pt-3 font-semibold">Frequency</th><th className="px-5 pb-1 pt-3 font-semibold">Duration</th></tr>
          </thead>
          <tbody>
            {rx.medications.map((m, i) => (
              <tr key={i} className="align-top">
                <td className="px-5 py-2.5"><p className="font-bold">{m.name}</p>{m.instructions && <p className="text-xs text-ink-soft">{m.instructions}</p>}</td>
                <td className="px-3 py-2.5">{m.dosage}</td>
                <td className="px-3 py-2.5">{m.frequency}</td>
                <td className="px-5 py-2.5">{m.duration}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {rx.notes && <p className="border-t border-line px-5 py-3 text-sm text-ink-soft">Doctor's note: {rx.notes}</p>}
    </article>
  );
}
