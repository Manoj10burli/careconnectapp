import type { ReactNode } from 'react';
import { CalendarClock, FlaskConical, Pill, Stethoscope, FileSignature } from 'lucide-react';
import type { LabReport, MedicalRecord, Prescription } from '@/types';
import { useLookups } from '@/hooks/useLookups';
import { Badge, DemoTag } from './ui';
import { fmtDate, today } from '@/utils/format';

/** Date → Consultation → Diagnosis (doctor-entered) → Prescription → Lab tests → Follow-up */
export function RecordTimeline({ records, prescriptions, labs }: { records: MedicalRecord[]; prescriptions: Prescription[]; labs: LabReport[] }) {
  const L = useLookups();
  return (
    <ol className="relative space-y-6 before:absolute before:bottom-2 before:left-[19px] before:top-2 before:w-px before:bg-line sm:before:left-[103px]">
      {records.map((r) => {
        const rx = prescriptions.find((p) => p.id === r.prescriptionId);
        const doc = L.doctor(r.doctorId);
        return (
          <li key={r.id} className="rise relative flex gap-4 sm:gap-6">
            <div className="hidden w-20 shrink-0 pt-3 text-right sm:block">
              <p className="num text-sm font-bold">{fmtDate(r.date, { day: 'numeric', month: 'short' })}</p>
              <p className="num text-xs text-ink-faint">{r.date.slice(0, 4)}</p>
            </div>
            <span className="relative z-10 mt-2.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-full border-4 border-white bg-care-500 text-white"><Stethoscope className="h-4 w-4" /></span>
            <div className="panel min-w-0 flex-1">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-4 py-3">
                <div>
                  <p className="text-xs text-ink-faint sm:hidden">{fmtDate(r.date)}</p>
                  <p className="font-bold">Consultation · {r.chiefComplaint}</p>
                  <p className="text-sm text-ink-soft">{doc?.name} · {L.department(doc?.departmentId)?.name}</p>
                </div>
                {r.date === today() && <Badge tone="blue">New today</Badge>}
              </div>
              <div className="divide-y divide-line text-sm">
                <Row icon={<FileSignature className="h-4 w-4" />} label="Notes">{r.consultationNotes}</Row>
                <Row icon={<Stethoscope className="h-4 w-4" />} label="Diagnosis (entered by doctor)"><span className="font-semibold">{r.diagnosisByDoctor || '—'}</span></Row>
                {r.vitals && <Row icon={<span className="text-[11px] font-bold">BP</span>} label="Vitals"><span className="num">BP {r.vitals.bp} · Pulse {r.vitals.pulse} · Temp {r.vitals.tempC}°C · SpO₂ {r.vitals.spo2}%</span> <DemoTag className="ml-1" /></Row>}
                <Row icon={<Pill className="h-4 w-4" />} label="Prescription">
                  {rx ? <ul className="space-y-0.5">{rx.medications.map((m, i) => <li key={i}><span className="font-semibold">{m.name}</span> — {m.dosage}, {m.frequency}, {m.duration}</li>)}</ul> : <span className="text-ink-faint">None</span>}
                </Row>
                <Row icon={<FlaskConical className="h-4 w-4" />} label="Lab tests">
                  {r.labTests.length ? <span className="flex flex-wrap gap-1.5">{r.labTests.map((t) => {
                    const lab = labs.find((l) => l.testName === t && l.patientId === r.patientId);
                    return <Badge key={t} tone={lab?.status === 'Available' ? 'teal' : 'amber'}>{t}{lab ? ` · ${lab.status}` : ''}</Badge>;
                  })}</span> : <span className="text-ink-faint">None ordered</span>}
                </Row>
                <Row icon={<CalendarClock className="h-4 w-4" />} label="Follow-up">{r.followUp ? <span className={r.followUp >= today() ? 'font-semibold text-care-600' : ''}>{fmtDate(r.followUp)}{r.followUp >= today() ? ' · upcoming' : ''}</span> : <span className="text-ink-faint">Not required</span>}</Row>
              </div>
            </div>
          </li>
        );
      })}
    </ol>
  );
}

function Row({ icon, label, children }: { icon: ReactNode; label: string; children: ReactNode }) {
  return (
    <div className="grid gap-1 px-4 py-2.5 sm:grid-cols-[190px_1fr] sm:gap-3">
      <p className="flex items-center gap-2 text-ink-faint">{icon}{label}</p>
      <div className="text-ink">{children}</div>
    </div>
  );
}
