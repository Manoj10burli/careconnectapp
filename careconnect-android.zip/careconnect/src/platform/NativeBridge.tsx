import { useEffect, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/hooks/useData';
import { services } from '@/services';
import { initNativeShell, isNative, prepareNotifications, showSystemNotification } from './native';

/**
 * Mounted once inside the router. Does nothing in a browser.
 * On Android it handles the back button and turns new in-app notifications
 * for the signed-in user into system notifications.
 */
export function NativeBridge() {
  const nav = useNavigate();
  const loc = useLocation();
  const { user } = useAuth();
  const pathRef = useRef(loc.pathname);
  pathRef.current = loc.pathname;

  useEffect(() => initNativeShell({ navigate: nav, currentPath: () => pathRef.current }), [nav]);
  useEffect(() => { if (isNative && user) prepareNotifications(); }, [user]);

  const { data } = useData(() => (isNative && user ? services.notifications.list(user.id) : Promise.resolve([])), [user?.id]);
  // Only surface notifications created after this user signed in on this device.
  const since = useRef({ userId: '', at: 0, shown: new Set<string>() });
  if (user && since.current.userId !== user.id) since.current = { userId: user.id, at: Date.now() - 2000, shown: new Set() };

  useEffect(() => {
    if (!isNative || !user || !data) return;
    for (const n of data) {
      if (n.userId !== user.id || n.read || since.current.shown.has(n.id)) continue;
      if (new Date(n.createdAt).getTime() < since.current.at) continue;
      since.current.shown.add(n.id);
      showSystemNotification({ id: n.id, title: n.title, body: n.message, link: n.link });
    }
  }, [data, user]);

  return null;
}
