/**
 * Platform layer. The rest of the app calls these helpers and never touches
 * Capacitor directly, so the same code runs in a browser and inside the
 * Android app. Every helper has a safe web fallback.
 */
import { Capacitor } from '@capacitor/core';
import { App } from '@capacitor/app';
import { Haptics, ImpactStyle, NotificationType } from '@capacitor/haptics';
import { LocalNotifications } from '@capacitor/local-notifications';
import { Directory, Filesystem } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

export const isNative = Capacitor.isNativePlatform();
export const platform = Capacitor.getPlatform(); // 'android' | 'ios' | 'web'

const CHANNEL_ID = 'careconnect-updates';

/* ------------------------------ Haptics ------------------------------ */

export async function haptic(kind: 'success' | 'warning' | 'tap' = 'tap') {
  if (!isNative) return;
  try {
    if (kind === 'tap') await Haptics.impact({ style: ImpactStyle.Light });
    else await Haptics.notification({ type: kind === 'success' ? NotificationType.Success : NotificationType.Warning });
  } catch { /* device without vibrator */ }
}

/* --------------------------- System notifications --------------------------- */

let notificationsReady: Promise<boolean> | null = null;

/** Asks for Android 13+ notification permission once and creates the channel. */
export function prepareNotifications(): Promise<boolean> {
  if (!isNative) return Promise.resolve(false);
  notificationsReady ??= (async () => {
    try {
      let perm = await LocalNotifications.checkPermissions();
      if (perm.display === 'prompt' || perm.display === 'prompt-with-rationale') perm = await LocalNotifications.requestPermissions();
      if (perm.display !== 'granted') return false;
      await LocalNotifications.createChannel({ id: CHANNEL_ID, name: 'CareConnect updates', description: 'Appointments, prescriptions and lab reports', importance: 4, visibility: 0, vibration: true });
      return true;
    } catch { return false; }
  })();
  return notificationsReady;
}

/** Stable positive 31-bit id from a string id (Android requires an int). */
const intId = (s: string) => {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
  return Math.abs(h) % 2147483647;
};

/**
 * Shows an Android system notification.
 * Production: replace with Firebase Cloud Messaging / Azure Notification Hubs
 * push, sent by the backend, so notifications arrive when the app is closed.
 */
export async function showSystemNotification(n: { id: string; title: string; body: string; link?: string }) {
  if (!(await prepareNotifications())) return;
  await LocalNotifications.schedule({
    notifications: [{
      id: intId(n.id), title: n.title, body: n.body, channelId: CHANNEL_ID,
      smallIcon: 'ic_stat_careconnect', iconColor: '#0F8A84', extra: { link: n.link },
    }],
  });
}

/* ------------------------------ Files ------------------------------ */

const blobToBase64 = (blob: Blob) => new Promise<string>((resolve, reject) => {
  const r = new FileReader();
  r.onload = () => resolve(String(r.result).split(',')[1]);
  r.onerror = () => reject(r.error);
  r.readAsDataURL(blob);
});

/**
 * Saves a file for the user. Web: normal browser download.
 * Android: writes to the app cache and opens the share sheet so the user can
 * open it in a PDF viewer, save to Files/Drive, or send it.
 */
export async function saveFile(blob: Blob, fileName: string): Promise<'downloaded' | 'shared' | 'cancelled'> {
  if (isNative) {
    const { uri } = await Filesystem.writeFile({ path: fileName, data: await blobToBase64(blob), directory: Directory.Cache });
    try {
      await Share.share({ title: fileName, url: uri, dialogTitle: 'Open or save the report' });
      return 'shared';
    } catch { return 'cancelled'; }
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = fileName; a.rel = 'noopener';
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  return 'downloaded';
}

/* ------------------------------ App lifecycle ------------------------------ */

const ROOT_PATHS = new Set(['/', '/doctor', '/admin', '/login']);

/**
 * Wires Android system integrations. Returns a cleanup function.
 * - Hardware back: closes an open dialog/drawer first, then navigates back,
 *   and on a home screen sends the app to the background.
 * - Tapping a system notification opens the related screen.
 */
export function initNativeShell(opts: { navigate: (path: string) => void; currentPath: () => string }) {
  if (!isNative) return () => {};
  const subs = [
    App.addListener('backButton', () => {
      if (document.querySelector('[role="dialog"]')) {
        document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
        return;
      }
      if (ROOT_PATHS.has(opts.currentPath())) App.minimizeApp();
      else window.history.back();
    }),
    LocalNotifications.addListener('localNotificationActionPerformed', (e) => {
      const link = e.notification.extra?.link as string | undefined;
      if (link) opts.navigate(link);
    }),
  ];
  return () => { subs.forEach((p) => p.then((h) => h.remove())); };
}
