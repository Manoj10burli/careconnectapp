import { ReactNode } from 'react';
import { HashRouter, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { ToastProvider } from '@/context/ToastContext';
import { AppShell } from '@/components/layout/AppShell';
import { NativeBridge } from '@/platform/NativeBridge';
import type { Role } from '@/types';
import LoginPage, { homeFor } from '@/pages/auth/LoginPage';
import PatientDashboard from '@/pages/patient/PatientDashboard';
import AppointmentsPage from '@/pages/patient/AppointmentsPage';
import BookAppointmentPage from '@/pages/patient/BookAppointmentPage';
import MedicalRecordsPage from '@/pages/patient/MedicalRecordsPage';
import LabReportsPage from '@/pages/patient/LabReportsPage';
import PrescriptionsPage from '@/pages/patient/PrescriptionsPage';
import AIAssistantPage from '@/pages/shared/AIAssistantPage';
import NotificationsPage from '@/pages/shared/NotificationsPage';
import ProfilePage from '@/pages/shared/ProfilePage';
import DoctorDashboard, { DoctorAppointmentsPage } from '@/pages/doctor/DoctorDashboard';
import PatientRecordPage, { PatientListPage } from '@/pages/doctor/PatientRecordPage';
import { AdminAppointmentsPage, AdminDashboard, AuditPage, DepartmentsPage, DoctorsPage, SettingsPage, UsersPage } from '@/pages/admin/AdminPages';

/**
 * Route guard. UI-level RBAC only improves the experience —
 * the production API must enforce the same rules server-side.
 */
function Guard({ roles, children }: { roles: Role[]; children: ReactNode }) {
  const { user } = useAuth();
  const loc = useLocation();
  if (!user) return <Navigate to="/login" state={{ from: loc.pathname }} replace />;
  if (!roles.includes(user.role)) return <Navigate to={homeFor(user.role)} replace />;
  return <AppShell>{children}</AppShell>;
}

const P: Role[] = ['patient'];
const D: Role[] = ['doctor'];
const A: Role[] = ['admin'];
const ALL: Role[] = ['patient', 'doctor', 'admin'];

function AppRoutes() {
  const { user } = useAuth();
  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to={homeFor(user.role)} replace /> : <LoginPage />} />
      <Route path="/" element={<Guard roles={P}><PatientDashboard /></Guard>} />
      <Route path="/appointments" element={<Guard roles={P}><AppointmentsPage /></Guard>} />
      <Route path="/appointments/book" element={<Guard roles={P}><BookAppointmentPage /></Guard>} />
      <Route path="/records" element={<Guard roles={P}><MedicalRecordsPage /></Guard>} />
      <Route path="/lab-reports" element={<Guard roles={P}><LabReportsPage /></Guard>} />
      <Route path="/prescriptions" element={<Guard roles={P}><PrescriptionsPage /></Guard>} />
      <Route path="/ai-assistant" element={<Guard roles={['patient', 'doctor']}><AIAssistantPage /></Guard>} />
      <Route path="/notifications" element={<Guard roles={ALL}><NotificationsPage /></Guard>} />
      <Route path="/profile" element={<Guard roles={ALL}><ProfilePage /></Guard>} />
      <Route path="/doctor" element={<Guard roles={D}><DoctorDashboard /></Guard>} />
      <Route path="/doctor/appointments" element={<Guard roles={D}><DoctorAppointmentsPage /></Guard>} />
      <Route path="/doctor/patients" element={<Guard roles={D}><PatientListPage /></Guard>} />
      <Route path="/doctor/patients/:id" element={<Guard roles={D}><PatientRecordPage /></Guard>} />
      <Route path="/admin" element={<Guard roles={A}><AdminDashboard /></Guard>} />
      <Route path="/admin/users" element={<Guard roles={A}><UsersPage /></Guard>} />
      <Route path="/admin/doctors" element={<Guard roles={A}><DoctorsPage /></Guard>} />
      <Route path="/admin/departments" element={<Guard roles={A}><DepartmentsPage /></Guard>} />
      <Route path="/admin/appointments" element={<Guard roles={A}><AdminAppointmentsPage /></Guard>} />
      <Route path="/admin/settings" element={<Guard roles={A}><SettingsPage /></Guard>} />
      <Route path="/admin/audit" element={<Guard roles={A}><AuditPage /></Guard>} />
      <Route path="*" element={<Navigate to={user ? homeFor(user.role) : '/login'} replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <HashRouter>
      <AuthProvider>
        <ToastProvider>
          <NativeBridge />
          <AppRoutes />
        </ToastProvider>
      </AuthProvider>
    </HashRouter>
  );
}
