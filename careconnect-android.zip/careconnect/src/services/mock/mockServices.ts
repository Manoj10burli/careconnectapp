import type {
  AdminService, AIService, AppointmentService, AuthService, DocumentService,
  MedicalRecordService, NotificationService, UserService,
} from '../interfaces';
import type { AIExtraction, AppNotification, AuditEntry, LabReport, Role, Session, StoredFile } from '@/types';
import { db, latency } from './mockDb';
import { sampleDocuments, cannedExtractions, DISCLAIMER } from '@/data/sampleDocuments';
import { fmtDate, fmtTime, today, uid } from '@/utils/format';

/* ----------------------------- helpers ----------------------------- */

const SESSION_KEY = 'careconnect.demo.session';
let session: Session | null = (() => {
  try { const s = localStorage.getItem(SESSION_KEY); return s ? (JSON.parse(s) as Session) : null; } catch { return null; }
})();

const audit = (action: string, entity: string, entityId?: string) => {
  const actor = session?.user;
  const entry: AuditEntry = {
    id: uid('AU'), at: new Date().toISOString(), actorId: actor?.id ?? 'system',
    actorName: actor?.name ?? 'System', role: actor?.role ?? 'admin', action, entity, entityId,
  };
  db.get().auditLog.unshift(entry);
};

const userIdForPatient = (patientId: string) => db.get().users.find((u) => u.profileId === patientId)?.id;
const userIdForDoctor = (doctorId: string) => db.get().users.find((u) => u.profileId === doctorId)?.id;
const doctorName = (id?: string) => db.get().doctors.find((d) => d.id === id)?.name ?? 'your doctor';
const patientName = (id: string) => db.get().patients.find((p) => p.id === id)?.name ?? 'Patient';

const channels = (): AppNotification['channels'] => {
  const c = db.get().config.channels;
  return (Object.keys(c) as AppNotification['channels']).filter((k) => c[k]);
};

const pushNotification = (n: Omit<AppNotification, 'id' | 'createdAt' | 'read' | 'channels'>) => {
  db.get().notifications.unshift({ ...n, id: uid('N'), createdAt: new Date().toISOString(), read: false, channels: channels() });
};

/* ------------------------------ auth ------------------------------- */

export const mockAuth: AuthService = {
  async login(email, password, role) {
    await latency(500);
    if (!email.trim() || !password.trim()) throw new Error('Enter your email and password.');
    const user = db.get().users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase() && u.role === role);
    if (!user) throw new Error(`No ${role} account found for that email. Try the demo login below.`);
    if (!user.active) throw new Error('This account is deactivated. Contact your administrator.');
    return this.startSession(user.id);
  },
  async demoLogin(role: Role) {
    await latency(400);
    const id = role === 'patient' ? 'U-P001' : role === 'doctor' ? 'U-D001' : 'U-ADM1';
    return this.startSession(id);
  },
  async logout() {
    if (session) db.mutate(() => audit('Signed out', 'Session'));
    session = null;
    try { localStorage.removeItem(SESSION_KEY); } catch { /* ignore */ }
  },
  getSession: () => session,
  // not part of the interface — internal helper
  startSession(userId: string): Session {
    const user = db.get().users.find((u) => u.id === userId)!;
    session = { user, accessToken: `demo-token-${uid('t')}`, expiresAt: new Date(Date.now() + 8 * 3600e3).toISOString() };
    try { localStorage.setItem(SESSION_KEY, JSON.stringify(session)); } catch { /* ignore */ }
    db.mutate((s) => {
      const u = s.users.find((x) => x.id === userId);
      if (u) u.lastLogin = new Date().toISOString();
      audit('Signed in', 'Session');
    });
    return session;
  },
} as AuthService & { startSession(userId: string): Session };

/* ------------------------------ users ------------------------------ */

export const mockUsers: UserService = {
  async listUsers() { await latency(); return [...db.get().users]; },
  async createUser(input) {
    await latency(300);
    if (db.get().users.some((u) => u.email.toLowerCase() === input.email.toLowerCase())) throw new Error('A user with this email already exists.');
    const user = { ...input, id: uid('U'), active: true };
    db.mutate((s) => { s.users.push(user); audit('Created user', 'User', user.id); });
    return user;
  },
  async setActive(userId, active) {
    await latency();
    db.mutate((s) => {
      const u = s.users.find((x) => x.id === userId);
      if (u) u.active = active;
      audit(active ? 'Activated user' : 'Deactivated user', 'User', userId);
    });
  },
  async listPatients() { await latency(); return [...db.get().patients]; },
  async getPatient(id) { await latency(120); return db.get().patients.find((p) => p.id === id); },
  async updatePatient(id, patch) {
    await latency(300);
    let updated = db.get().patients.find((p) => p.id === id)!;
    db.mutate((s) => {
      const i = s.patients.findIndex((p) => p.id === id);
      s.patients[i] = updated = { ...s.patients[i], ...patch, id };
      const u = s.users.find((x) => x.profileId === id);
      if (u) { u.name = updated.name; u.email = updated.email; u.phone = updated.phone; }
      audit('Updated profile', 'Patient', id);
    });
    return updated;
  },
  async listDoctors() { await latency(); return [...db.get().doctors]; },
  async getDoctor(id) { await latency(80); return db.get().doctors.find((d) => d.id === id); },
  async saveDoctor(doc) {
    await latency(300);
    const d = { ...doc, id: doc.id ?? uid('D') };
    db.mutate((s) => {
      const i = s.doctors.findIndex((x) => x.id === d.id);
      if (i >= 0) s.doctors[i] = d; else {
        s.doctors.push(d);
        s.users.push({ id: `U-${d.id}`, role: 'doctor', name: d.name, email: d.email, phone: d.phone, active: true, profileId: d.id });
      }
      audit(i >= 0 ? 'Updated doctor' : 'Added doctor', 'Doctor', d.id);
    });
    return d;
  },
  async listDepartments() { await latency(); return [...db.get().departments]; },
  async saveDepartment(dep) {
    await latency(250);
    const d = { ...dep, id: dep.id ?? uid('DEP') };
    db.mutate((s) => {
      const i = s.departments.findIndex((x) => x.id === d.id);
      if (i >= 0) s.departments[i] = d; else s.departments.push(d);
      audit(i >= 0 ? 'Updated department' : 'Added department', 'Department', d.id);
    });
    return d;
  },
};

/* --------------------------- appointments -------------------------- */

export const mockAppointments: AppointmentService = {
  async list(f = {}) {
    await latency();
    return db.get().appointments
      .filter((a) => (!f.patientId || a.patientId === f.patientId) && (!f.doctorId || a.doctorId === f.doctorId) && (!f.date || a.date === f.date) && (!f.status || a.status === f.status))
      .sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
  },
  async availableSlots(doctorId, date) {
    await latency(250);
    const doc = db.get().doctors.find((d) => d.id === doctorId);
    if (!doc) return [];
    const [y, m, d] = date.split('-').map(Number);
    if (!doc.workingDays.includes(new Date(y, m - 1, d).getDay())) return [];
    const taken = new Set(db.get().appointments.filter((a) => a.doctorId === doctorId && a.date === date && a.status !== 'Cancelled').map((a) => a.time));
    const now = new Date();
    const nowHM = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    return doc.slots.map((t) => ({ time: t, available: !taken.has(t) && !(date === today() && t <= nowHM) }));
  },
  async book(input) {
    await latency(600);
    const s0 = db.get();
    const doc = s0.doctors.find((d) => d.id === input.doctorId);
    if (!doc) throw new Error('Doctor not found.');
    if (!input.reason.trim()) throw new Error('Add a short reason for the visit.');
    if (s0.appointments.some((a) => a.doctorId === input.doctorId && a.date === input.date && a.time === input.time && a.status !== 'Cancelled'))
      throw new Error('That slot was just taken. Pick another time.');
    const status = s0.config.autoConfirmBookings ? 'Confirmed' : 'Pending';
    const appt = { ...input, id: uid('A'), departmentId: doc.departmentId, status, createdAt: new Date().toISOString() } as const;
    db.mutate((s) => {
      s.appointments.push({ ...appt });
      const pUser = userIdForPatient(input.patientId);
      const dUser = userIdForDoctor(input.doctorId);
      const when = `${fmtDate(input.date)} at ${fmtTime(input.time)}`;
      if (pUser) pushNotification({ userId: pUser, kind: status === 'Confirmed' ? 'appointment_confirmed' : 'system', title: status === 'Confirmed' ? 'Appointment confirmed' : 'Appointment requested', message: `${doc.name} — ${when}. ${status === 'Confirmed' ? 'A reminder will be sent before your visit.' : 'You will be notified once the clinic confirms.'}`, link: '/appointments' });
      if (dUser) pushNotification({ userId: dUser, kind: 'appointment_confirmed', title: 'New appointment booked', message: `${patientName(input.patientId)} booked ${when}: ${input.reason}`, link: `/doctor/patients/${input.patientId}` });
      audit('Booked appointment', 'Appointment', appt.id);
    });
    return { ...appt };
  },
  async cancel(id) {
    await latency(400);
    db.mutate((s) => {
      const a = s.appointments.find((x) => x.id === id);
      if (!a) return;
      a.status = 'Cancelled';
      const pUser = userIdForPatient(a.patientId);
      if (pUser) pushNotification({ userId: pUser, kind: 'appointment_cancelled', title: 'Appointment cancelled', message: `Your appointment with ${doctorName(a.doctorId)} on ${fmtDate(a.date)} at ${fmtTime(a.time)} was cancelled.`, link: '/appointments' });
      audit('Cancelled appointment', 'Appointment', id);
    });
  },
  async setStatus(id, status) {
    await latency(250);
    db.mutate((s) => {
      const a = s.appointments.find((x) => x.id === id);
      if (!a) return;
      a.status = status;
      const pUser = userIdForPatient(a.patientId);
      if (status === 'Confirmed' && pUser) pushNotification({ userId: pUser, kind: 'appointment_confirmed', title: 'Appointment confirmed', message: `${doctorName(a.doctorId)} — ${fmtDate(a.date)} at ${fmtTime(a.time)}.`, link: '/appointments' });
      audit(`Set appointment ${status.toLowerCase()}`, 'Appointment', id);
    });
  },
};

/* ------------------------- medical records ------------------------- */

export const mockRecords: MedicalRecordService = {
  async listRecords(patientId) {
    await latency();
    db.silent(() => audit('Viewed medical records', 'Patient', patientId));
    return db.get().medicalRecords.filter((r) => r.patientId === patientId).sort((a, b) => b.date.localeCompare(a.date));
  },
  async addConsultation(input) {
    await latency(500);
    if (!input.consultationNotes.trim()) throw new Error('Consultation notes are required.');
    const rec = { ...input, id: uid('MR'), date: today(), labTests: [] as string[] };
    db.mutate((s) => {
      s.medicalRecords.push(rec);
      if (input.appointmentId) {
        const a = s.appointments.find((x) => x.id === input.appointmentId);
        if (a) a.status = 'Completed';
      }
      const pUser = userIdForPatient(input.patientId);
      if (pUser && input.followUp) pushNotification({ userId: pUser, kind: 'follow_up', title: 'Follow-up scheduled', message: `${doctorName(input.doctorId)} asked to see you again around ${fmtDate(input.followUp)}.`, link: '/appointments/book' });
      audit('Added consultation note', 'MedicalRecord', rec.id);
    });
    return rec;
  },
  async listPrescriptions(f) {
    await latency();
    return db.get().prescriptions.filter((p) => (!f.patientId || p.patientId === f.patientId) && (!f.doctorId || p.doctorId === f.doctorId)).sort((a, b) => b.date.localeCompare(a.date));
  },
  async addPrescription(input) {
    await latency(500);
    const meds = input.medications.filter((m) => m.name.trim());
    if (!meds.length) throw new Error('Add at least one medicine.');
    const rx = { id: uid('RX'), patientId: input.patientId, doctorId: input.doctorId, date: today(), medications: meds, notes: input.notes, status: 'Active' as const };
    db.mutate((s) => {
      s.prescriptions.push(rx);
      const rec = input.recordId ? s.medicalRecords.find((r) => r.id === input.recordId) : undefined;
      if (rec) rec.prescriptionId = rx.id;
      const pUser = userIdForPatient(input.patientId);
      if (pUser) pushNotification({ userId: pUser, kind: 'prescription_added', title: 'New prescription added', message: `${doctorName(input.doctorId)} added a prescription with ${meds.length} medicine${meds.length > 1 ? 's' : ''}.`, link: '/prescriptions' });
      audit('Added prescription', 'Prescription', rx.id);
    });
    return rx;
  },
  async listLabReports(patientId) {
    await latency();
    return db.get().labReports.filter((l) => !patientId || l.patientId === patientId).sort((a, b) => b.date.localeCompare(a.date));
  },
  async requestLabTest(input) {
    await latency(400);
    const lr: LabReport = { id: uid('LR'), patientId: input.patientId, orderedById: input.doctorId, testName: input.testName, category: input.category, date: today(), status: 'Requested', labName: 'CareConnect Central Lab (Demo)', parameters: [], comments: input.comments };
    db.mutate((s) => {
      s.labReports.push(lr);
      const latest = s.medicalRecords.filter((r) => r.patientId === input.patientId && r.date === today()).pop();
      if (latest) latest.labTests.push(input.testName);
      const pUser = userIdForPatient(input.patientId);
      if (pUser) pushNotification({ userId: pUser, kind: 'lab_requested', title: 'Lab test requested', message: `${doctorName(input.doctorId)} requested a ${input.testName}. Visit the lab desk with your booking ID.`, link: '/lab-reports' });
      audit('Requested lab test', 'LabReport', lr.id);
    });
    return lr;
  },
};

/* ---------------------------- documents ---------------------------- */

const ALLOWED = ['application/pdf', 'image/png', 'image/jpeg', 'text/plain'];
const MAX_BYTES = 10 * 1024 * 1024;

export const mockDocuments: DocumentService = {
  validate(file) {
    if (!ALLOWED.includes(file.type)) return 'Only PDF, PNG, JPG or TXT files can be uploaded.';
    if (file.size > MAX_BYTES) return 'Files must be 10 MB or smaller.';
    if (file.size === 0) return 'This file is empty.';
    return null;
  },
  async readText(file) {
    const err = this.validate(file);
    if (err) throw new Error(err);
    const textContent = file.type === 'text/plain' ? await file.text() : undefined;
    return { id: uid('F'), fileName: file.name, mimeType: file.type, sizeBytes: file.size, uploadedAt: new Date().toISOString(), textContent } satisfies StoredFile;
  },
  async upload(file, meta) {
    const stored = await this.readText(file);
    await latency(900); // simulated upload + malware scan
    const lr: LabReport = { id: uid('LR'), patientId: meta.patientId, testName: meta.testName, category: meta.category, date: today(), status: 'Uploaded', labName: 'Uploaded by patient', parameters: [], file: stored, comments: 'Uploaded document — awaiting review by care team (demo).' };
    db.mutate((s) => {
      s.labReports.push(lr);
      const pUser = userIdForPatient(meta.patientId);
      if (pUser) pushNotification({ userId: pUser, kind: 'lab_available', title: 'Report uploaded', message: `"${meta.testName}" was uploaded securely and shared with your care team.`, link: '/lab-reports' });
      audit('Uploaded document', 'LabReport', lr.id);
    });
    return lr;
  },
  listSampleDocuments: () => sampleDocuments,
};

/* -------------------------- notifications ------------------------- */

export const mockNotifications: NotificationService = {
  async list(userId) {
    await latency(120);
    return db.get().notifications.filter((n) => n.userId === userId).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  },
  async markRead(id) { db.mutate((s) => { const n = s.notifications.find((x) => x.id === id); if (n) n.read = true; }); },
  async markAllRead(userId) { db.mutate((s) => s.notifications.forEach((n) => { if (n.userId === userId) n.read = true; })); },
  async send(n) {
    const full = { ...n, id: uid('N'), createdAt: new Date().toISOString(), read: false };
    db.mutate((s) => { s.notifications.unshift(full); });
    return full;
  },
};

/* ------------------------------- AI -------------------------------- */

/**
 * Mock AI. Sample documents return hand-written responses. Uploaded text is
 * processed with simple pattern matching so the demo still reacts to real input.
 * Production: AzureOpenAIService with a system prompt that forbids diagnosis
 * and treatment advice, plus output filtering and human review.
 */
const KNOWN_MEDS = ['paracetamol', 'amlodipine', 'metformin', 'atorvastatin', 'aspirin', 'cetirizine', 'levothyroxine', 'salbutamol', 'cholecalciferol', 'calcium', 'omeprazole', 'ibuprofen', 'amoxicillin', 'insulin', 'losartan', 'telmisartan', 'pantoprazole', 'azithromycin'];

const heuristicExtract = (title: string, text: string): Omit<AIExtraction, 'generatedAt' | 'model' | 'disclaimer'> => {
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const dateRe = /\b(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}-\d{2}-\d{2}|\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{4})\b/i;
  const importantDates = lines.filter((l) => dateRe.test(l)).slice(0, 6).map((l) => ({ date: l.match(dateRe)![0], context: l.replace(dateRe, '').replace(/[:\-–]+\s*$/, '').trim().slice(0, 80) || 'Date mentioned' }));
  const medications = lines.filter((l) => KNOWN_MEDS.some((m) => l.toLowerCase().includes(m))).slice(0, 8).map((l) => ({ name: l.replace(/^[-•*\s]+/, '').split(/\s{2,}|,|\(/)[0].slice(0, 60), detail: 'Mentioned in document' }));
  const labRe = /^([A-Za-z][A-Za-z0-9 ()\-/.]{1,40}?)\s*[:\s]\s*(\d+(?:\.\d+)?(?:\/\d+)?)\s*([A-Za-z%/µ.]+(?:\/[A-Za-z]+)?)?\s*(?:\(?(?:ref\.?|reference)?\s*([<>]?\s*\d+(?:\.\d+)?\s*[-–]?\s*\d*(?:\.\d+)?)\)?)?/i;
  const labValues = lines.map((l) => l.match(labRe)).filter((m): m is RegExpMatchArray => !!m && !dateRe.test(m[0])).slice(0, 10).map((m) => {
    const flagged = /\b(H|L|high|low|abnormal)\b/i.test(m.input ?? '');
    return { name: m[1].trim(), value: `${m[2]} ${m[3] ?? ''}`.trim(), referenceRange: m[4]?.trim(), outsideRange: flagged };
  });
  const attentionItems = [
    ...labValues.filter((v) => v.outsideRange).map((v) => ({ title: `${v.name} is flagged in the document`, detail: 'The document marks this value as outside its reference range. Ask your doctor what it means for you.' })),
    ...lines.filter((l) => /(urgent|follow[- ]?up|repeat|return if|review)/i.test(l)).slice(0, 3).map((l) => ({ title: 'Instruction in document', detail: l.slice(0, 140) })),
  ];
  return {
    documentTitle: title,
    documentType: /discharge/i.test(text) ? 'Discharge summary' : /lab|reference/i.test(text) ? 'Laboratory report' : 'Medical document',
    keyInformation: lines.slice(0, 4).map((l, i) => ({ label: i === 0 ? 'Heading' : `Line ${i + 1}`, value: l.slice(0, 90) })),
    plainLanguageSummary: `This document has about ${lines.length} lines of text. The assistant found ${importantDates.length} date${importantDates.length === 1 ? '' : 's'}, ${medications.length} medication mention${medications.length === 1 ? '' : 's'} and ${labValues.length} measured value${labValues.length === 1 ? '' : 's'}. It does not interpret what these mean for your health — please review them with your doctor.`,
    importantDates, medications, labValues,
    attentionItems: attentionItems.length ? attentionItems : [{ title: 'Nothing flagged', detail: 'No values in this document were marked as outside a reference range.' }],
  };
};

export const mockAI: AIService = {
  providerName: 'Mock AI (offline demo)',
  async analyzeDocument({ title, text }) {
    await latency(1600);
    const sample = sampleDocuments.find((d) => d.text === text);
    const base = sample ? cannedExtractions[sample.id] : heuristicExtract(title, text);
    db.silent(() => audit('Ran AI document summary', 'Document'));
    return { ...base, model: this.providerName, generatedAt: new Date().toISOString(), disclaimer: DISCLAIMER };
  },
};

/* ------------------------------ admin ------------------------------ */

export const mockAdmin: AdminService = {
  async getConfig() { await latency(100); return { ...db.get().config }; },
  async updateConfig(patch) {
    await latency(300);
    db.mutate((s) => { s.config = { ...s.config, ...patch }; audit('Updated configuration', 'AppConfig'); });
    return { ...db.get().config };
  },
  async listAudit(limit = 50) { await latency(); return db.get().auditLog.slice(0, limit); },
  async resetDemoData() { await latency(300); db.reset(); },
};
