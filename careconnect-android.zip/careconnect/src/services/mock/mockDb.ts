/**
 * A tiny in-browser "database" for the prototype.
 * Stands in for PostgreSQL / Azure SQL. Persisted to localStorage so the
 * patient → doctor → patient demo flow survives page reloads.
 */
import * as seed from '@/data/seed';
import type {
  AppConfig, AppNotification, Appointment, AuditEntry, Department, Doctor, LabReport,
  MedicalRecord, Patient, Prescription, UserAccount,
} from '@/types';

export interface DbState {
  version: number;
  users: UserAccount[];
  patients: Patient[];
  doctors: Doctor[];
  departments: Department[];
  appointments: Appointment[];
  medicalRecords: MedicalRecord[];
  prescriptions: Prescription[];
  labReports: LabReport[];
  notifications: AppNotification[];
  auditLog: AuditEntry[];
  config: AppConfig;
}

const STORAGE_KEY = 'careconnect.demo.db.v1';
const clone = <T>(v: T): T => JSON.parse(JSON.stringify(v));

const freshState = (): DbState => ({
  version: 1,
  users: clone(seed.users),
  patients: clone(seed.patients),
  doctors: clone(seed.doctors),
  departments: clone(seed.departments),
  appointments: clone(seed.appointments),
  medicalRecords: clone(seed.medicalRecords),
  prescriptions: clone(seed.prescriptions),
  labReports: clone(seed.labReports),
  notifications: clone(seed.notifications),
  auditLog: clone(seed.auditLog),
  config: clone(seed.defaultConfig),
});

const load = (): DbState => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw) as DbState;
  } catch { /* storage unavailable — fall back to seed */ }
  return freshState();
};

let state: DbState = load();
let revision = 0;
const listeners = new Set<() => void>();

export const db = {
  get: () => state,
  revision: () => revision,
  /** Apply a mutation, persist, and notify subscribers (UI re-fetches). */
  mutate(fn: (s: DbState) => void) {
    fn(state);
    revision++;
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch { /* ignore */ }
    listeners.forEach((l) => l());
  },
  /** Persist without notifying the UI — for side records such as read-access audit entries. */
  silent(fn: (s: DbState) => void) {
    fn(state);
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch { /* ignore */ }
  },
  reset() {
    state = freshState();
    this.mutate(() => {});
  },
  subscribe(l: () => void) {
    listeners.add(l);
    return () => { listeners.delete(l); };
  },
};

/** Simulated network latency so loading states are visible in the demo. */
export const latency = (ms = 180) => new Promise<void>((r) => setTimeout(r, ms));
