/**
 * Service contracts.
 *
 * The UI only ever talks to these interfaces (via `services` in ./index.ts).
 * Today they are backed by an in-browser mock store. To go to production,
 * write an implementation of each interface that calls the real backend
 * (e.g. `HttpAppointmentService` using ./http/apiClient.ts) and swap it in
 * the registry — no page or component needs to change.
 */
import type {
  AIExtraction, AppConfig, AppNotification, Appointment, AppointmentStatus, AuditEntry,
  Department, Doctor, ID, ISODate, LabReport, MedicalRecord, Medication, Patient,
  Prescription, Role, SampleDocument, Session, StoredFile, UserAccount,
} from '@/types';

export interface AuthService {
  /** Production: redirect to Microsoft Entra ID / OAuth 2.0 + PKCE. */
  login(email: string, password: string, role: Role): Promise<Session>;
  demoLogin(role: Role): Promise<Session>;
  logout(): Promise<void>;
  getSession(): Session | null;
}

export interface UserService {
  listUsers(): Promise<UserAccount[]>;
  createUser(input: Omit<UserAccount, 'id' | 'active'>): Promise<UserAccount>;
  setActive(userId: ID, active: boolean): Promise<void>;
  listPatients(): Promise<Patient[]>;
  getPatient(id: ID): Promise<Patient | undefined>;
  updatePatient(id: ID, patch: Partial<Patient>): Promise<Patient>;
  listDoctors(): Promise<Doctor[]>;
  getDoctor(id: ID): Promise<Doctor | undefined>;
  saveDoctor(doctor: Omit<Doctor, 'id'> & { id?: ID }): Promise<Doctor>;
  listDepartments(): Promise<Department[]>;
  saveDepartment(dep: Omit<Department, 'id'> & { id?: ID }): Promise<Department>;
}

export interface BookAppointmentInput {
  patientId: ID;
  doctorId: ID;
  date: ISODate;
  time: string;
  type: Appointment['type'];
  reason: string;
}

export interface AppointmentService {
  list(filter?: { patientId?: ID; doctorId?: ID; date?: ISODate; status?: AppointmentStatus }): Promise<Appointment[]>;
  availableSlots(doctorId: ID, date: ISODate): Promise<{ time: string; available: boolean }[]>;
  book(input: BookAppointmentInput): Promise<Appointment>;
  cancel(id: ID): Promise<void>;
  setStatus(id: ID, status: AppointmentStatus): Promise<void>;
}

export interface AddConsultationInput {
  patientId: ID;
  doctorId: ID;
  appointmentId?: ID;
  chiefComplaint: string;
  consultationNotes: string;
  diagnosisByDoctor: string;
  followUp?: ISODate;
  vitals?: MedicalRecord['vitals'];
}

export interface MedicalRecordService {
  listRecords(patientId: ID): Promise<MedicalRecord[]>;
  addConsultation(input: AddConsultationInput): Promise<MedicalRecord>;
  listPrescriptions(filter: { patientId?: ID; doctorId?: ID }): Promise<Prescription[]>;
  addPrescription(input: { patientId: ID; doctorId: ID; medications: Medication[]; notes?: string; recordId?: ID }): Promise<Prescription>;
  listLabReports(patientId?: ID): Promise<LabReport[]>;
  requestLabTest(input: { patientId: ID; doctorId: ID; testName: string; category: string; comments?: string }): Promise<LabReport>;
}

export interface DocumentService {
  /** Validates type/size, then stores. Production: Azure Blob Storage + malware scan. */
  validate(file: File): string | null;
  upload(file: File, meta: { patientId: ID; testName: string; category: string }): Promise<LabReport>;
  readText(file: File): Promise<StoredFile>;
  listSampleDocuments(): SampleDocument[];
}

export interface NotificationService {
  list(userId: ID): Promise<AppNotification[]>;
  markRead(id: ID): Promise<void>;
  markAllRead(userId: ID): Promise<void>;
  /** Production: fan out via Azure Communication Services (email/SMS) + push. */
  send(n: Omit<AppNotification, 'id' | 'createdAt' | 'read'>): Promise<AppNotification>;
}

export interface AIService {
  readonly providerName: string;
  /** Must extract and explain only. Never diagnose or recommend treatment. */
  analyzeDocument(input: { title: string; text: string }): Promise<AIExtraction>;
}

export interface AdminService {
  getConfig(): Promise<AppConfig>;
  updateConfig(patch: Partial<AppConfig>): Promise<AppConfig>;
  listAudit(limit?: number): Promise<AuditEntry[]>;
  resetDemoData(): Promise<void>;
}

export interface ServiceRegistry {
  auth: AuthService;
  users: UserService;
  appointments: AppointmentService;
  records: MedicalRecordService;
  documents: DocumentService;
  notifications: NotificationService;
  ai: AIService;
  admin: AdminService;
}
