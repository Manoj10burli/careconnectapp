/**
 * Service registry — the single seam between UI and data.
 *
 * Set VITE_DATA_SOURCE=api (and implement the Http* services) to switch the
 * whole app to a real backend. Components import `services` and never know
 * which implementation is behind it.
 */
import type { ServiceRegistry } from './interfaces';
import {
  mockAdmin, mockAI, mockAppointments, mockAuth, mockDocuments,
  mockNotifications, mockRecords, mockUsers,
} from './mock/mockServices';

const mockRegistry: ServiceRegistry = {
  auth: mockAuth,
  users: mockUsers,
  appointments: mockAppointments,
  records: mockRecords,
  documents: mockDocuments,
  notifications: mockNotifications,
  ai: mockAI,
  admin: mockAdmin,
};

// Future:
// const apiRegistry: ServiceRegistry = {
//   auth: new EntraIdAuthService(msalConfig),
//   appointments: new HttpAppointmentService(apiClient),
//   ai: new AzureOpenAIService(apiClient), // calls your backend, never Azure OpenAI directly from the browser
//   ...
// };

export const services: ServiceRegistry = mockRegistry;
export const DATA_SOURCE = 'mock' as const;
export type { ServiceRegistry } from './interfaces';
