/**
 * Production HTTP client (not used by the prototype yet).
 * - Attaches the OAuth / Entra ID bearer token to every request
 * - Sends a correlation ID for Application Insights tracing
 * - Normalises errors so services can surface friendly messages
 */
export interface ApiClientOptions {
  baseUrl: string;
  getAccessToken: () => Promise<string | null>;
}

export class ApiError extends Error {
  constructor(public status: number, message: string, public correlationId?: string) {
    super(message);
  }
}

export const createApiClient = ({ baseUrl, getAccessToken }: ApiClientOptions) => {
  const request = async <T>(method: string, path: string, body?: unknown): Promise<T> => {
    const token = await getAccessToken();
    const correlationId = crypto.randomUUID();
    const res = await fetch(`${baseUrl}${path}`, {
      method,
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-ID': correlationId,
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    if (!res.ok) throw new ApiError(res.status, (await res.text()) || res.statusText, correlationId);
    return res.status === 204 ? (undefined as T) : ((await res.json()) as T);
  };
  return {
    get: <T>(p: string) => request<T>('GET', p),
    post: <T>(p: string, b?: unknown) => request<T>('POST', p, b),
    put: <T>(p: string, b?: unknown) => request<T>('PUT', p, b),
    patch: <T>(p: string, b?: unknown) => request<T>('PATCH', p, b),
    delete: <T>(p: string) => request<T>('DELETE', p),
  };
};
export type ApiClient = ReturnType<typeof createApiClient>;
