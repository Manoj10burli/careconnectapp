/**
 * Example of a production implementation. Copy this pattern for each service.
 * Suggested REST surface (ASP.NET Core or Node/Express):
 *   GET    /api/appointments?patientId=&doctorId=&date=&status=
 *   GET    /api/doctors/{id}/slots?date=
 *   POST   /api/appointments
 *   POST   /api/appointments/{id}/cancel
 *   PATCH  /api/appointments/{id}/status
 * Authorization is enforced server-side (RBAC), never only in the UI.
 */
import type { AppointmentService } from '../interfaces';
import type { Appointment } from '@/types';
import type { ApiClient } from './apiClient';

export const createHttpAppointmentService = (api: ApiClient): AppointmentService => ({
  list: (f = {}) => api.get<Appointment[]>(`/api/appointments?${new URLSearchParams(f as Record<string, string>)}`),
  availableSlots: (doctorId, date) => api.get(`/api/doctors/${doctorId}/slots?date=${date}`),
  book: (input) => api.post<Appointment>('/api/appointments', input),
  cancel: (id) => api.post(`/api/appointments/${id}/cancel`),
  setStatus: (id, status) => api.patch(`/api/appointments/${id}/status`, { status }),
});
