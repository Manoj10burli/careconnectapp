package com.careconnect.demo;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
