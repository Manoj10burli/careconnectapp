/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Figtree', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
      colors: {
        ink: { DEFAULT: '#12304A', soft: '#4A6275', faint: '#7C8FA0' },
        care: { 50: '#EEF4FB', 100: '#D9E7F7', 500: '#2463B0', 600: '#1D5498', 700: '#17457E' },
        teal: { 50: '#E7F5F3', 100: '#C8EAE5', 500: '#0F8A84', 600: '#0B726E', 700: '#0A5C59', 900: '#083F3D' },
        line: '#DCE4EC',
        canvas: '#F6F9FB',
        attn: { 50: '#FDF6E7', 600: '#A86A0F' },
        alert: { 50: '#FDEEEA', 600: '#B83A1B' },
      },
      borderRadius: { panel: '14px', item: '10px' },
    },
  },
  plugins: [],
};
